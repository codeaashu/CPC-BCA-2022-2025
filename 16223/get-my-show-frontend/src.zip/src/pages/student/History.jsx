import React, { useEffect, useState } from "react";
import axios from "axios";
import { toast } from "react-toastify";

const History = () => {
  const [history, setHistory] = useState([]);
  const token = localStorage.getItem("token");

  useEffect(() => {
    const fetchHistory = async () => {
      try {
        const res = await axios.get("http://localhost:5000/api/student/history", {
          headers: { Authorization: `Bearer ${token}` },
        });
        setHistory(res.data);
      } catch (err) {
        console.error("History fetch error:", err);
        toast.error("❌ Failed to load history");
      }
    };
    fetchHistory();
  }, [token]);

  return (
    <div className="bg-white dark:bg-gray-800 p-4 rounded shadow mb-6">
      <h3 className="text-lg font-semibold text-orange-600 mb-3">📚 Attendance History</h3>

      {history.length === 0 ? (
        <p className="text-gray-500 dark:text-gray-300">No records found.</p>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full text-sm border border-gray-300 dark:border-gray-700">
            <thead>
              <tr className="bg-gray-200 dark:bg-gray-700 text-left">
                <th className="p-2">📅 Date</th>
                <th className="p-2">🎓 Batch</th>
                <th className="p-2">🏫 Class</th>
                <th className="p-2">📊 Status</th>
                <th className="p-2">✅ Present</th>
                <th className="p-2">👥 Total</th>
                <th className="p-2">📘 Class Done</th>
              </tr>
            </thead>
            <tbody>
              {history.map((item, i) => (
                <tr key={i} className="border-t border-gray-300 dark:border-gray-600">
                  <td className="p-2">{item.date}</td>
                  <td className="p-2">{item.batch}</td>
                  <td className="p-2">{item.className}</td>
                  <td className="p-2">
                    {item.status === "present" ? "✅ Present" : "❌ Absent"}
                  </td>
                  <td className="p-2">{item.presentCount}</td>
                  <td className="p-2">{item.totalStudents}</td>
                  <td className="p-2">{item.allClassesDone ? "✔️ Yes" : "❌ No"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

export default History;
