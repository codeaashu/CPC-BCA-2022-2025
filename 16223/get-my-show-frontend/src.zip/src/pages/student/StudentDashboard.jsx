import React from 'react';

const StudentDashboard = () => {
  return (
    <div className="text-center mt-10 text-2xl font-semibold text-green-600">
      Student Dashboard (Under Construction)
    </div>
  );
};

export default StudentDashboard;
