import React, { useState } from 'react';
import toast from 'react-hot-toast';
import bgImg from '../../assets/cimage-building.jpg'; // Save your image here

const Login = () => {
  const [formData, setFormData] = useState({ userId: '', password: '', role: 'student' });

  const handleLogin = (e) => {
    e.preventDefault();
    toast.success('Login functionality connected'); // Replace with real login later
  };

  const handleClickHeader = () => {
    toast('Please login first', { icon: '🔒' });
  };

  return (
    <div
      className="min-h-screen bg-cover bg-center flex flex-col"
      style={{ backgroundImage: `url(${bgImg})` }}
    >
      {/* Header */}
      <div className="flex justify-between items-center px-8 py-4 bg-gradient-to-r from-black/60 to-black/40 text-white">
        <div className="flex gap-6 text-sm md:text-base">
          <button onClick={handleClickHeader} className="hover:underline">STUDENT</button>
          <button onClick={handleClickHeader} className="hover:underline">FACULTY</button>
          <button onClick={handleClickHeader} className="hover:underline">ADMIN</button>
        </div>
        <h1 className="text-lg md:text-2xl font-bold tracking-wider">FACULTY MANAGEMENT SYSTEM</h1>
      </div>

      {/* Login Box */}
      <div className="flex-grow flex justify-center items-center">
        <form
          onSubmit={handleLogin}
          className="bg-cyan-400 shadow-xl rounded-2xl p-6 md:p-10 w-[90%] max-w-sm space-y-5 text-white"
        >
          <h2 className="text-xl font-bold text-center text-gray-900">LOGIN TO YOUR ACCOUNT</h2>

          <div>
            <label className="text-gray-900 font-medium">Email Address :</label>
            <input
              type="text"
              required
              value={formData.userId}
              onChange={(e) => setFormData({ ...formData, userId: e.target.value })}
              className="w-full mt-1 p-2 rounded-full bg-white text-black focus:outline-none"
            />
          </div>

          <div>
            <label className="text-gray-900 font-medium">Password :</label>
            <input
              type="password"
              required
              value={formData.password}
              onChange={(e) => setFormData({ ...formData, password: e.target.value })}
              className="w-full mt-1 p-2 rounded-full bg-white text-black focus:outline-none"
            />
          </div>

          <div>
            <label className="text-gray-900 font-medium">Select Role :</label>
            <select
              value={formData.role}
              onChange={(e) => setFormData({ ...formData, role: e.target.value })}
              className="w-full mt-1 p-2 rounded-full bg-white text-black"
            >
              <option value="student">Student</option>
              <option value="faculty">Faculty</option>
              <option value="admin">Admin</option>
            </select>
          </div>

          <button
            type="submit"
            className="w-full mt-4 py-2 bg-black text-white rounded-full hover:bg-gray-800 transition"
          >
            LOGIN
          </button>
        </form>
      </div>
    </div>
  );
};

export default Login;
