import React from 'react';

const AdminDashboard = () => {
  return (
    <div className="text-center mt-10 text-2xl font-semibold text-red-600">
      Admin Dashboard (Under Construction)
    </div>
  );
};

export default AdminDashboard;
