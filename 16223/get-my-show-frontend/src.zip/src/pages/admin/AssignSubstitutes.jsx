// src/pages/admin/AssignSubstitutes.jsx
import React, { useState } from "react";
import axios from "axios";

const AssignSubstitutes = () => {
  const [form, setForm] = useState({
    date: "",
    className: "",
    batch: "",
    period: "",
    subject: "",
    originalFaculty: "",
    substituteFaculty: ""
  });

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleAssign = async () => {
    try {
      const token = localStorage.getItem("token");
      await axios.post("http://localhost:5000/api/admin/substitute", form, {
        headers: { Authorization: `Bearer ${token}` }
      });
      alert("✅ Substitute assigned!");
    } catch (err) {
      console.error("❌ Failed to assign substitute:", err);
    }
  };

  return (
    <div className="text-gray-800 dark:text-white">
      <h2 className="text-2xl font-bold mb-4 text-orange-500">♻️ Assign Substitute Faculty</h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 bg-white dark:bg-gray-800 p-6 rounded-xl shadow">
        {["date", "className", "batch", "period", "subject", "originalFaculty", "substituteFaculty"].map((field) => (
          <input
            key={field}
            type="text"
            name={field}
            value={form[field]}
            onChange={handleChange}
            placeholder={field.replace(/([A-Z])/g, " $1")}
            className="p-2 rounded border dark:bg-gray-700 dark:border-gray-600"
          />
        ))}
        <button
          onClick={handleAssign}
          className="col-span-1 sm:col-span-2 bg-orange-500 hover:bg-orange-600 text-white py-2 rounded"
        >
          Assign Substitute
        </button>
      </div>
    </div>
  );
};

export default AssignSubstitutes;
