import React, { useState } from "react";
import axios from "axios";
import { toast } from "react-toastify";

const weekdays = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];

const AddRoutine = () => {
  const [batch, setBatch] = useState("");
  const [session, setSession] = useState("");
  const [semester, setSemester] = useState("");
  const [routineData, setRoutineData] = useState({});

  const handleInputChange = (day, index, field, value) => {
    const updated = { ...routineData };
    if (!updated[day]) updated[day] = [];

    updated[day][index] = {
      ...updated[day][index],
      [field]: value,
    };

    setRoutineData(updated);
  };

  const addPeriod = (day) => {
    const updated = { ...routineData };
    if (!updated[day]) updated[day] = [];

    updated[day].push({ time: "", subject: "", faculty: "" });
    setRoutineData(updated);
  };

  const handleSubmit = async () => {
    try {
      const token = localStorage.getItem("token");
      for (const day of weekdays) {
        const periods = routineData[day] || [];
        if (periods.length === 0) continue;

        await axios.post(
          "http://localhost:5000/api/admin/add/routine",
          { batch, semester, session, day, periods },
          { headers: { Authorization: `Bearer ${token}` } }
        );
      }

      toast.success("✅ Routine saved for selected days!");
      setRoutineData({});
    } catch (err) {
      console.error("Routine submit error", err);
      toast.error("❌ Error saving routine");
    }
  };

  return (
    <div className="text-gray-800 dark:text-white px-4 pb-20">
      <h2 className="text-3xl font-bold mb-6 text-orange-500">🗓️ Add Class Routine</h2>

      {/* Header Info */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <input
          value={batch}
          onChange={(e) => setBatch(e.target.value)}
          placeholder="Batch (e.g., BCA AKU Batch 1)"
          className="p-2 rounded border dark:bg-gray-700 dark:border-gray-600"
        />
        <input
          value={session}
          onChange={(e) => setSession(e.target.value)}
          placeholder="Session (e.g., 2022-2025)"
          className="p-2 rounded border dark:bg-gray-700 dark:border-gray-600"
        />
        <input
          value={semester}
          onChange={(e) => setSemester(e.target.value)}
          placeholder="Semester (e.g., Semester 1)"
          className="p-2 rounded border dark:bg-gray-700 dark:border-gray-600"
        />
      </div>

      {/* Routine Per Day */}
      {weekdays.map((day) => (
        <div key={day} className="bg-white dark:bg-gray-800 rounded-xl shadow mb-6 p-4">
          <div className="flex justify-between items-center mb-2">
            <h3 className="text-xl font-semibold text-orange-600">{day}</h3>
            <button
              onClick={() => addPeriod(day)}
              className="text-sm bg-orange-500 text-white px-3 py-1 rounded hover:bg-orange-600"
            >
              ➕ Add Period
            </button>
          </div>

          {(routineData[day] || []).map((period, index) => (
            <div key={index} className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-3">
              <input
                type="text"
                placeholder="Time (e.g., 10:00 - 11:00)"
                value={period.time}
                onChange={(e) => handleInputChange(day, index, "time", e.target.value)}
                className="p-2 rounded border dark:bg-gray-700 dark:border-gray-600"
              />
              <input
                type="text"
                placeholder="Subject"
                value={period.subject}
                onChange={(e) => handleInputChange(day, index, "subject", e.target.value)}
                className="p-2 rounded border dark:bg-gray-700 dark:border-gray-600"
              />
              <input
                type="text"
                placeholder="Faculty Name"
                value={period.faculty}
                onChange={(e) => handleInputChange(day, index, "faculty", e.target.value)}
                className="p-2 rounded border dark:bg-gray-700 dark:border-gray-600"
              />
            </div>
          ))}
        </div>
      ))}

      {/* Submit */}
      <button
        onClick={handleSubmit}
        className="bg-green-600 text-white px-6 py-2 rounded hover:bg-green-700"
      >
        ✅ Save Routine
      </button>
    </div>
  );
};

export default AddRoutine;
