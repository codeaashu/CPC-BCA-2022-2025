import React from 'react';

const FacultyDashboard = () => {
  return (
    <div className="text-center mt-10 text-2xl font-semibold text-blue-600">
      Faculty Dashboard (Under Construction)
    </div>
  );
};

export default FacultyDashboard;
