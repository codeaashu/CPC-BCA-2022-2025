import { BrowserRouter, Routes, Route } from "react-router-dom";
import Login from "./pages/login/Login"; // ✅ Correct default import

const StudentDashboard = () => <div>Student Dashboard OK</div>;
const FacultyDashboard = () => <div>Faculty Dashboard OK</div>;
const AdminDashboard = () => <div>Admin Dashboard OK</div>;

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Login />} />
        
      </Routes>
    </BrowserRouter>
  );
}

export default App;
