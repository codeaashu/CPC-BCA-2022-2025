package hospital.management.system;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class UserDBConection {

    public static void main(String[] args) {

    }

    Connection connection;
    Statement statement;

    public UserDBConection(){
        try{
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital_management_system","root","Amir@9471");

        }catch (Exception e){
            e.printStackTrace();
        }
    }

}
