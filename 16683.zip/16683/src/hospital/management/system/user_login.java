package hospital.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class user_login extends JFrame implements ActionListener {

    JTextField textField;
    JPasswordField jPasswordField;
    JButton b1, b2;

    user_login(){

            JLabel templet = new JLabel("PATIENT LOGIN");
            templet.setBounds(200,  10, 260, 53);
            templet.setFont(new Font("Tahoma", Font.BOLD, 20));
            templet.setForeground(Color.red);
            add(templet);

            JLabel nameLabel = new JLabel("Username");
            nameLabel.setBounds(140, 100, 100, 30);
            nameLabel.setFont(new Font("Tahoma", Font.BOLD, 16));
            nameLabel.setForeground(Color.BLACK);
            add(nameLabel);

            JLabel Password = new JLabel("Password");
            Password.setBounds(140, 160, 100, 30);
            Password.setFont(new Font("Tahoma", Font.BOLD, 16));
            Password.setForeground(Color.BLACK);
            add(Password);

            textField = new JTextField();
            textField.setBounds(250, 100, 145, 25);
            textField.setFont(new Font("Tahoma", Font.PLAIN, 15));
            textField.setBackground(new Color(255, 255, 255));
            add(textField);

            jPasswordField = new JPasswordField();
            jPasswordField.setBounds(250, 160, 145, 25);
            jPasswordField.setFont(new Font("Tahoma", Font.PLAIN, 15));
            jPasswordField.setBackground(new Color(255, 255, 255));
            add(jPasswordField);


            b1 = new JButton("LOGIN");
            b1.setBounds(140, 250, 120, 30);
            b1.setFont(new Font("serif", Font.BOLD, 15));
            b1.setBackground(Color.BLACK);
            b1.setForeground(Color.WHITE);
             b1.addActionListener(this);
            add(b1);

            b2 = new JButton("BACK");
            b2.setBounds(277, 250, 120, 30);
            b2.setFont(new Font("serif", Font.BOLD, 15));
            b2.setBackground(Color.BLACK);
            b2.setForeground(Color.WHITE);
            b2.addActionListener(this);
            add(b2);


            ImageIcon imageIcon2 = new ImageIcon(ClassLoader.getSystemResource("icon/image2.png.png"));
            JLabel label1 = new JLabel(imageIcon2);
            label1.setBounds(5, 5, 683, 390);
            add(label1);

            setUndecorated(true);
            setSize(693, 400);
            getContentPane().setBackground(new Color(161, 49, 236));
            setLocation(237, 280);
            setLayout(null);
            setVisible(true);
        }
     public void actionPerformed(ActionEvent ae){
        if(ae.getSource() == b1){
            String User = textField.getText();
            String Pass = new String(jPasswordField.getPassword());
            if(User.isEmpty()|| Pass.isEmpty()){
                JOptionPane.showMessageDialog(this, "All fields are required!");
                return;
            }
            try{
                md c = new md();
                String q = "Select *from users where username=? AND pw =?";
                PreparedStatement ps =
                        c.connection.prepareStatement(q);
                ps.setString(1,User);
                ps.setString(2,Pass);
                ResultSet resultSet = ps.executeQuery();
                if(resultSet.next()){
                 JOptionPane.showMessageDialog(this, "Login Successful!");
                 new Appointment();
                 setVisible(false);

                }else{
                   JOptionPane.showMessageDialog(this, "Invalid username or password");
                }
            }catch (Exception e){
                e.printStackTrace();
            }
        }else if (ae.getSource() == b2){
            setVisible(false);
        }
     }
    public static void main(String[] args) {
        new user_login();
    }
}
