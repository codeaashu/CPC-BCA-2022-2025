package hospital.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Handle extends JFrame {

    Handle(){

       ImageIcon imageIcon2 = new ImageIcon(ClassLoader.getSystemResource("icon/loginhandle.png"));
       JLabel label1 = new JLabel(imageIcon2);
       label1.setBounds(750,-150, 740, 1050);
       add(label1);

        ImageIcon imageIcon3 = new ImageIcon(ClassLoader.getSystemResource("icon/adminitrationpic.png"));
        JLabel label2 = new JLabel(imageIcon3);
        label2.setBounds(350,200, 450, 450);
        add(label2);

        JPanel panel = new JPanel();
        panel.setLayout(null);
        panel.setBounds(230,100, 1080, 550);
        panel.setBackground(new Color(241, 29, 156));
        add(panel);

        JButton Reg = new JButton("PATIENT REGISTER");
        Reg.setBounds(30,60,200,30);
        Reg.setFont(new Font("Tahoma", Font.BOLD, 15));
        Reg.setBackground(new Color(227, 223, 7));
        panel.add(Reg);
        Reg.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new User_register();
            }
        });

        JButton login = new JButton("PATIENT LOGIN");
        login.setBounds(253,60,200,30);
        login.setFont(new Font("Tahoma", Font.BOLD, 15));
        login.setBackground(new Color(227, 223, 7));
        panel.add(login);
        login.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new user_login();
            }
        });

        JButton admin = new JButton("DOCTOR LOGIN");
        admin.setBounds(470,60,200,30);
        admin.setFont(new Font("Tahoma", Font.BOLD, 15));
        admin.setBackground(new Color(227, 223, 7));
        panel.add(admin);
        admin.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new Adminlogin();
            }
        });
        setSize(1950,1090);
        getContentPane().setBackground(new Color(222, 174, 239));
        setLayout(null);
        setVisible(true);
    }

    public static void main(String[] args) {
        new Handle();
    }
}
