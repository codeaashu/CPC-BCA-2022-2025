package hospital.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

public class Reception  extends JFrame {

    Reception(){

        JPanel panel = new JPanel();
        panel.setLayout(null);
        panel.setBounds(-5,-5, 1950, 150);
        panel.setBackground(new Color(243, 5, 187));
        add(panel);

        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icon/Doclogo.png"));
        Image i3 = i1.getImage().getScaledInstance(250,250, Image.SCALE_SMOOTH);
        ImageIcon i2 = new ImageIcon(i3);
        JLabel label = new JLabel(i2);
        label.setBounds(1300,0,250,250);
        panel.add(label);

        ImageIcon i11 = new ImageIcon(ClassLoader.getSystemResource("icon/Hospitalicon.png"));
        Image image1 = i11.getImage().getScaledInstance(300,200, Image.SCALE_SMOOTH);
        ImageIcon i22 = new ImageIcon(image1);
        JLabel label2 = new JLabel(i22);
        label2.setBounds(1000,-20,300,200);
        panel.add(label2);

        JButton btn1 = new JButton("ADD PATIENT");
        btn1.setBounds(30,20,200,30);
        btn1.setBackground(new Color(246,215,118));
        panel.add(btn1);
        btn1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new new_patient();
            }
        });

        JButton btn2 = new JButton("ROOM");
        btn2.setBounds(30,60,200,30);
        btn2.setBackground(new Color(246,215,118));
        panel.add(btn2);
        btn2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    new Room();

                } catch (Exception E) {
                    E.printStackTrace();

                }
            }
        });

        JButton btn3 = new JButton("DEPARTMENT");
        btn3.setBounds(30,100,200,30);
        btn3.setBackground(new Color(246,215,118));
        panel.add(btn3);
        btn3.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new Department();
            }
        });

        JButton btn4 = new JButton("ALL EMPLOYEES INFO");
        btn4.setBounds(270 ,20,200,30);
        btn4.setBackground(new Color(246,215,118));
        panel.add(btn4);
        btn4.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new Employee_info();

            }
        });

        JButton btn5 = new JButton("PATIENT INFO");
        btn5.setBounds(270,60,200,30);
        btn5.setBackground(new Color(246,215,118));
        panel.add(btn5);
        btn5.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new AllPatient_info();

            }
        });

        JButton btn6 = new JButton("PATIENT DISCHARGE");
        btn6.setBounds(270,100,200,30);
        btn6.setBackground(new Color(246,215,118));
        panel.add(btn6);
        btn6.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               new patient_discharge();
            }
        });

        JButton btn7 = new JButton("UPDATE PATIENT DETAILS");
        btn7.setBounds(510,20,200,30);
        btn7.setBackground(new Color(246,215,118));
        panel.add(btn7);
        btn7.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new update_patient();
            }
        });

        JButton btn8 = new JButton("SEARCH ROOM");
        btn8.setBounds(510,60,200,30);
        btn8.setBackground(new Color(246,215,118));
        panel.add(btn8);
        btn8.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               new SearchRoom();
            }
        });

        JButton btn9 = new JButton("HOSPITAL AMBULANCE");
        btn9.setBounds(510,100,200,30);
        btn9.setBackground(new Color(246,215,118));
        panel.add(btn9);
        btn9.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
              new Ambulance();
            }
        });

        JButton btn10 = new JButton("LOGOUT");
        btn10.setBounds(750,60,200,30);
        btn10.setFont(new Font("Tahoma", Font.BOLD,16));
        btn10.setBackground(new Color(246, 34, 34));
        btn10.setForeground(Color.white);
        panel.add(btn10);
        btn10.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               new Adminlogin();
               Window window =
               SwingUtilities.getWindowAncestor(btn10);
               window.dispose();
            }
        });

        ImageIcon imageIcon2 = new ImageIcon(ClassLoader.getSystemResource("icon/Docteam.png"));
        Image image = imageIcon2.getImage().getScaledInstance(1950,1090, Image.SCALE_SMOOTH);
        ImageIcon scaledIcon = new ImageIcon(image);
        JLabel label1 = new JLabel(scaledIcon);
        label1.setHorizontalAlignment(JLabel.CENTER);
        label1.setVerticalAlignment(JLabel.CENTER);
        setLayout(new BorderLayout());
        add(label1, BorderLayout.CENTER);
        setSize(1950,1090);
        setVisible(true);

    }

    public static void main(String[] args)
    {
        new Reception();
    }
}
