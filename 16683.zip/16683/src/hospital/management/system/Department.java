package hospital.management.system;

import net.proteanit.sql.DbUtils;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;

public class Department extends JFrame {

    Department(){

        JPanel panel = new JPanel();
        panel.setBounds(5,5,640,540);
        panel.setLayout(null);
        panel.setBackground(new Color(111,241,171));
        add(panel);


        JTable table = new JTable();
        table.setBounds(30,80,600,300);
        table.setBackground(new Color(111,241,171));
        table.setFont(new Font("Tahoma", Font.BOLD,13));
        panel.add(table);

        try{
            md c = new md();
            String q = "select * from department";
            ResultSet resultSet = c.statement.executeQuery(q);
            table.setModel(DbUtils.resultSetToTableModel(resultSet));

        }catch (Exception E){
            E.printStackTrace();
        }

        JLabel label1 = new JLabel("Department");
        label1.setBounds(30,50,105,20);
        label1.setFont(new Font("Tahoma",Font.BOLD,15));
        label1.setForeground(Color.red);
        panel.add(label1);

        JLabel label2 = new JLabel("Phone Number");
        label2.setBounds(330,50,130,20);
        label2.setFont(new Font("Tahoma",Font.BOLD,15));
        label2.setForeground(Color.red);
        panel.add(label2);

        JButton back = new JButton("BACK");
        back.setBounds(260,450,120,30);
        back.setBackground(Color.BLACK);
        back.setForeground(Color.WHITE);
        panel.add(back);
        back.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
            }
        });

        setUndecorated(true);
        setSize(650, 550);
        getContentPane().setBackground(new Color(161, 49, 236));
        setLayout(null);
        setLocation(420, 200);
        setVisible(true);

    }

    public static void main(String[] args) {
        new Department();
    }


}
