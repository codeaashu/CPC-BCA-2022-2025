package hospital.management.system;

import net.proteanit.sql.DbUtils;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;

public class Ambulance extends JFrame {
    Ambulance(){

        JPanel panel = new JPanel();
        panel.setBounds(5,5,640,540);
        panel.setBackground(new Color(111,241,171));
        panel.setLayout(null);
        add(panel);

        JTable table = new JTable();
        table.setBounds(8,65,650,350);
        table.setBackground(new Color(111,241,171));
        table.setFont(new Font("Tahoma", Font.BOLD,13));
        panel.add(table);

        try{
            md c = new md();
            String q = "select * from Ambulance";
            ResultSet resultSet = c.statement.executeQuery(q);
            table.setModel(DbUtils.resultSetToTableModel(resultSet));

        }catch (Exception e){
            e.printStackTrace();
        }

        JLabel label1 = new JLabel("Name");
        label1.setBounds(10,25,70,25);
        label1.setFont(new Font("Tahoma", Font.BOLD,15));
        label1.setForeground(Color.red);
        panel.add(label1);

        JLabel label2 = new JLabel("Gender");
        label2.setBounds(160,25,150,25);
        label2.setFont(new Font("Tahoma", Font.BOLD,15));
        label2.setForeground(Color.red);
        panel.add(label2);

        JLabel label3 = new JLabel("Car-Name");
        label3.setBounds(300,25,100,25);
        label3.setFont(new Font("Tahoma", Font.BOLD,15));
        label3.setForeground(Color.red);
        panel.add(label3);

        JLabel label4 = new JLabel("Status");
        label4.setBounds(500,25,100,25);
        label4.setFont(new Font("Tahoma", Font.BOLD,15));
        label4.setForeground(Color.red);
        panel.add(label4);

        JButton back = new JButton("BACK");
        back.setBounds(260,450,120,30);
        back.setBackground(Color.BLACK);
        back.setForeground(Color.WHITE);
        panel.add(back);
        back.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
            }
        });

        setUndecorated(true);
        setSize(650,550);
        getContentPane().setBackground(new Color(161, 49, 236));
        setLocation(450,200);
        setLayout(null);
        setVisible(true);
    }

    public static void main(String[] args) {
        new Ambulance();
    }
}
