package hospital.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;


public class Adminlogin extends JFrame implements ActionListener {
    JTextField textField;
    JPasswordField jPasswordField;
    JButton b1, b2;

    Adminlogin() {

        JLabel templet = new JLabel("DOCTOR LOGIN");
        templet.setBounds(200,  10, 260, 53);
        templet.setFont(new Font("Tahoma", Font.BOLD, 20));
        templet.setForeground(Color.red);
        add(templet);

        JLabel nameLabel = new JLabel("Username");
        nameLabel.setBounds(140, 100, 100, 30);
        nameLabel.setFont(new Font("Tahoma", Font.BOLD, 16));
        nameLabel.setForeground(Color.BLACK);
        add(nameLabel);

        JLabel Password = new JLabel("Password");
        Password.setBounds(140, 160, 100, 30);
        Password.setFont(new Font("Tahoma", Font.BOLD, 16));
        Password.setForeground(Color.BLACK);
        add(Password);

        textField = new JTextField();
        textField.setBounds(250, 100, 145, 25);
        textField.setFont(new Font("Tahoma", Font.PLAIN, 15));
        textField.setBackground(new Color(255, 255, 255));
        add(textField);

        jPasswordField = new JPasswordField();
        jPasswordField.setBounds(250, 160, 145, 25);
        jPasswordField.setFont(new Font("Tahoma", Font.PLAIN, 15));
        jPasswordField.setBackground(new Color(255, 255, 255));
        add(jPasswordField);

        b1 = new JButton("LOGIN");
        b1.setBounds(140, 250, 120, 30);
        b1.setFont(new Font("serif", Font.BOLD, 15));
        b1.setBackground(Color.BLACK);
        b1.setForeground(Color.WHITE);
        b1.addActionListener(this);
        add(b1);

        b2 = new JButton("CANCEL");
        b2.setBounds(277, 250, 120, 30);
        b2.setFont(new Font("serif", Font.BOLD, 15));
        b2.setBackground(Color.BLACK);
        b2.setForeground(Color.WHITE);
        b2.addActionListener(this);
        add(b2);


        ImageIcon imageIcon2 = new ImageIcon(ClassLoader.getSystemResource("icon/image2.png.png"));
        JLabel label1 = new JLabel(imageIcon2);
        label1.setBounds(5, 5, 683, 390);
        add(label1);

        setUndecorated(true);
        setSize(693, 400);
        getContentPane().setBackground(new Color(205, 8, 236));
        setLocation(237, 280);
        setLayout(null);
        setVisible(true);
    }
    @Override
    public void actionPerformed(ActionEvent e) {

        if(e.getSource() == b1) {
            String user = textField.getText();
            String Pass = jPasswordField.getText();

            if(user.isEmpty() || Pass.isEmpty()){
                JOptionPane.showMessageDialog(this,"All fields are required");
                return;
            }
            try{
                md c = new md();
                String q = "select * from login where ID =  '" + user + "' and pw = '" + Pass + "'";
                ResultSet resultSet = c.statement.executeQuery(q);
                if(resultSet.next()){
                    new Reception();
                    setVisible(false);
                    }else{
                JOptionPane.showMessageDialog(null, "Invalid");
            }
                }catch (Exception ex){
                    ex.printStackTrace();
                }
        } else if (e.getSource() == b2){
            setVisible(false);
        }
    }
public static void main(String[] args) {
    new Adminlogin();

    }
}
