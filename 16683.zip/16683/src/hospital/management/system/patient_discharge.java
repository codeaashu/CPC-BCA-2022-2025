package hospital.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.util.Date;

public class patient_discharge extends JFrame {

patient_discharge(){


    JPanel panel = new JPanel();
    panel.setBounds(5,5,740,390);
    panel.setBackground(new Color(111,241,171));
    panel.setLayout(null);
    add(panel);

    JLabel label = new JLabel("CHECK-OUT");
    label.setBounds(300,20,150,20);
    label.setFont(new Font("Tahoma",Font.BOLD,20));
    label.setForeground(Color.red);
    panel.add(label);

    JLabel label2 = new JLabel("Patient Id");
    label2.setBounds(150,80,150,20);
    label2.setFont(new Font("Tahoma",Font.BOLD,14));
    label2.setForeground(Color.black);
    panel.add(label2);

    Choice choice = new Choice();
    choice.setBounds(350,80,150,25);
    panel.add(choice);

    JLabel label3 = new JLabel("Room Number");
    label3.setBounds(150,130,150,20);
    label3.setFont(new Font("Tahoma",Font.BOLD,14));
    label3.setForeground(Color.black);
    panel.add(label3);

    JLabel rn = new JLabel();
    rn.setBounds(350,130,150,20);
    rn.setFont(new Font("Tahoma",Font.BOLD,14));
    rn.setForeground(Color.black);
    panel.add(rn);

    JLabel label4 = new JLabel("In Time");
    label4.setBounds(150,180,150,20);
    label4.setFont(new Font("Tahoma",Font.BOLD,14));
    label4.setForeground(Color.black);
    panel.add(label4);

    JLabel inTime = new JLabel();
    inTime.setBounds(350,180,230,20);
    inTime.setFont(new Font("Tahoma",Font.BOLD,14));
    inTime.setForeground(Color.black);
    panel.add(inTime);

    JLabel label5 = new JLabel("Out Time");
    label5.setBounds(150,230,150,20);
    label5.setFont(new Font("Tahoma",Font.BOLD,14));
    label5.setForeground(Color.black);
    panel.add(label5);

    Date date = new Date();

    JLabel OutTime = new JLabel(""+date);
    OutTime.setBounds(350,230,250,20);
    OutTime.setFont(new Font("Tahoma",Font.BOLD,14));
    OutTime.setForeground(Color.black);
    panel.add(OutTime);

    JButton discharge = new JButton("DISCHARGE");
    discharge.setBounds(150,300,120,30);
    discharge.setBackground(Color.black);
    discharge.setForeground(Color.white);
    panel.add(discharge);
    discharge.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            md c = new md();
            try {
                c.statement.executeUpdate("delete from patient_info where number = '" + choice.getSelectedItem() + "'");
                c.statement.executeUpdate("update Room set Avaliability = 'Available' where Room_No = '" + rn.getText() + "'");
                JOptionPane.showMessageDialog(null, "Patient Discharge and Room Available");
                setVisible(false);

            }catch (Exception E){
                E.printStackTrace();

            }
        }
    });

    JButton check = new JButton("CHECK");
    check.setBounds(300,300,120,30);
    check.setBackground(Color.black);
    check.setForeground(Color.white);
    panel.add(check);
    check.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            md c = new md();
            try {
                ResultSet resultSet = c.statement.executeQuery("select * from patient_info where number ='" + choice.getSelectedItem() + "'");
                 if(resultSet.next()) {
                    rn.setText(resultSet.getString("Room_Number"));
                    inTime.setText(resultSet.getString("Time"));
                }else{
                    JOptionPane.showMessageDialog(null, "Dont Have Data");
                };
            }catch (Exception E){
                E.printStackTrace();
            }
        }
    });
    JButton back = new JButton("BACK");
    back.setBounds(450,300,120,30);
    back.setBackground(Color.black);
    back.setForeground(Color.white);
    panel.add(back);
    back.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            setVisible(false);
        }
    });

    try{
        md c = new md();
        ResultSet resultSet = c.statement.executeQuery("select * from patient_info");
        while(resultSet.next()){
            choice.add(resultSet.getString("number"));
        }

    }catch (Exception e) {
        e.printStackTrace();
    }
    setUndecorated(true);
    setSize(750,400);
    getContentPane().setBackground(new Color(161, 49, 236));
    setLayout(null);
    setLocation(400,250);
    setVisible(true);

}

public static void main(String[] args) {

    new patient_discharge();
  }
}
