package hospital.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Date;

public class new_patient extends JFrame implements ActionListener {
    JComboBox comboBox;
    JTextField textFieldNumber, textName,
            textFieldDisease, textFieldDeposite;

    JRadioButton r1, r2;
    Choice c1;

    JLabel date;
    JButton b1, b2;


    new_patient() {


        ImageIcon imageIcon1 = new ImageIcon(ClassLoader.getSystemResource("icon/patientnote.jpg"));
        JLabel Panel = new JLabel(imageIcon1);
        Panel.setBounds(5, 5, 840, 540);
        add(Panel);

        JLabel labelName = new JLabel("ADD PATIENT FORM");
        labelName.setBounds(150, -11, 260, 53);
        labelName.setFont(new Font("Tahoma", Font.BOLD, 20));
        labelName.setForeground(Color.RED);
        Panel.add(labelName);

        JLabel labelID = new JLabel("ID :");
        labelID.setBounds(35, 76, 200, 14);
        labelID.setFont(new Font("Tahoma", Font.BOLD, 15));
        labelID.setForeground(Color.black);
        Panel.add(labelID);

        comboBox = new JComboBox(new String[]{"Aadhar Card", "Voter Id", "Driving License"});
        comboBox.setBounds(271, 73, 155, 20);
        comboBox.setBackground(new Color(111, 241, 171));
        comboBox.setForeground(Color.black);
        comboBox.setFont(new Font("Tahoma", Font.BOLD, 14));
        Panel.add(comboBox);

        JLabel labelNumber = new JLabel("NUMBER :");
        labelNumber.setBounds(35, 111, 200, 14);
        labelNumber.setFont(new Font("Tahoma", Font.BOLD, 15));
        labelNumber.setForeground(Color.black);
        Panel.add(labelNumber);

        textFieldNumber = new JTextField();
        textFieldNumber.setBounds(271, 111, 155, 20);
        textFieldNumber.setBackground(new Color(111, 241, 171));
        textFieldNumber.setFont(new Font("Tahoma", Font.BOLD, 14));
        textFieldNumber.setForeground(Color.black);
        Panel.add(textFieldNumber);

        JLabel labelName1 = new JLabel("NAME :");
        labelName1.setBounds(35, 151, 200, 14);
        labelName1.setFont(new Font("Tahoma", Font.BOLD, 15));
        labelName1.setForeground(Color.black);
        Panel.add(labelName1);

        textName = new JTextField();
        textName.setBounds(271, 151, 155, 20);
        textName.setBackground(new Color(111, 241, 171));
        textName.setFont(new Font("Tahoma", Font.BOLD, 14));
        textName.setForeground(Color.black);
        Panel.add(textName);

        JLabel labelGender = new JLabel("GENDER :");
        labelGender.setBounds(35, 191, 200, 14);
        labelGender.setFont(new Font("Tahoma", Font.BOLD, 15));
        labelGender.setForeground(Color.black);
        Panel.add(labelGender);

        r1 = new JRadioButton("Male");
        r1.setFont(new Font("Tahoma", Font.BOLD, 14));
        r1.setForeground(Color.black);
        r1.setBackground(new Color(111, 241, 171));
        r1.setBounds(271, 191, 80, 20);
        Panel.add(r1);

        r2 = new JRadioButton("Female");
        r2.setFont(new Font("Tahoma", Font.BOLD, 14));
        r2.setForeground(Color.black);
        r2.setBackground(new Color(111, 241, 171));
        r2.setBounds(345, 191, 80, 20);
        Panel.add(r2);

        JLabel labelDisease = new JLabel("DISEASE :");
        labelDisease.setBounds(35, 231, 200, 14);
        labelDisease.setFont(new Font("Tahoma", Font.BOLD, 15));
        labelDisease.setForeground(Color.black);
        Panel.add(labelDisease);

        textFieldDisease = new JTextField();
        textFieldDisease.setBounds(271, 231, 155, 20);
        textFieldDisease.setBackground(new Color(111, 241, 171));
        textFieldDisease.setFont(new Font("Tahoma", Font.BOLD, 14));
        textFieldDisease.setForeground(Color.black);
        Panel.add(textFieldDisease);

        JLabel labelRoom = new JLabel("Room.No :");
        labelRoom.setBounds(35, 274, 200, 14);
        labelRoom.setFont(new Font("Tahoma", Font.BOLD, 15));
        labelRoom.setForeground(Color.black);
        Panel.add(labelRoom);

        c1 = new Choice();
        try {
            md c = new md();
            ResultSet resultSet = c.statement.executeQuery("select * from Room");
            while (resultSet.next()) {
                c1.add(resultSet.getString("room_no"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        c1.setBounds(271, 274, 155, 20);
        c1.setFont(new Font("Tahoma", Font.BOLD, 14));
        c1.setForeground(Color.black);
        c1.setBackground(new Color(111, 241, 171));
        Panel.add(c1);


        JLabel labelDate = new JLabel("Time :");
        labelDate.setBounds(35, 316, 200, 14);
        labelDate.setFont(new Font("Tahoma", Font.BOLD, 15));
        labelDate.setForeground(Color.black);
        Panel.add(labelDate);

        Date now = new Date();

        SimpleDateFormat sdf = new SimpleDateFormat("EEE MMM dd hh:mm:ss a yyy");
        date = new JLabel(""+sdf.format(now));
        date.setBounds(271, 316, 240, 14);
        date.setForeground(Color.black);
        date.setFont(new Font("Tahoma", Font.BOLD, 14));
        Panel.add(date);

        JLabel labelDeposite = new JLabel("DEPOSITE :");
        labelDeposite.setBounds(35, 359, 200, 14);
        labelDeposite.setFont(new Font("Tahoma", Font.BOLD, 15));
        labelDeposite.setForeground(Color.black);
        Panel.add(labelDeposite);

        textFieldDeposite = new JTextField();
        textFieldDeposite.setBounds(271, 359, 155, 20);
        textFieldDeposite.setBackground(new Color(111, 241, 171));
        textFieldDeposite.setFont(new Font("Tahoma", Font.BOLD, 14));
        textFieldDeposite.setForeground(Color.black);
        Panel.add(textFieldDeposite);

        b1 = new JButton("ADD");
        b1.setBounds(100, 430, 120, 30);
        b1.setForeground(Color.white);
        b1.setBackground(Color.black);
        b1.addActionListener(this);
        Panel.add(b1);

        b2 = new JButton("BACK");
        b2.setBounds(260, 430, 120, 30);
        b2.setForeground(Color.white);
        b2.setBackground(Color.black);
        b2.addActionListener(this);
        Panel.add(b2);

        setUndecorated(true);
        setSize(850, 550);
        getContentPane().setBackground(new Color(161, 49, 236));
        setLayout(null);
        setLocation(320, 200);
        setVisible(true);

    }

    public static void main(String[] args) {
        new new_patient();

    }
    @Override
    public void actionPerformed(ActionEvent e) {

        if (e.getSource() == b1) {
            md c = new md();
            String radioBTN = null;
            if (r1.isSelected()) {
                radioBTN = "Male";
            } else if (r2.isSelected()) {
                radioBTN = "Female";
            }
            String s1 = (String) comboBox.getSelectedItem();
            String s2 = textFieldNumber.getText();
            String s3 = textName.getText();
            String s4 = radioBTN;
            String s5 = textFieldDisease.getText();
            String s6 = c1.getSelectedItem();
            String s7 = date.getText();
            String s8 = textFieldDeposite.getText();

            try {
                String q = "insert into Patient_Info values('" + s1 + "','" + s2 + "','" + s3 + "','" + s4 + "','" + s5 + "','" + s6 + "','" + s7 + "','" + s8 + "')";
                String q1 = "update room set Avaliability = 'Occupied' where room_no = " + s6;
                c.statement.executeUpdate(q);
                c.statement.executeUpdate(q1);
                JOptionPane.showMessageDialog(null, "Added Successfully");
                setVisible(false);

            } catch (Exception E) {
                E.printStackTrace();
            }

        } else {
            setVisible(false);
        }
    }

}
