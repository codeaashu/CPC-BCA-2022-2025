package hospital.management.system;

import javax.swing.*;
import javax.xml.transform.Result;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.InputStream;
import java.math.BigDecimal;
import java.sql.*;

public class update_patient extends JFrame{


    update_patient(){


        JPanel panel = new JPanel();
        panel.setBounds(5,5,740,440);
        panel.setBackground(new Color(111,241,171));
        panel.setLayout(null);
        add(panel);

        JLabel label = new JLabel("UPDATE PATIENT DETAILS");
        label.setBounds(230,20,350,20);
        label.setFont(new Font("Tahoma",Font.BOLD,20));
        label.setForeground(Color.red);
        panel.add(label);

        JLabel label1 = new JLabel("Name");
        label1.setBounds(150,88,80,14);
        label1.setFont(new Font("Tahoma",Font.BOLD,14));
        label1.setForeground(Color.black);
        panel.add(label1);


        Choice choice = new Choice();
        choice.setBounds(450,85,140,25);
        panel.add(choice);

        try{

            md c = new md();
            ResultSet resultSet = c.statement.executeQuery("select * from patient_info");
            while(resultSet.next()){
                choice.add(resultSet.getString("Name"));
            }

        }catch (Exception E){
            E.printStackTrace();
        }

        JLabel label2 = new JLabel("Room Number");
        label2.setBounds(150,129,250,14);
        label2.setFont(new Font("Tahoma",Font.BOLD,14));
        label2.setForeground(Color.black);
        panel.add(label2);

        JTextField textFieldRomm =  new JTextField();
        textFieldRomm.setBounds(450,129,140,20);
        panel.add(textFieldRomm);

        JLabel label3 = new JLabel("In-Time");
        label3.setBounds(150,174,100,14);
        label3.setFont(new Font("Tahoma",Font.BOLD,14));
        label3.setForeground(Color.black);
        panel.add(label3);

        JTextField textFieldINTime =  new JTextField();
        textFieldINTime.setBounds(450,174,140,20);
        panel.add(textFieldINTime);

        JLabel label4 = new JLabel("Amount Paid (Rs):");
        label4.setBounds(150,216,250,14);
        label4.setFont(new Font("Tahoma",Font.BOLD,14));
        label4.setForeground(Color.black);
        panel.add(label4);

        JTextField textFieldAmount =  new JTextField();
        textFieldAmount.setBounds(450,216,140,20);
        panel.add(textFieldAmount);

        JLabel label5 = new JLabel("Pending Amount (Rs):");
        label5.setBounds(150,261,250,18);
        label5.setFont(new Font("Tahoma",Font.BOLD,14));
        label5.setForeground(Color.black);
        panel.add(label5);

        JTextField textFieldPending =  new JTextField();
        textFieldPending.setBounds(450,261,140,20);
        panel.add(textFieldPending);

        JButton check = new JButton("CHECK");
        check.setBounds(500,378,89,23);
        check.setBackground(Color.black);
        check.setForeground(Color.white);
        panel.add(check);
        check.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String id = choice.getSelectedItem();
                String q = "select * from patient_info where Name = '"+id+"'";
                try{
                    md c = new md();
                    ResultSet resultSet = c.statement.executeQuery(q);
                    while (resultSet.next()){
                        textFieldRomm.setText(resultSet.getString("Room_Number"));
                        textFieldINTime.setText(resultSet.getString("Time"));
                        textFieldAmount.setText(resultSet.getString("Deposite"));

                    }
                    ResultSet resultSet1 = c.statement.executeQuery("select * from room where room_no = '"+textFieldRomm.getText()+"'");
                    while (resultSet1.next()){
                        String Price = resultSet1.getString("Price");
                        int amountPaid = Integer.parseInt(textFieldAmount.getText());
                        int price = Integer.parseInt(Price);
                        int pending = price -amountPaid;
                        if(pending < 0){
                            pending = 0;
                        }
                        textFieldPending.setText(""+pending);
                    }

                }catch (Exception E){
                    E.printStackTrace();
                }
            }
        });

        JButton update = new JButton("UPDATE");
        update.setBounds(100,378,89,23);
        update.setBackground(Color.black);
        update.setForeground(Color.white);
        panel.add(update);
        update.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try{
                    md c = new md();
                    String q =choice.getSelectedItem();
                    String room = textFieldRomm.getText();
                    String time = textFieldINTime.getText();
                    String amount = textFieldAmount.getText();
                    c.statement.executeUpdate("update patient_info set Room_Number = '"+room+"',Time = '"+time+"',Deposite = '"+amount+"' where name = '"+q+"'");
                    JOptionPane.showMessageDialog(null,"Update Successfully");
                    setVisible(false);

                }catch (Exception E){
                    E.printStackTrace();
                }
            }
        });

        JButton back = new JButton("BACK");
        back.setBounds(310,378,89,23);
        back.setBackground(Color.black);
        back.setForeground(Color.white);
        panel.add(back);
        back.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
            }
        });

        setUndecorated(true);
        setSize(750,450);
        getContentPane().setBackground(new Color(161, 49, 236));
        setLayout(null);
        setLocation(400,250);
        setVisible(true);

    }

    public static void main(String[] args) {
        new update_patient();
    }
}