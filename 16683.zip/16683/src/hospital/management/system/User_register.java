package hospital.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.PreparedStatement;

public class User_register extends JFrame implements ActionListener{

    JTextField textField;
    JTextField mailField;
    JPasswordField jPasswordField;
    JButton b1, b2;


    User_register(){

        JLabel labelName = new JLabel("PATIENT REGISTER");
        labelName.setBounds(200,  10, 260, 53);
        labelName.setFont(new Font("Tahoma", Font.BOLD, 20));
        labelName.setForeground(Color.RED);
        add(labelName);

        JLabel nameLabel = new JLabel("Username");
        nameLabel.setBounds(130, 90, 100, 30);
        nameLabel.setFont(new Font("Tahoma", Font.BOLD, 16));
        nameLabel.setForeground(Color.BLACK);
        add(nameLabel);

        JLabel Email = new JLabel("Email");
        Email.setBounds(130,150,100,30);
        Email.setFont(new Font("Tahoma", Font.BOLD,16));
        Email.setForeground(Color.black);
        add(Email);

        JLabel Password = new JLabel("Password");
        Password.setBounds(130, 210, 100, 30);
        Password.setFont(new Font("Tahoma", Font.BOLD, 16));
        Password.setForeground(Color.BLACK);
        add(Password);

        textField = new JTextField();
        textField.setBounds(280, 90, 150, 25);
        textField.setFont(new Font("Tahoma", Font.PLAIN, 15));
        textField.setBackground(new Color(255, 255, 255));
        add(textField);

        mailField = new JTextField();
        mailField.setBounds(280, 150, 150, 25);
        mailField.setFont(new Font("Tahoma", Font.PLAIN, 15));
        mailField.setBackground(new Color(255, 255, 255));
        add(mailField);

        jPasswordField = new JPasswordField();
        jPasswordField.setBounds(280, 210, 150, 25);
        jPasswordField.setFont(new Font("Tahoma", Font.PLAIN, 15));
        jPasswordField.setBackground(new Color(255, 255, 255));
        add(jPasswordField);

        b1 = new JButton("SUBMIT");
        b1.setBounds(130, 280, 120, 30);
        b1.setFont(new Font("serif", Font.BOLD, 15));
        b1.setBackground(Color.BLACK);
        b1.setForeground(Color.WHITE);
        b1.addActionListener(this);
        add(b1);

        b2 = new JButton("CANCEL");
        b2.setBounds(300, 280, 120, 30);
        b2.setFont(new Font("serif", Font.BOLD, 15));
        b2.setBackground(Color.BLACK);
        b2.setForeground(Color.WHITE);
        b2.addActionListener(this);
        add(b2);

       ImageIcon imageIcon2 = new ImageIcon(ClassLoader.getSystemResource("icon/image2.png.png"));
       JLabel label1 = new JLabel(imageIcon2);
       label1.setBounds(5, 5, 683, 390);
       add(label1);

        setUndecorated(true);
        setSize(693, 400);
        getContentPane().setBackground(new Color(142, 25, 239));
        setLocation(237,280);
        setLayout(null);
        setVisible(true);


    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == b1) {
            md c = new md();
            String user = textField.getText();
            String email = mailField.getText();
            String Pass = jPasswordField.getText();

            if(user.isEmpty()||email.isEmpty()||Pass.isEmpty()){
             JOptionPane.showMessageDialog(null,"All fields are required!");
            return;
           }
           if(!email.endsWith("@gmail.com")){
               JOptionPane.showMessageDialog(null,"Please enter valid Gmail address!");
           return;
          }
          try{
              PreparedStatement ps =
                      c.connection.prepareStatement("INSERT INTO users(username,email,pw) VALUES (?,?,?)");
              ps.setString(1,user);
              ps.setString(2,email);
              ps.setString(3,Pass);
              ps.executeUpdate();
              JOptionPane.showMessageDialog(null, "User Registered Successfully!");
              setVisible(false);
        } catch (Exception ex){
              ex.printStackTrace();
        }

      }else if(e.getSource() == b2) {
            setVisible(false);

        }
     }
   public static void main(String[] args) {
       new User_register();
   }
}

