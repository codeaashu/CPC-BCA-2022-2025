package hospital.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

public class Appointment extends JFrame {

    Appointment(){


        JPanel panel = new JPanel();
        panel.setLayout(null);
        panel.setBounds(-5,-5, 1950, 120);
        panel.setBackground(new Color(243, 5, 187));
        add(panel);

        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icon/logoappontment.png"));
        Image i3 = i1.getImage().getScaledInstance(250,120, Image.SCALE_SMOOTH);
        ImageIcon i2 = new ImageIcon(i3);
        JLabel label = new JLabel(i2);
        label.setBounds(1283,0,250,120);
        panel.add(label);

        JButton btn1 = new JButton("ADD PATIENT");
        btn1.setBounds(30,23,200,30);
        btn1.setBackground(new Color(246,215,118));
        panel.add(btn1);
        btn1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new new_patient();
            }
        });

        JButton btn2 = new JButton("ROOM");
        btn2.setBounds(30,75,200,30);
        btn2.setBackground(new Color(246,215,118));
        panel.add(btn2);
        btn2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    new Room();
                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }
            }
        });

        JButton btn3 = new JButton("DEPARTMENT");
        btn3.setBounds(260,23,200,30);
        btn3.setBackground(new Color(246,215,118));
        panel.add(btn3);
        btn3.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new Department();
            }
        });

        JButton btn4 = new JButton("PATIENT INFO");
        btn4.setBounds(260,75,200,30);
        btn4.setBackground(new Color(246,215,118));
        panel.add(btn4);
        btn4.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new AllPatient_info();
            }
        });

        JButton btn5 = new JButton("SEARCH ROOM");
        btn5.setBounds(490,23,200,30);
        btn5.setBackground(new Color(246,215,118));
        panel.add(btn5);
        btn5.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new SearchRoom();
            }
        });

        JButton btn6 = new JButton("HOSPITAL AMBULANCE");
        btn6.setBounds(490,75,200,30);
        btn6.setBackground(new Color(246,215,118));
        panel.add(btn6);
        btn6.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new Ambulance();
            }
        });

        JButton btn7 = new JButton("LOGOUT");
        btn7.setBounds(740,45,200,30);
        btn7.setFont(new Font("Tahoma", Font.BOLD,16));
        btn7.setBackground(new Color(246, 34, 34));
        btn7.setForeground(Color.white);
        panel.add(btn7);
        btn7.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new user_login();
                Window window =
                SwingUtilities.getWindowAncestor(btn7);
                window.dispose();
            }
        });


        ImageIcon imageIcon2 = new ImageIcon(ClassLoader.getSystemResource("icon/userappoint.jpg"));
        Image image = imageIcon2.getImage().getScaledInstance(1950,1090, Image.SCALE_SMOOTH);
        ImageIcon scaledIcon = new ImageIcon(image);
        JLabel label1 = new JLabel(scaledIcon);
        label1.setHorizontalAlignment(JLabel.CENTER);
        label1.setVerticalAlignment(JLabel.CENTER);
        setLayout(new BorderLayout());
        add(label1, BorderLayout.CENTER);
        setSize(1950,1090);
        setVisible(true);

    }

    public static void main(String[] args) {
        new Appointment();
    }
}
