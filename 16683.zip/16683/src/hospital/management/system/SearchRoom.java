package hospital.management.system;

import net.proteanit.sql.DbUtils;

import javax.swing.*;
import javax.xml.transform.Result;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;

public class SearchRoom extends JFrame {

         Choice choice;
         JTable table;

         SearchRoom(){

             JPanel panel = new JPanel();
             panel.setBounds(5,5,690,490);
             panel.setBackground(new Color(111,241,171));
             panel.setLayout(null);
             add(panel);

             JLabel label = new JLabel("SEARCH FOR ROOM");
             label.setBounds(230,11,300,20);
             label.setFont(new Font("Tahoma",Font.BOLD,20));
             label.setForeground(Color.red);
             panel.add(label);

             JLabel status = new JLabel("Check:");
             status.setBounds(150,73,80,20);
             status.setFont(new Font("Tahoma",Font.BOLD,15));
             status.setForeground(new Color(15, 16, 18));
             panel.add(status);

             choice = new Choice();
             choice.setBounds(350,73,120,20);
             choice.add("Available");
             choice.add("Occupied");
             choice.setFont(new Font("Tahoma",Font.BOLD,13));
             choice.setForeground(Color.black);
             panel.add(choice);

             table = new JTable();
             table.setBounds(5,187,700,210);
             table.setBackground(new Color(111,241,171));
             table.setFont(new Font("Tahoma", Font.BOLD,13));
             table.setForeground(Color.black);
             panel.add(table);

             try{
                 md c = new md();
                 String q = "select * from room";
                 ResultSet resultSet = c.statement.executeQuery(q);
                 table.setModel(DbUtils.resultSetToTableModel(resultSet));

             }catch (Exception E){
                 E.printStackTrace();
             }

             JLabel label1 = new JLabel("Room No");
             label1.setBounds(10,160,80,15);
             label1.setFont(new Font( "Tahoma", Font.BOLD,15));
             label1.setForeground(Color.red);
             panel.add(label1);

             JLabel label2 = new JLabel("Status");
             label2.setBounds(180,160,90,15);
             label2.setFont(new Font( "Tahoma", Font.BOLD,15));
             label2.setForeground(Color.red);
             panel.add(label2);

             JLabel label3 = new JLabel("Price");
             label3.setBounds(350,160,90,15);
             label3.setFont(new Font( "Tahoma", Font.BOLD,15));
             label3.setForeground(Color.red);
             panel.add(label3);

             JLabel label4 = new JLabel("Bed Type");
             label4.setBounds(530,160,80,15);
             label4.setFont(new Font( "Tahoma", Font.BOLD,15));
             label4.setForeground(Color.red);
             panel.add(label4);

             JButton search = new JButton("SERCH");
             search.setBounds(180,420,120,30);
             search.setBackground(Color.black);
             search.setForeground(Color.white);
             panel.add(search);
             search.addActionListener(new ActionListener() {
                 @Override
                 public void actionPerformed(ActionEvent e) {
                     String q = "select * from Room where Avaliability = '"+choice.getSelectedItem()+"'";
                     try{
                         md c = new md();
                         ResultSet resultSet = c.statement.executeQuery(q);
                         table.setModel(DbUtils.resultSetToTableModel(resultSet));

                     }catch (Exception E){
                         E.printStackTrace();
                     }
                 }
             });

             JButton back = new JButton("BACK");
             back.setBounds(380,420,120,30);
             back.setBackground(Color.black);
             back.setForeground(Color.white);
             panel.add(back);
             back.addActionListener(new ActionListener() {
                 @Override
                 public void actionPerformed(ActionEvent e) {
                     setVisible(false);
                 }
             });

             setUndecorated(true);
             setSize(700,500);
             getContentPane().setBackground(new Color(161, 49, 236));
             setLayout(null);
             setLocation(450,200);
             setVisible(true);

         }

    public static void main(String[] args) {
        new SearchRoom();
    }
}

