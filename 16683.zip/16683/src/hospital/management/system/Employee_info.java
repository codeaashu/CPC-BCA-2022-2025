package hospital.management.system;

import net.proteanit.sql.DbUtils;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;

public class Employee_info extends JFrame {

    Employee_info(){

        JPanel panel = new JPanel();
        panel.setBounds(5,5,990,590);
        panel.setBackground(new Color(111,241,171));
        panel.setLayout(null);
        add(panel);

        JTable table = new JTable();
        table.setBounds(8,65,970,350);
        table.setBackground(new Color(111,241,171));
        table.setFont(new Font("Tahoma", Font.BOLD,13));
        panel.add(table);

        try{
            md c = new md();
            String q = "select * from EMP_INFO";
            ResultSet resultSet = c.statement.executeQuery(q);
            table.setModel(DbUtils.resultSetToTableModel(resultSet));
        }catch (Exception e){
            e.printStackTrace();
        }
        JLabel label1 = new JLabel("Name");
        label1.setBounds(10,25,70,25);
        label1.setFont(new Font("Tahoma", Font.BOLD,15));
        label1.setForeground(Color.red);
        panel.add(label1);

        JLabel label2 = new JLabel("Age");
        label2.setBounds(200,25,70,25);
        label2.setFont(new Font("Tahoma", Font.BOLD,15));
        label2.setForeground(Color.red);
        panel.add(label2);

        JLabel label3 = new JLabel("Phone_No");
        label3.setBounds(400,25,100,25);
        label3.setFont(new Font("Tahoma", Font.BOLD,15));
        label3.setForeground(Color.red);
        panel.add(label3);

        JLabel label4 = new JLabel("Aadhar_No");
        label4.setBounds(590,25,100,25);
        label4.setFont(new Font("Tahoma", Font.BOLD,15));
        label4.setForeground(Color.red);
        panel.add(label4);

        JLabel label5 = new JLabel("Salary");
        label5.setBounds(780,25,100,25);
        label5.setFont(new Font("Tahoma", Font.BOLD,15));
        label5.setForeground(Color.red);
        panel.add(label5);

        JButton back = new JButton("BACK");
        back.setBounds(420,450,120,30);
        back.setBackground(Color.BLACK);
        back.setForeground(Color.WHITE);
        panel.add(back);
        back.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
            }
        });
        setUndecorated(true);
        setSize(1000,600);
        getContentPane().setBackground(new Color(161, 49, 236));
        setLocation(310,200);
        setLayout(null);
        setVisible(true);
    }

    public static void main(String[] args) {
        new Employee_info();
    }


}
