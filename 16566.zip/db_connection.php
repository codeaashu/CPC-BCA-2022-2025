<?php
$host = "sql304.infinityfree.com"; // from cPanel
$user = "if0_39483364";   // your username
$pass = "HsWMoHYwklOX1rM";    // DB password
$db   = "if0_39483364_threadup"; // your DB name

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>

