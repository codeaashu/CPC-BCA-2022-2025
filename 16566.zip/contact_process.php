<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = htmlspecialchars(trim($_POST["name"]));
    $email = htmlspecialchars(trim($_POST["email"]));
    $message = htmlspecialchars(trim($_POST["message"]));

    // Optional: Validate email format
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        header("Location: contact.php?success=0");
        exit;
    }

    // ✅ Option 1: Save to database
    // include("db.php");
    // $stmt = $conn->prepare("INSERT INTO contact_messages (name, email, message) VALUES (?, ?, ?)");
    // $stmt->bind_param("sss", $name, $email, $message);
    // $stmt->execute();
    // $stmt->close();

    // ✅ Option 2: Send Email (uncomment this if you want mail)
    // mail("support@threadup.com", "New Contact Message", "From: $name <$email>\n\n$message");

    header("Location: contact.php?success=1");
    exit;
} else {
    header("Location: contact.php");
    exit;
}
?>
