<?php
session_start();
include("db_connection.php");

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

error_reporting(E_ALL);
ini_set('display_errors', 1);

// Handle Delete
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    mysqli_query($conn, "DELETE FROM tailors WHERE id = $id");
    header("Location: manage_tailors.php");
    
}

// Fetch Tailors
$search = isset($_GET['search']) ? $_GET['search'] : '';
$query = "SELECT * FROM tailors WHERE name LIKE '%$search%' ORDER BY created_at DESC";
$result = mysqli_query($conn, $query);

// Count Cards
$total = mysqli_fetch_row(mysqli_query($conn, "SELECT COUNT(*) FROM tailors"))[0];
$approved = mysqli_fetch_row(mysqli_query($conn, "SELECT COUNT(*) FROM tailors WHERE status='approved'"))[0];
$pending = mysqli_fetch_row(mysqli_query($conn, "SELECT COUNT(*) FROM tailors WHERE status='pending'"))[0];
$topRated = mysqli_fetch_row(mysqli_query($conn, "SELECT COUNT(*) FROM tailors WHERE rating >= 4.5"))[0];
?>

<?php include("header.php"); ?>

<div class="container mt-5">
  <h2 class="text-center mb-4">Manage Tailors</h2>

  <!-- Summary Cards -->
  <div class="row mb-4 text-white">
    <div class="col-md-3">
      <div class="card bg-primary">
        <div class="card-body text-center">
          <h5>Total Tailors</h5>
          <h3><?= $total ?></h3>
        </div>
      </div>
    </div>
    <div class="col-md-3">
      <div class="card bg-success">
        <div class="card-body text-center">
          <h5>Approved</h5>
          <h3><?= $approved ?></h3>
        </div>
      </div>
    </div>
    <div class="col-md-3">
      <div class="card bg-warning">
        <div class="card-body text-center">
          <h5>Requested</h5>
          <h3><?= $pending ?></h3>
        </div>
      </div>
    </div>
    <div class="col-md-3">
      <div class="card bg-info">
        <div class="card-body text-center">
          <h5>Top Rated (4.5+)</h5>
          <h3><?= $topRated ?></h3>
        </div>
      </div>
    </div>
  </div>

  <!-- Search + Export -->
  <div class="d-flex justify-content-between mb-3">
    <form method="GET" class="d-flex">
      <input type="text" name="search" class="form-control me-2" placeholder="Search Tailor" value="<?= htmlspecialchars($search) ?>">
      <button type="submit" class="btn btn-dark">Search</button>
    </form>
    <div>
      <a href="export_tailors_csv.php" class="btn btn-success me-2">Export CSV</a>
      <a href="export_tailors_pdf.php" class="btn btn-danger">Export PDF</a>
    </div>
  </div>

  <!-- Tailor Table -->
  <div class="table-responsive bg-white p-3 shadow-sm rounded">
    <table class="table table-bordered align-middle text-center">
      <thead class="table-dark">
        <tr>
          <th>Image</th>
          <th>Name</th>
          <th>Email</th>
          <th>Contact</th>
          <th>Specialty</th>
          <th>Status</th>
          <th>Rating</th>
          <th>Joined On</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php while ($row = mysqli_fetch_assoc($result)) { ?>
          <tr>
            <td>
              <?php if (!empty($row['image'])): ?>
                <img src="uploads/<?= htmlspecialchars($row['image']) ?>" class="rounded-circle" width="50" height="50" alt="Tailor Image">
              <?php else: ?>
                <img src="assets/default-profile.png" class="rounded-circle" width="50" height="50" alt="Default">
              <?php endif; ?>
            </td>
            <td><?= htmlspecialchars($row['name']) ?></td>
            <td><?= htmlspecialchars($row['email']) ?></td>
            <td><?= htmlspecialchars($row['contact']) ?></td>
            <td><?= htmlspecialchars($row['specialty']) ?></td>
            <td><span class="badge bg-<?= $row['status'] == 'approved' ? 'success' : 'warning' ?>"><?= ucfirst($row['status']) ?></span></td>
            <td><?= number_format($row['rating'], 1) ?></td>
            <td><?= date('d M Y', strtotime($row['created_at'])) ?></td>
            <td>
              <a href="edit_tailor.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-primary">Edit</a>
              <a href="?delete=<?= $row['id'] ?>" onclick="return confirm('Are you sure to delete this tailor?')" class="btn btn-sm btn-danger">Delete</a>
            </td>
          </tr>
        <?php } ?>
      </tbody>
    </table>
  </div>
</div>

<?php include("footer.php"); ?>
