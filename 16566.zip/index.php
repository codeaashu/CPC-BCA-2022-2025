<?php include("header.php"); ?>
<main class="homepage-wrapper">

  <!-- HERO Section with background image grid -->
  <section class="hero-wrapper">
    <div class="background-grid">
      <?php
        $images = ['1.jpg', '2.jpg', 'img3.jpg', 'img2.jpg', 'i.jpg', 'img1.avif'];
        for ($i = 0; $i < 12; $i++) {
          echo '<img src="assets/' . $images[$i % count($images)] . '" alt="Tailoring image">';
        }
      ?>
    </div>

  <div class="hero-content text-center">
      <div class="welcome-card">
        <h1 class="typewriter-text">Welcome to ThreadUp</h1>
        <p class="lead">Your one-stop platform for custom tailoring.</p>
        <a href="home.php" class="btn btn-primary rounded-pill mt-3">Explore</a>
      </div>
    </div>
  </section>

<!-- Typewriter Script -->
  <script>
    new Typed('.typewriter', {
      strings: ['Welcome to ThreadUp', 'Custom Tailoring', 'Crafted for You'],
      typeSpeed: 50,
      backSpeed: 30,
      loop: true
    });
  </script>
  <style>
  /* HERO wrapper */
.hero-wrapper {
  position: relative;
  height: 100vh;
  overflow: hidden;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 2rem;
}

/* Background image grid */
.background-grid {
  position: absolute;
  top: 0;
  left: 0;
  height: 150%;
  width: 100%;
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  grid-auto-rows: 25%;
  gap: 8px;
  opacity: 0.3;
  z-index: 0;
  padding: 10px;
}

.background-grid img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  border-radius: 6px;
}

/* Welcome text */
.hero-content {
  position: relative;
  z-index: 2;
}

.welcome-card {
  background: rgba(255, 255, 255, 0.95);
  padding: 2rem;
  border-radius: 12px;
  box-shadow: 0 6px 20px rgba(0,0,0,0.1);
  max-width: 600px;
  margin: 0 auto;
}

.typewriter-text {
  font-size: 2.2rem;
  font-weight: bold;
  color: #3a1c71;
}

/* Map Section */
.map-section {
  padding: 2rem 1rem;
  background: #fff;
}

.map-container iframe {
  width: 90%;
  max-width: 800px;
  height: 250px;
  border-radius: 10px;
  box-shadow: 0 4px 12px rgba(0,0,0,0.15);
  border: none;
}

/* Mobile */
@media (max-width: 768px) {
  .background-grid {
    grid-template-columns: repeat(2, 1fr);
    grid-auto-rows: 30%;
  }

  .welcome-card {
    padding: 1.2rem;
  }
}
</style>
</main>
<?php include("footer.php"); ?>
