<?php
session_start();
include("db_connection.php");

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name     = trim($_POST['name']);
    $email    = trim($_POST['email']);
    $phone    = trim($_POST['phone']);
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    // Basic validation (optional: can be expanded)
    if (empty($name) || empty($email) || empty($phone) || empty($_POST['password'])) {
        echo "<script>alert('❌ All fields are required'); window.location.href='customer_signup.php';</script>";
        exit();
    }

    // Check if email already exists
    $check = $conn->prepare("SELECT id FROM customers WHERE email = ?");
    $check->bind_param("s", $email);
    $check->execute();
    $check->store_result();

    if ($check->num_rows > 0) {
        echo "<script>alert('⚠️ Email already registered'); window.location.href='customer_signup.php';</script>";
        exit();
    }

    $stmt = $conn->prepare("INSERT INTO customers (name, email, password, phone) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $name, $email, $password, $phone);

    if ($stmt->execute()) {
        $_SESSION['user_id'] = $conn->insert_id;
        $_SESSION['name'] = $name;
        $_SESSION['role'] = 'customer';
        header("Location: customer_dashboard.php");
        exit();
    } else {
        echo "<script>alert('❌ Error: " . $stmt->error . "'); window.location.href='customer_signup.php';</script>";
    }
}
?>
