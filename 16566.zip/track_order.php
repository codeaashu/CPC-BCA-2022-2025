<?php include("header.php"); ?>
<div class="container mt-5">
  <h2 class="text-center text-primary mb-4">Track Your Orders</h2>

  <!-- Order 1 -->
  <div class="order-card">
    <h5 class="fw-bold mb-2">Ravi Tailors - Men's Formal (2025-07-02)</h5>
    <div class="progress-timeline">
      <div class="step done">Placed</div>
      <div class="step done">Accepted</div>
      <div class="step active">In Progress</div>
      <div class="step">Delivered</div>
    </div>
  </div>

  <!-- Order 2 -->
  <div class="order-card">
    <h5 class="fw-bold mb-2">Neha Stitching - Alterations (2025-07-01)</h5>
    <div class="progress-timeline">
      <div class="step done">Placed</div>
      <div class="step done">Accepted</div>
      <div class="step done">In Progress</div>
      <div class="step done">Delivered</div>
    </div>
  </div>

  <!-- Order 3 -->
  <div class="order-card">
    <h5 class="fw-bold mb-2">Modern Tailors - Women's Traditional (2025-07-03)</h5>
    <div class="progress-timeline">
      <div class="step done">Placed</div>
      <div class="step">Accepted</div>
      <div class="step">In Progress</div>
      <div class="step">Delivered</div>
    </div>
  </div>
</div>
<?php include("footer.php"); ?>
<style>
.order-card {
  background: #fff;
  border-radius: 12px;
  box-shadow: 0 4px 16px rgba(0,0,0,0.1);
  padding: 20px;
  margin-bottom: 30px;
  border-left: 6px solid #3a1c71;
}

.progress-timeline {
  display: flex;
  justify-content: space-between;
  position: relative;
  margin-top: 10px;
  padding-top: 10px;
}
.progress-timeline::before {
  content: "";
  position: absolute;
  top: 18px;
  left: 0;
  width: 100%;
  height: 4px;
  background-color: #e0e0e0;
  z-index: 0;
}
.step {
  position: relative;
  z-index: 1;
  text-align: center;
  flex: 1;
  font-size: 14px;
  font-weight: bold;
  color: #aaa;
}
.step::before {
  content: "";
  width: 18px;
  height: 18px;
  background: #bbb;
  border-radius: 50%;
  display: block;
  margin: 0 auto 8px;
  transition: background 0.4s ease;
}
.step.done {
  color: green;
}
.step.done::before {
  background: green;
}
.step.active {
  color: #ff9800;
}
.step.active::before {
  background: #ff9800;
}
</style>