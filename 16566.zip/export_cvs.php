<?php
include 'db_connection.php';
header('Content-Type: text/csv');
header('Content-Disposition: attachment; filename=bookings.csv');

$output = fopen("php://output", "w");
fputcsv($output, ['Customer', 'Service', 'Status', 'Contact']);

$result = mysqli_query($conn, "SELECT * FROM bookings");
while ($row = mysqli_fetch_assoc($result)) {
    fputcsv($output, [$row['customer_name'], $row['service'], $row['status'], $row['contact']]);
}
fclose($output);
exit;
