<?php include("header.php"); ?>

<div class="profile-box container mt-5" style="max-width: 600px; background: white; padding: 2rem; border-radius: 12px; box-shadow: 0 5px 18px rgba(0, 0, 0, 0.1);">
  <h2 class="text-primary text-center mb-4">Edit Your Profile</h2>
  <form method="post" action="update_profile.php">
    <div class="mb-3">
      <label class="form-label">Full Name</label>
      <input type="text" name="name" class="form-control" value="Customer Name" required />
    </div>
    <div class="mb-3">
      <label class="form-label">Email</label>
      <input type="email" name="email" class="form-control" value="email@example.com" required />
    </div>
    <div class="mb-3">
      <label class="form-label">Phone</label>
      <input type="text" name="phone" class="form-control" value="9876543210" />
    </div>
    <div class="mb-3">
      <label class="form-label">Change Password</label>
      <input type="password" name="password" class="form-control" placeholder="Leave blank to keep current" />
    </div>
    <div class="d-grid">
      <button type="submit" class="btn btn-primary rounded-pill">Update Profile</button>
    </div>
  </form>
</div>

<?php include("footer.php"); ?>


<!-- <!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <title>Edit Profile - ThreadUp</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background-color: #fffdfd;
      font-family: 'Segoe UI', sans-serif;
      padding: 2rem;
    }

    .profile-box {
      max-width: 600px;
      margin: auto;
      background: white;
      border-radius: 12px;
      box-shadow: 0 5px 18px rgba(0, 0, 0, 0.1);
      padding: 2rem;
    }

    h2 {
      text-align: center;
      color: #3a1c71;
      margin-bottom: 1.5rem;
    }

    .btn-primary {
      background-color: #3a1c71;
      border: none;
      border-radius: 30px;
      font-weight: bold;
    }

    .btn-primary:hover {
      background-color: #822e91;
    }
  </style>
</head>

<body>
  <header style="background: #3a1c71; padding: 1rem;">
    <nav class="container d-flex justify-content-between align-items-center text-white">
      <h3 class="m-0">ThreadUp</h3>
      <ul class="nav">
        <li class="nav-item"><a class="nav-link text-white" href="index.html">Home</a></li>
        <li class="nav-item"><a class="nav-link text-white" href="about.html">About</a></li>
        <li class="nav-item"><a class="nav-link text-white" href="services.html">Services</a></li>
        <li class="nav-item"><a class="nav-link text-white" href="tailors.html">Tailors</a></li>
        <li class="nav-item"><a class="nav-link text-white" href="contact.html">Contact</a></li>
        <li class="nav-item"><a class="nav-link text-white" href="login.html">Login</a></li>
        <li class="nav-item"><a class="nav-link text-white" href="signup.html">Sign Up</a></li>
      </ul>
    </nav>
  </header>

  <div class="profile-box">
    <h2>Edit Your Profile</h2>
    <form>
      <div class="mb-3">
        <label class="form-label">Full Name</label>
        <input type="text" class="form-control" value="Customer Name" required />
      </div>
      <div class="mb-3">
        <label class="form-label">Email</label>
        <input type="email" class="form-control" value="email@example.com" required />
      </div>
      <div class="mb-3">
        <label class="form-label">Phone</label>
        <input type="text" class="form-control" value="9876543210" />
      </div>
      <div class="mb-3">
        <label class="form-label">Change Password</label>
        <input type="password" class="form-control" placeholder="Leave blank to keep current" />
      </div>
      <div class="d-grid">
        <button class="btn btn-primary">Update Profile</button>
      </div>
    </form>
  </div>
  <footer class="text-center p-4 mt-5" style="background: #3a1c71; color: white;">
    <p>&copy; 2025 ThreadUp. All rights reserved.</p>
  </footer>

</body>

</html> -->