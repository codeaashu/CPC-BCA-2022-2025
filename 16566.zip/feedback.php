<?php
session_start();
if ($_SESSION['role'] !== 'customer') {
    header("Location: /ThreadUp/login.php");
    exit;
}
include("header.php");
include("db_connection.php");
?>

<div class="container-fluid mt-5 mb-5" role="main" aria-label="ThreadUp Feedback">
    <!-- <div class="background-images" aria-hidden="true" aria-label="Tailors working in background">
        <div class="image-grid">
            <img src="/ThreadUp/assets/1.jpg" alt="Close-up sewing machine stitching" />
            <img src="/ThreadUp/assets/2.jpg" alt="Colorful folded fabrics on shelf" />
            <img src="/ThreadUp/assets/img3.jpg" alt="Tailor cutting fabric with scissors" />
            <img src="/ThreadUp/assets/img2.jpg" alt="Fashion sketch on paper" />
            <img src="/ThreadUp/assets/i.jpg" alt="Tailor sewing by hand with needle" />
            <img src="/ThreadUp/assets/img1.avif" alt="Pattern drafting for tailor" />
            <img src="/ThreadUp/assets/img3.jpg" alt="Tailoring tools and equipment layout" />
            <img src="/ThreadUp/assets/img2.jpg" alt="Fashion sketch on paper" />
            <img src="/ThreadUp/assets/2.jpg" alt="Colorful folded fabrics on shelf" />
            <img src="/ThreadUp/assets/1.jpg" alt="Close-up sewing machine stitching" />
            <img src="/ThreadUp/assets/2.jpg" alt="Colorful folded fabrics on shelf" />
            <img src="/ThreadUp/assets/i.jpg" alt="Tailor measuring cloth on table" />
        </div>
    </div> -->
    <section class="welcome-card" tabindex="0">
        <h1 class="section-title text-primary fw-bold">Submit Feedback</h1>
        <p class="lead text-center">Share your experience with us.</p>
        <form action="/ThreadUp/feedback_submit.php" method="POST">
            <div class="mb-3">
                <select name="rating" class="form-select" required>
                    <option value="">Select Rating</option>
                    <option value="5">⭐ 5</option>
                    <option value="4">⭐ 4</option>
                    <option value="3">⭐ 3</option>
                    <option value="2">⭐ 2</option>
                    <option value="1">⭐ 1</option>
                </select>
            </div>
            <div class="mb-3">
                <textarea name="comment" class="form-control" placeholder="Your Feedback" rows="5" required></textarea>
            </div>
            <div class="d-grid">
                <button type="submit" class="btn btn-primary">Submit</button>
            </div>
        </form>
    </section>
</div>

<?php include("footer.php"); ?>
<?php $conn->close(); ?>

<style>
.background-images {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    z-index: -1;
    overflow: hidden;
}
.image-grid {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    grid-template-rows: repeat(3, 1fr);
    gap: 5px;
    width: 100%;
    height: 100%;
}
.image-grid img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    opacity: 0.5;
    filter: brightness(0.7);
}
.welcome-card {
    position: relative;
    z-index: 1;
    background: rgba(255, 255, 255, 0.9);
    padding: 20px;
    border-radius: 10px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    max-width: 500px;
    margin: 20px auto;
}
.section-title { color: #3a1c71; font-size: 2rem; margin-bottom: 1rem; }
.lead { color: #666; }
.form-select, .form-control { border-color: #ddd; }
.btn-primary { background: #3a1c71; border: none; }
.btn-primary:hover { background: #2a1357; }
@media (max-width: 768px) {
    .image-grid { grid-template-columns: repeat(2, 1fr); }
    .welcome-card { margin: 10px; }
}
</style>