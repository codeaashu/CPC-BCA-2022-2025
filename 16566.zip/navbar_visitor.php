<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <a class="navbar-brand" href="/ThreadUp/index.php">ThreadUp</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ms-auto">
            <li class="nav-item"><a class="nav-link" href="/ThreadUp/index.php">Home</a></li>
            <li class="nav-item"><a class="nav-link" href="/ThreadUp/about.php">About</a></li>
            <li class="nav-item"><a class="nav-link" href="/ThreadUp/services.php">Services</a></li>
            <li class="nav-item"><a class="nav-link" href="/ThreadUp/tailors.php">Tailors</a></li>
            <li class="nav-item"><a class="nav-link" href="/ThreadUp/contact.php">Contact</a></li>
            <li class="nav-item"><a class="nav-link" href="/ThreadUp/login.php">Login</a></li>
            <li class="nav-item"><a class="nav-link" href="/ThreadUp/signup.php">Sign Up</a></li>
        </ul>
    </div>
</nav>