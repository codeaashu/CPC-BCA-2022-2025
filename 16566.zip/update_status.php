<?php
session_start();
include("db_connection.php");

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'tailor') {
    header("Location: login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $booking_id = $_POST['booking_id'];
    $status = $_POST['status'];
    $tailor_id = $_SESSION['user_id'];

    // Check if the booking is assigned to this tailor
    $check = mysqli_query($conn, "SELECT * FROM bookings WHERE id = '$booking_id' AND tailor_id = '$tailor_id'");

    if (mysqli_num_rows($check) === 1) {
        $update = mysqli_query($conn, "UPDATE bookings SET status = '$status' WHERE id = '$booking_id'");
        $_SESSION['msg'] = "✅ Booking status updated to '$status'.";
    } else {
        $_SESSION['msg'] = "❌ Unauthorized access or booking not found.";
    }

    header("Location: tailor_bookings.php");
    exit();
}
?>
