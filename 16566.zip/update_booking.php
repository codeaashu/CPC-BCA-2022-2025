<?php
session_start();
include("db_connection.php");

// Ensure tailor is logged in
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'tailor') {
  header("Location: login.html");
  exit;
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
  $booking_id = $_POST['booking_id'];
  $status = $_POST['action']; // accepted or rejected

  // Update status
  $update = "UPDATE bookings SET status='$status' WHERE id='$booking_id'";
  if (mysqli_query($conn, $update)) {
    echo "<script>alert('Booking status updated'); window.location.href='tailor_bookings.php';</script>";
  } else {
    echo "Error: " . mysqli_error($conn);
  }
}
?>
