<?php
include("db_connection.php");

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $booking_id = $_POST['booking_id'];
    $file = $_FILES['work_file'];

    if ($file['error'] === 0) {
        $filename = time() . '_' . basename($file['name']);
        $destination = 'uploads/' . $filename;

        if (move_uploaded_file($file['tmp_name'], $destination)) {
            mysqli_query($conn, "UPDATE bookings SET completed_work_image = '$filename', status = 'completed' WHERE id = $booking_id");
        }
    }
}
header("Location: tailor_bookings.php");
exit;
