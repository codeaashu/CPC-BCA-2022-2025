<?php
session_start();
include("db.php");

if ($_SESSION['role'] !== 'admin') {
  header("Location: login.html");
  exit;
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
  $user_id = $_POST['user_id'];

  // Prevent admin from deleting themselves
  if ($user_id == $_SESSION['user_id']) {
    echo "<script>alert('You cannot delete yourself!'); window.location.href='admin_users.php';</script>";
    exit;
  }

  $query = "DELETE FROM users WHERE id='$user_id'";
  if (mysqli_query($conn, $query)) {
    echo "<script>alert('User deleted successfully'); window.location.href='admin_users.php';</script>";
  } else {
    echo "Error: " . mysqli_error($conn);
  }
}
?>
