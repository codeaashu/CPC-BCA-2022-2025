<?php include("header.php"); ?>

<main class="container py-5" role="main" aria-label="ThreadUp Book Service">
    <section class="text-center mb-5">
        <h1 class="text-primary fw-bold">Book a Service</h1>
        <p class="lead">Schedule your tailoring appointment.</p>
    </section>

    <section class="mx-auto" style="max-width: 500px;">
        <form action="/ThreadUp/book_service_submit.php" method="POST" class="shadow p-4 rounded-4 bg-white">
            <div class="mb-3">
                <label class="form-label fw-semibold">Select Tailor</label>
                <select name="tailor" class="form-select rounded-pill" required>
                    <option value="">-- Choose Tailor --</option>
                    <option value="1">Ravi Tailors</option>
                    <option value="2">Neha Stitching</option>
                    <option value="3">Modern Tailors</option>
                </select>
            </div>
            <div class="mb-3">
                <label class="form-label fw-semibold">Select Service</label>
                <select name="service" class="form-select rounded-pill" required>
                    <option value="">-- Choose Service --</option>
                    <option value="mens_formal">Men's Formal Stitching</option>
                    <option value="womens_traditional">Women's Traditional Wear</option>
                    <option value="alterations">Alterations</option>
                    <option value="urgent">Urgent Stitching</option>
                </select>
            </div>
            <div class="mb-3">
                <label class="form-label fw-semibold">Preferred Date</label>
                <input type="date" name="date" class="form-control rounded-pill text-center" required>
            </div>
            <div class="d-grid">
                <button type="submit" class="btn btn-primary rounded-pill">Book Now</button>
            </div>
        </form>
    </section>
</main>

<?php include("footer.php"); ?>
