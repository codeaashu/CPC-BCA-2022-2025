<?php
session_start();
include("db.php");

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
  header("Location: login.php");
  exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['customer_id'])) {
  $id = intval($_POST['customer_id']);

  $delete = mysqli_query($conn, "DELETE FROM users WHERE id = $id AND role='customer'");

  if ($delete) {
    header("Location: admin_customers.php");
    exit;
  } else {
    echo "❌ Error: " . mysqli_error($conn);
  }
}
?>
