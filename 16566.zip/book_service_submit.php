<?php
session_start();
include("db_connection.php");

// Check login and role
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'customer') {
    header("Location: login.php");
    exit();
}

$customer_id = $_SESSION['user_id'];
$customer_name = $_SESSION['name'];

$tailor_id = $_POST['tailor'];
$service = $_POST['service'];
$date = $_POST['date'];
$status = 'placed';

// Optional: Fetch tailor name for record
$tailor_result = mysqli_query($conn, "SELECT name FROM users WHERE id = '$tailor_id' AND role = 'tailor'");
$tailor = mysqli_fetch_assoc($tailor_result);
$tailor_name = $tailor ? $tailor['name'] : 'Unknown';

$query = "INSERT INTO bookings (customer_id, customer_name, tailor_id, tailor_name, service, date, status)
          VALUES ('$customer_id', '$customer_name', '$tailor_id', '$tailor_name', '$service', '$date', '$status')";

if (mysqli_query($conn, $query)) {
    echo "<script>alert('Booking placed successfully!'); window.location.href='customer/index.php';</script>";
} else {
    echo "<script>alert('Booking failed: " . mysqli_error($conn) . "'); window.location.href='book_service.php';</script>";
}
?>
