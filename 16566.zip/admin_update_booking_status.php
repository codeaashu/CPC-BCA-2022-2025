<?php
session_start();
include("db.php");

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
  header("Location: login.php");
  exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $booking_id = intval($_POST['booking_id']);
  $status = mysqli_real_escape_string($conn, $_POST['status']);

  $update = mysqli_query($conn, "UPDATE bookings SET status='$status' WHERE id=$booking_id");

  if ($update) {
    header("Location: admin_bookings.php");
    exit;
  } else {
    echo "❌ Error: " . mysqli_error($conn);
  }
}
?>
