<?php
session_start();
include("db_connection.php");

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'tailor') {
  header("Location: login.html");
  exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $id = $_POST['booking_id'];
  $new_status = $_POST['new_status'];

  $query = "UPDATE bookings SET status='$new_status' WHERE id='$id'";
  if (mysqli_query($conn, $query)) {
    echo "<script>alert('Status updated to $new_status'); window.location.href='tailor_orders.php';</script>";
  } else {
    echo "Error: " . mysqli_error($conn);
  }
}
?>
