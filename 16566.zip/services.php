<?php include("header.php"); ?>
<!-- <div class="sidebar">
    <nav class="nav flex-column">
        <a class="nav-link" href="/ThreadUp/home.php">Home</a>
        <a class="nav-link" href="/ThreadUp/about.php">About</a>
        <a class="nav-link" href="/ThreadUp/services.php">Services</a>
        <a class="nav-link" href="/ThreadUp/contact.php">Contact</a>
        <a class="nav-link" href="/ThreadUp/login.php">Login</a>
        <a class="nav-link" href="/ThreadUp/signup.php">Sign Up</a>
        <a class="nav-link" href="/ThreadUp/tailors.php">Tailors</a>
        <a class="nav-link" href="/ThreadUp/reviews.php">Reviews</a>
    </nav>
</div> -->
<div class="container-fluid" role="main" aria-label="ThreadUp Services">
    <h1 class="page-heading" style="text-center">WELCOME TO SERVICES</h1>
    <!-- <div class="background-images" aria-hidden="true" aria-label="Tailors working in background">
        <img src="/ThreadUp/assets/1.jpg" alt="Close-up sewing machine stitching" />
        <img src="/ThreadUp/assets/2.jpg" alt="Colorful folded fabrics on shelf" />
        <img src="/ThreadUp/assets/img3.jpg" alt="Tailor cutting fabric with scissors" />
        <img src="/ThreadUp/assets/img2.jpg" alt="Fashion sketch on paper" />
        <img src="/ThreadUp/assets/i.jpg" alt="Tailor sewing by hand with needle" />
        <img src="/ThreadUp/assets/img1.avif" alt="Pattern drafting for tailor" />
        <img src="/ThreadUp/assets/img3.jpg" alt="Tailoring tools and equipment layout" />
        <img src="/ThreadUp/assets/img2.jpg" alt="Fashion sketch on paper" />
        <img src="/ThreadUp/assets/2.jpg" alt="Colorful folded fabrics on shelf" />
        <img src="/ThreadUp/assets/1.jpg" alt="Close-up sewing machine stitching" />
        <img src="/ThreadUp/assets/2.jpg" alt="Colorful folded fabrics on shelf" />
        <img src="/ThreadUp/assets/i.jpg" alt="Tailor measuring cloth on table" />
    </div> -->
    <section class="section" tabindex="0">
        <h1 class="section-title text-primary fw-bold"><span class="typewriter">Our Tailoring Services</span></h1>
        <p class="lead text-center">High-quality tailoring at your fingertips.</p>
    </section>
    <section class="section">
        <h2 class="section-title text-primary">Choose Your Category</h2>
        <div class="row g-4">
            <div class="col-md-4">
                <div class="card service-card">
                    <div class="card-body">
                        <h5>👔 Mens Wear</h5>
                        <p>Shirts, suits, trousers—custom-fit options.</p>
                        <a href="/ThreadUp/book_service.php?category=mens" class="btn btn-primary">Book Now</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card service-card">
                    <div class="card-body">
                        <h5>👗 Womens Wear</h5>
                        <p>Lehengas, blouses, sarees—stylish designs.</p>
                        <a href="/ThreadUp/book_service.php?category=womens" class="btn btn-primary">Book Now</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card service-card">
                    <div class="card-body">
                        <h5>👶 Kids Wear</h5>
                        <p>Dresses, shirts, outfits for boys & girls.</p>
                        <a href="/ThreadUp/book_service.php?category=kids" class="btn btn-primary">Book Now</a>
                    </div>
                </div>
            </div>
            <div class="card service-card mx-2">
                <div class="card-body">
                    <h5>🪡 Alterations</h5>
                    <p>Quick resizing and adjustments for a perfect fit.</p>
                    <a href="/ThreadUp/book_service.php" class="btn btn-primary">Book Now</a>
                </div>
            </div>
            <div class="card service-card mx-2">
                <div class="card-body">
                    <h5>⚡ Urgent Stitching</h5>
                    <p>Same-day or 2-day delivery for urgent needs.</p>
                    <a href="/ThreadUp/book_service.php" class="btn btn-primary">Book Now</a>
                </div>
            </div>
        </div>
    </section>
    <section class="section">
        <h2 class="section-title text-primary">Fabric & Customization</h2>
        <p class="text-center">Choose from cotton, silk, linen, and more. Select colors and stitching styles (e.g.,
            straight, embroidered).</p>
        <div class="text-center mt-4">
            <a href="/ThreadUp/book_service.php" class="btn btn-primary rounded-pill">Customize Now</a>
        </div>
    </section>
</div>
<script>
    new Typed('.typewriter', {
        strings: ['Our Tailoring Services', 'Custom Stitching', 'Crafted for You'],
        typeSpeed: 50,
        backSpeed: 30,
        loop: true
    });
</script>
<?php include("footer.php"); ?>
<!--<div class="container-fluid" role="main" aria-label="ThreadUp Services">
    <div class="background-images" aria-hidden="true" aria-label="Tailors working in background">
        <img src="/ThreadUp/assets/1.jpg" alt="Close-up sewing machine stitching" />
        <img src="/ThreadUp/assets/2.jpg" alt="Colorful folded fabrics on shelf" />
        <img src="/ThreadUp/assets/img3.jpg" alt="Tailor cutting fabric with scissors" />
        <img src="/ThreadUp/assets/img2.jpg" alt="Fashion sketch on paper" />
        <img src="/ThreadUp/assets/i.jpg" alt="Tailor sewing by hand with needle" />
        <img src="/ThreadUp/assets/img1.avif" alt="Pattern drafting for tailor" />
        <img src="/ThreadUp/assets/img3.jpg" alt="Tailoring tools and equipment layout" />
        <img src="/ThreadUp/assets/img2.jpg" alt="Fashion sketch on paper" />
        <img src="/ThreadUp/assets/2.jpg" alt="Colorful folded fabrics on shelf" />
        <img src="/ThreadUp/assets/1.jpg" alt="Close-up sewing machine stitching" />
        <img src="/ThreadUp/assets/2.jpg" alt="Colorful folded fabrics on shelf" />
        <img src="/ThreadUp/assets/i.jpg" alt="Tailor measuring cloth on table" />
    </div>
    <section class="welcome-card" tabindex="0">
        <h1 class="section-title text-primary fw-bold">Our Tailoring Services</h1>
        <p class="lead text-center">High-quality tailoring at your fingertips.</p>
        <div class="slider" style="overflow: hidden;">
            <div class="slider-track">
                <div class="card service-card mx-2">
                    <div class="card-body">
                        <h5>👔 Men's Formal Stitching</h5>
                        <p>Custom-fit shirts, suits, and pants crafted with precision.</p>
                        <a href="/ThreadUp/book_service.php" class="btn btn-primary">Book Now</a>
                    </div>
                </div>
                <div class="card service-card mx-2">
                    <div class="card-body">
                        <h5>👗 Women's Traditional Wear</h5>
                        <p>Lehengas, blouses, and saree pleats tailored to perfection.</p>
                        <a href="/ThreadUp/book_service.php" class="btn btn-primary">Book Now</a>
                    </div>
                </div>
                
            </div>
        </div>
    </section>
</div>
 -->