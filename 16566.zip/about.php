<?php include("header.php"); ?>
<div style="position: relative; z-index: 1;">

  <!-- Section: About ThreadUp -->
  <section style="padding: 4rem 2rem; background-color: rgba(255,255,255,0.95); position: relative; z-index: 2;">
    <div style="background: url('/ThreadUp/assets/about-bg.jpg') no-repeat center center/cover; opacity: 0.2; position: absolute; inset: 0; z-index: -1;"></div>
    <h1 style="text-align:center; color: #3a1c71; font-weight: bold;">About ThreadUp</h1>
    <p style="max-width: 900px; margin: auto; font-size: 1.2rem; text-align: center; color: #333;">
      ThreadUp is a modern tailoring platform designed to bridge the gap between customers and professional tailors.
      We focus on quality stitching, convenience, and trust. With features like doorstep pickup, real-time tracking, and tailor profiles,
      we empower both customers and tailors to thrive in the digital age.
    </p>
  </section>

  <!-- Section: Milestones Timeline -->
  <section style="padding: 4rem 2rem; background-color: #f7f7f7; position: relative;">
    <h2 style="text-align:center; color: #3a1c71; font-weight: bold;">Our Journey</h2>
    <ul style="list-style: none; max-width: 900px; margin: 2rem auto; padding: 0; position: relative;">
      <li style="margin-bottom: 2rem; position: relative;">
        <div style="background: #3a1c71; color: white; padding: 1rem; border-radius: 8px;">
          <strong>2023:</strong> ThreadUp idea born during a college project.
        </div>
      </li>
      <li style="margin-bottom: 2rem; position: relative;">
        <div style="background: #d76d77; color: white; padding: 1rem; border-radius: 8px;">
          <strong>2024:</strong> Platform launched with 10 tailors and 200+ users.
        </div>
      </li>
      <li style="margin-bottom: 2rem; position: relative;">
        <div style="background: #ffaf7b; color: black; padding: 1rem; border-radius: 8px;">
          <strong>2025:</strong> Reached 1000+ customers and expanded to 3 cities.
        </div>
      </li>
    </ul>
  </section>

  <!-- Section: Animated Counters -->
  <section style="padding: 4rem 2rem; background-color: white; text-align: center;">
    <h2 style="color: #3a1c71; font-weight: bold;">Our Achievements</h2>
    <div style="display: flex; justify-content: center; gap: 3rem; flex-wrap: wrap; margin-top: 2rem;">
      <div>
        <h1 style="font-size: 3rem; color: #3a1c71;" id="tailorsCount">0+</h1>
        <p>Verified Tailors</p>
      </div>
      <div>
        <h1 style="font-size: 3rem; color: #3a1c71;" id="customersCount">0+</h1>
        <p>Satisfied Customers</p>
      </div>
      <div>
        <h1 style="font-size: 3rem; color: #3a1c71;" id="ordersCount">0+</h1>
        <p>Orders Delivered</p>
      </div>
    </div>
  </section>

  <!-- Section: Team (optional) -->
  <section style="padding: 4rem 2rem; background-color: #f7f7f7; text-align: center;">
    <h2 style="color: #3a1c71; font-weight: bold;">Meet Our Team</h2>
    <div style="display: flex; justify-content: center; gap: 2rem; flex-wrap: wrap; margin-top: 2rem;">
      <div style="max-width: 200px;">
        <img src="/ThreadUp/assets/team1.jpg" alt="Founder" style="width: 100%; border-radius: 50%;">
        <h5 style="margin-top: 1rem;">Varsha Kumari</h5>
        <p>Founder & Developer</p>
      </div>
      <!-- Add more team members here -->
    </div>
  </section>

  <!-- Section: Testimonials Carousel -->
  <section style="padding: 4rem 2rem; background-color: white;">
    <h2 style="color: #3a1c71; font-weight: bold; text-align: center;">What Our Users Say</h2>
    <div id="testimonialCarousel" class="carousel slide mt-4" data-bs-ride="carousel" style="max-width: 700px; margin:auto;">
      <div class="carousel-inner">
        <div class="carousel-item active">
          <blockquote class="blockquote text-center">
            <p class="mb-0">"ThreadUp helped me find a tailor in minutes. The stitching was perfect!"</p>
            <footer class="blockquote-footer mt-0">Pooja Singh (Customer)</footer>
          </blockquote>
        </div>
        <div class="carousel-item">
          <blockquote class="blockquote text-center">
            <p class="mb-0">"As a tailor, this platform gave me visibility and trust with new clients."</p>
            <footer class="blockquote-footer mt-0">Ravi Tailor</footer>
          </blockquote>
        </div>
        <!-- Add more testimonials here -->
      </div>
      <button class="carousel-control-prev" type="button" data-bs-target="#testimonialCarousel" data-bs-slide="prev">
        <span class="carousel-control-prev-icon"></span>
      </button>
      <button class="carousel-control-next" type="button" data-bs-target="#testimonialCarousel" data-bs-slide="next">
        <span class="carousel-control-next-icon"></span>
      </button>
    </div>
  </section>

</div>

<script>
  // Counter Animation
  function animateCount(id, target) {
    let count = 0;
    const interval = setInterval(() => {
      if (count < target) {
        count++;
        document.getElementById(id).innerText = count + "+";
      } else {
        clearInterval(interval);
      }
    }, 20);
  }

  window.onload = () => {
    animateCount("tailorsCount", 120);
    animateCount("customersCount", 950);
    animateCount("ordersCount", 1800);
  };
</script>
<?php include("footer.php"); ?>
