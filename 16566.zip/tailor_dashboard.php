<?php
session_start();
include("db_connection.php");

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'tailor') {
    header("Location: /login.php");
    exit();
}

$tailor_id = $_SESSION['user_id'];

// Fetch tailor name & image
$query = mysqli_query($conn, "SELECT name, profile_image FROM tailors WHERE id = '$tailor_id'");
$tailor = mysqli_fetch_assoc($query);
$name = $tailor['name'];
$imagePath = !empty($tailor['profile_image']) ? 'uploads/profile_images/' . $tailor['profile_image'] : 'assets/images/default_avatar.png';

// Booking statistics
$total_q = mysqli_query($conn, "SELECT COUNT(*) AS total FROM bookings WHERE tailor_id = '$tailor_id'");
$completed_q = mysqli_query($conn, "SELECT COUNT(*) AS completed FROM bookings WHERE tailor_id = '$tailor_id' AND status = 'Completed'");
$pending_q = mysqli_query($conn, "SELECT COUNT(*) AS pending FROM bookings WHERE tailor_id = '$tailor_id' AND status = 'Pending'");

$total = mysqli_fetch_assoc($total_q)['total'];
$completed = mysqli_fetch_assoc($completed_q)['completed'];
$pending = mysqli_fetch_assoc($pending_q)['pending'];
?>

<?php include("header.php"); ?>

<div class="container my-5">
    <!-- Welcome Header -->
    <div class="row align-items-center mb-4">
        <div class="col-md-8">
            <h2 class="fw-bold text-dark">Welcome, <span class="text-primary"><?php echo htmlspecialchars($name); ?></span> ✂️</h2>
            <p class="text-muted">Manage your tailoring services, track bookings, and update your profile easily.</p>
        </div>
        <div class="col-md-4 text-end">
            <img src="<?php echo $imagePath; ?>" alt="Profile" class="rounded-circle shadow" style="width: 80px; height: 80px; object-fit: cover;">
        </div>
    </div>

    <!-- Summary Cards -->
    <div class="row g-4 mb-4">
        <div class="col-md-4">
            <div class="card text-white bg-primary shadow h-100">
                <div class="card-body text-center">
                    <h5 class="card-title">📦 Total Bookings</h5>
                    <h3 class="fw-bold"><?php echo $total; ?></h3>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card text-white bg-success shadow h-100">
                <div class="card-body text-center">
                    <h5 class="card-title">✅ Completed Orders</h5>
                    <h3 class="fw-bold"><?php echo $completed; ?></h3>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card text-white bg-warning shadow h-100">
                <div class="card-body text-center">
                    <h5 class="card-title">⏳ Pending Orders</h5>
                    <h3 class="fw-bold"><?php echo $pending; ?></h3>
                </div>
            </div>
        </div>
    </div>

    <!-- Actions -->
    <div class="row g-4">
        <div class="col-md-6">
            <div class="card h-100 shadow-sm border-0 hover-shadow">
                <div class="card-body text-center">
                    <h5 class="card-title fw-semibold">📋 View Bookings</h5>
                    <p class="card-text">Check your assigned orders and update their statuses.</p>
                    <a href="tailor_bookings.php" class="btn btn-outline-primary">View Bookings</a>
                </div>
            </div>
        </div>

        <div class="col-md-6">
            <div class="card h-100 shadow-sm border-0 hover-shadow">
                <div class="card-body text-center">
                    <h5 class="card-title fw-semibold">🧵 Edit Profile</h5>
                    <p class="card-text">Update your contact info, skills, and location.</p>
                    <a href="tailor_profile.php" class="btn btn-outline-success">Edit Profile</a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include("footer.php"); ?>
