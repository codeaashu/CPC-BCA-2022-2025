<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Custom tailoring platform.">
    <meta name="keywords" content="tailoring, stitching, suits, bridal wear, men, women, custom clothing">
    <title>ThreadUp - Custom Tailoring</title>

    <!-- CSS -->
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

    <!-- JS -->
    <script src="js/slider.js" defer></script>
    <script src="https://unpkg.com/typed.js@2.0.16/dist/typed.umd.js" defer></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" defer></script>
</head>

<body>
    <header class="main-header">
        <nav class="navbar navbar-expand-lg navbar-dark" style="background: linear-gradient(90deg, #3a1c71, #d76d77);">
            <div class="container">
                <a class="navbar-brand fw-bold" href="index.php">ThreadUp</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                    aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav ms-auto">
                        <?php
                        $role = $_SESSION['role'] ?? 'visitor';

                        if ($role === 'admin') {
                            echo '
                                <li class="nav-item"><a class="nav-link" href="admin_dashboard.php">Dashboard</a></li>
                                <li class="nav-item"><a class="nav-link" href="reports.php">Reports</a></li>
                                <li class="nav-item"><a class="nav-link" href="logout.php">Logout</a></li>
                            ';
                        } elseif ($role === 'customer') {
                            echo '
                                <li class="nav-item"><a class="nav-link" href="customer_dashboard.php">Dashboard</a></li>
                                <li class="nav-item"><a class="nav-link" href="book_service.php">Book Service</a></li>
                                <li class="nav-item"><a class="nav-link" href="track_order.php">Track Orders</a></li>
                                <li class="nav-item"><a class="nav-link" href="feedback.php">Feedback</a></li>
                                <li class="nav-item"><a class="nav-link" href="logout.php">Logout</a></li>
                            ';
                        } elseif ($role === 'tailor') {
                            echo '
                                <li class="nav-item"><a class="nav-link" href="tailor_profile.php">Dashboard</a></li>
                                <li class="nav-item"><a class="nav-link" href="tailor_bookings.php">My Bookings</a></li>
                                <li class="nav-item"><a class="nav-link" href="logout.php">Logout</a></li>
                            ';
                        } else {
                            echo '
                                <li class="nav-item"><a class="nav-link" href="home.php">Home</a></li>
                                <li class="nav-item"><a class="nav-link" href="about.php">About</a></li>
                                <li class="nav-item"><a class="nav-link" href="services.php">Services</a></li>
                                <li class="nav-item"><a class="nav-link" href="tailors.php">Tailors</a></li>
                                <li class="nav-item"><a class="nav-link" href="contact.php">Contact</a></li>
                                <li class="nav-item"><a class="nav-link" href="login.php">Login</a></li>
                                <li class="nav-item"><a class="nav-link" href="signup.php">Sign Up</a></li>
                            ';
                        }
                        ?>
                    </ul>
                </div>
            </div>
        </nav>
    </header>

    <main>
