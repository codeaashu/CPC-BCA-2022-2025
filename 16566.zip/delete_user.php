<?php
session_start();
if ($_SESSION['role'] !== 'admin') {
    header("Location: /ThreadUp/login.php");
    exit;
}
include("db_connect.php");
$user_id = $_GET['id'] ?? 0;
$conn->query("DELETE FROM users WHERE id = $user_id");
header("Location: /ThreadUp/admin_dashboard.php");
?>