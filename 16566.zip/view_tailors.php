<?php include("header.php"); ?>

<h2 class="text-center my-5 text-primary fw-bold">Available Tailors</h2>

<div class="container mb-5">
 <div class="row g-4">
        <!-- Tailor 1 -->
        <div class="col-md-4">
            <div class="card h-100 shadow-sm">
                <img src="assets/tailor1.jpg" class="card-img-top" alt="Tailor Ravi">
                <div class="card-body">
                    <h5 class="card-title text-primary">Ravi Tailors</h5>
                    <p class="card-text">Men's Formal Specialist<br><strong>Location:</strong> Boring Road</p>
                    <p>⭐ 4.8 (120 reviews)</p>
                    <a href="/ThreadUp/tailor_profile.php?id=1" class="btn btn-primary w-100">View Profile</a>
                </div>
            </div>
        </div>
        <!-- Tailor 2 -->
        <div class="col-md-4">
            <div class="card h-100 shadow-sm">
                <img src="assets/tailor2.jpg" class="card-img-top" alt="Tailor Neha">
                <div class="card-body">
                    <h5 class="card-title text-primary">Neha Stitching</h5>
                    <p class="card-text">Bridal & Women's Wear<br><strong>Location:</strong> Kankarbagh</p>
                    <p>⭐ 4.7 (95 reviews)</p>
                    <a href="/ThreadUp/tailor_profile.php?id=2" class="btn btn-primary w-100">View Profile</a>
                </div>
            </div>
        </div>
        <!-- Tailor 3 -->
        <div class="col-md-4">
            <div class="card h-100 shadow-sm">
                <img src="assets/tailor3.jpg" class="card-img-top" alt="Tailor Modern">
                <div class="card-body">
                    <h5 class="card-title text-primary">Modern Tailors</h5>
                    <p class="card-text">Ethnic Wear Specialist<br><strong>Location:</strong> Rajendra Nagar</p>
                    <p>⭐ 4.6 (80 reviews)</p>
                    <a href="/ThreadUp/tailor_profile.php?id=3" class="btn btn-primary w-100">View Profile</a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include("footer.php"); ?>


<!-- <!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <title>View Tailors - ThreadUp</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background: #f0f0f5;
      font-family: 'Segoe UI', sans-serif;
      padding: 2rem;
    }

    .card {
      border-radius: 12px;
      box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
      transition: transform 0.3s ease;
    }

    .card:hover {
      transform: scale(1.03);
    }

    .card-title {
      color: #3a1c71;
      font-weight: bold;
    }

    .btn-custom {
      background-color: #3a1c71;
      color: white;
      border-radius: 20px;
    }

    .btn-custom:hover {
      background-color: #822e91;
    }
  </style>
</head>

<body>
  <header style="background: #3a1c71; padding: 1rem;">
    <nav class="container d-flex justify-content-between align-items-center text-white">
      <h3 class="m-0">ThreadUp</h3>
      <ul class="nav">
        <li class="nav-item"><a class="nav-link text-white" href="index.html">Home</a></li>
        <li class="nav-item"><a class="nav-link text-white" href="about.html">About</a></li>
        <li class="nav-item"><a class="nav-link text-white" href="services.html">Services</a></li>
        <li class="nav-item"><a class="nav-link text-white" href="tailors.html">Tailors</a></li>
        <li class="nav-item"><a class="nav-link text-white" href="contact.html">Contact</a></li>
        <li class="nav-item"><a class="nav-link text-white" href="login.html">Login</a></li>
        <li class="nav-item"><a class="nav-link text-white" href="signup.html">Sign Up</a></li>
      </ul>
    </nav>
  </header>

  <h2 class="text-center mb-4">Available Tailors</h2>

  <div class="container">
    <div class="row g-4">

      Tailor Card
      <div class="col-md-4">
        <div class="card p-3">
          <img src="assets/tailor1.jpg" class="card-img-top rounded" alt="Tailor Image">
          <div class="card-body">
            <h5 class="card-title">Ravi Tailors</h5>
            <p class="card-text">Men's formalwear specialist. 4.8⭐</p>
            <a href="book_service.html" class="btn btn-custom">Book Now</a>
          </div>
        </div>
      </div>

      Repeat similar cards
      <div class="col-md-4">
        <div class="card p-3">
          <img src="assets/tailor2.jpg" class="card-img-top rounded" alt="Tailor Image">
          <div class="card-body">
            <h5 class="card-title">Neha Stitching</h5>
            <p class="card-text">Women’s ethnic and bridal expert. 4.9⭐</p>
            <a href="book_service.html" class="btn btn-custom">Book Now</a>
          </div>
        </div>
      </div>

      

    </div>
  </div>
  <footer class="text-center p-4 mt-5" style="background: #3a1c71; color: white;">
    <p>&copy; 2025 ThreadUp. All rights reserved.</p>
  </footer>

</body>

</html> -->