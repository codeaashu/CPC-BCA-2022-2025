<?php
session_start();
include("db_connection.php");

// Redirect if not logged in or not a tailor
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'tailor') {
    header("Location: ../login.php");
    exit();
}

$tailor_id = $_SESSION['user_id'];

// Fetch tailor details
$tailor = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM tailors WHERE id = '$tailor_id'"));
?>

<?php include("header.php"); ?>

<div class="container my-5">
    <h2 class="text-center text-primary mb-4">Welcome, <?php echo htmlspecialchars($tailor['name']); ?> 👋</h2>

    <div class="card shadow-sm mb-4">
        <div class="card-header bg-primary text-white fw-bold">Your Profile</div>
        <div class="card-body">
            <p><strong>Email:</strong> <?php echo htmlspecialchars($tailor['email']); ?></p>
            <p><strong>Specialty:</strong> <?php echo htmlspecialchars($tailor['specialty']); ?></p>
            <p><strong>Location:</strong> <?php echo htmlspecialchars($tailor['location']); ?></p>
            <a href="edit_profile.php" class="btn btn-sm btn-outline-primary">Edit Profile</a>
        </div>
    </div>

    <div class="text-center">
        <a href="my_bookings.php" class="btn btn-primary">My Bookings</a>
    </div>
</div>

<?php include("footer.php"); ?>
