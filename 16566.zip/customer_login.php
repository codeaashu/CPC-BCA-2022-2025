<?php
session_start();
include("db_connection.php");

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = trim($_POST['email']);
    $password = $_POST['password'];

    // Prepare statement
    $stmt = $conn->prepare("SELECT id, name, password FROM customers WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();

    // Check if email exists
    if ($stmt->num_rows === 1) {
        $stmt->bind_result($id, $name, $hashed_password);
        $stmt->fetch();

        // Verify password
        if (password_verify($password, $hashed_password)) {
            $_SESSION['user_id'] = $id;
            $_SESSION['name'] = $name;
            $_SESSION['role'] = 'customer';
            header("Location: customer_dashboard.php");
            exit();
        } else {
            echo "<script>alert('❌ Incorrect password'); window.location.href='customer_login.php';</script>";
        }
    } else {
        echo "<script>alert('❌ No customer found with this email'); window.location.href='customer_login.php';</script>";
    }

    $stmt->close();
    $conn->close();
}
?>
