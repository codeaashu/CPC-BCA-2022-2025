<?php
include("db_connection.php");
header('Content-Type: application/json');

$type = $_GET['type'];

if ($type === 'status') {
    $data = [];
    $labels = [];
    $result = mysqli_query($conn, "SELECT status, COUNT(*) as count FROM bookings GROUP BY status");
    while ($row = mysqli_fetch_assoc($result)) {
        $labels[] = ucfirst($row['status']);
        $data[] = $row['count'];
    }
    echo json_encode(['labels' => $labels, 'values' => $data]);
}

if ($type === 'monthly') {
    $data = [];
    $labels = [];
    $result = mysqli_query($conn, "
        SELECT MONTH(created_at) AS month, COUNT(*) AS count
        FROM bookings
        WHERE YEAR(created_at) = YEAR(CURDATE())
        GROUP BY MONTH(created_at)
    ");
    $months = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
    $monthCounts = array_fill(1, 12, 0);
    while ($row = mysqli_fetch_assoc($result)) {
        $monthCounts[(int)$row['month']] = (int)$row['count'];
    }
    foreach ($monthCounts as $i => $val) {
        $labels[] = $months[$i - 1];
        $data[] = $val;
    }
    echo json_encode(['labels' => $labels, 'values' => $data]);
}
?>
