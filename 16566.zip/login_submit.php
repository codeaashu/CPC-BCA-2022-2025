<?php
session_start();
include("db_connection.php");

$email = $_POST['email'];
$password = $_POST['password'];

// Function to check login in a specific table
function attempt_login($conn, $table, $email, $password) {
    $stmt = $conn->prepare("SELECT * FROM $table WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();

        // If passwords are hashed, use password_verify instead
        if ($user['password'] === $password) {
            return $user;
        }
    }
    return false;
}

// Check in customers
$user = attempt_login($conn, 'customers', $email, $password);
if ($user) {
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['role'] = 'customer';
    header("Location: customer_dashboard.php");
    exit();
}

// Check in tailors
$user = attempt_login($conn, 'tailors', $email, $password);
if ($user) {
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['role'] = 'tailor';
    header("Location: tailor_dashboard.php");
    exit();
}

// Check in admins
$user = attempt_login($conn, 'admins', $email, $password);
if ($user) {
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['role'] = 'admin';
    header("Location: admin_dashboard.php");
    exit();
}

// If no match found
echo "<script>alert('Invalid email or password'); window.location.href='login.php';</script>";
?>
