<?php
include("header.php");
include("db_connect.php");
$order_id = $_GET['id'] ?? 1;
$order = $conn->query("SELECT b.*, u.name as tailor_name FROM bookings b JOIN users u ON b.tailor_id = u.id WHERE b.id = $order_id")->fetch_assoc();
?>
<div class="container-fluid" role="main" aria-label="ThreadUp Order Details">
    <div class="background-images" aria-hidden="true" aria-label="Tailors working in background">
        <img src="/ThreadUp/assets/1.jpg" alt="Close-up sewing machine stitching" />
        <img src="/ThreadUp/assets/2.jpg" alt="Colorful folded fabrics on shelf" />
        <img src="/ThreadUp/assets/img3.jpg" alt="Tailor cutting fabric with scissors" />
        <img src="/ThreadUp/assets/img2.jpg" alt="Fashion sketch on paper" />
        <img src="/ThreadUp/assets/i.jpg" alt="Tailor sewing by hand with needle" />
        <img src="/ThreadUp/assets/img1.avif" alt="Pattern drafting for tailor" />
        <img src="/ThreadUp/assets/img3.jpg" alt="Tailoring tools and equipment layout" />
        <img src="/ThreadUp/assets/img2.jpg" alt="Fashion sketch on paper" />
        <img src="/ThreadUp/assets/2.jpg" alt="Colorful folded fabrics on shelf" />
        <img src="/ThreadUp/assets/1.jpg" alt="Close-up sewing machine stitching" />
        <img src="/ThreadUp/assets/2.jpg" alt="Colorful folded fabrics on shelf" />
        <img src="/ThreadUp/assets/i.jpg" alt="Tailor measuring cloth on table" />
    </div>
    <section class="welcome-card" tabindex="0">
        <h1 class="section-title text-primary fw-bold">Order #<?php echo $order_id; ?></h1>
        <p class="lead text-center">Order Details</p>
        <div class="text-center">
            <p>Service: <?php echo $order['service'] ?? 'N/A'; ?></p>
            <p>Tailor: <?php echo $order['tailor_name'] ?? 'N/A'; ?></p>
            <p>Status: <?php echo $order['status'] ?? 'N/A'; ?></p>
            <a href="/ThreadUp/track_orders.php" class="btn btn-primary rounded-pill">Back to Orders</a>
        </div>
    </section>
</div>
<?php include("footer.php"); ?>