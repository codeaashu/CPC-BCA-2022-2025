<?php include("header.php"); ?>

<div class="container mt-5">
  <h2 class="text-primary text-center mb-4">Tailor List</h2>

  <table class="table table-bordered table-striped">
    <thead class="table-dark">
      <tr>
        <th>Name</th>
        <th>Email</th>
        <th>Specialty</th>
        <th>Status</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>Neha Tailors</td>
        <td>neha@threadup.com</td>
        <td>Bridal Wear</td>
        <td><span class="badge bg-success">Verified</span></td>
        <td><button class="btn btn-sm btn-warning">Revoke</button></td>
      </tr>
      <tr>
        <td>Ravi Stitch</td>
        <td>ravi@threadup.com</td>
        <td>Formal Shirts</td>
        <td><span class="badge bg-warning">Pending</span></td>
        <td><button class="btn btn-sm btn-success">Approve</button></td>
      </tr>
      <tr>
        <td>Elegant Fashion</td>
        <td>elegant@threadup.com</td>
        <td>Party Wear</td>
        <td><span class="badge bg-warning">Pending</span></td>
        <td><button class="btn btn-sm btn-success">Approve</button></td>
      </tr>
    </tbody>
  </table>
</div>

<?php include("footer.php"); ?>


<!-- <!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <title>Admin - Tailors</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background: #f5f9ff;
      font-family: 'Segoe UI', sans-serif;
      padding: 2rem;
    }

    h2 {
      color: #3a1c71;
      text-align: center;
      margin-bottom: 2rem;
    }

    .table {
      background: white;
      border-radius: 12px;
      overflow: hidden;
      box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
    }

    .btn-approve {
      background-color: #28a745;
      color: white;
      border-radius: 20px;
    }

    .btn-reject {
      background-color: #dc3545;
      color: white;
      border-radius: 20px;
    }

    .btn-block {
      background-color: #ffc107;
      color: black;
      border-radius: 20px;
    }
  </style>
</head>

<body>
  <header style="background: #3a1c71; padding: 1rem;">
    <nav class="container d-flex justify-content-between align-items-center text-white">
      <h3 class="m-0">ThreadUp</h3>
      <ul class="nav">
        <li class="nav-item"><a class="nav-link text-white" href="index.html">Home</a></li>
        <li class="nav-item"><a class="nav-link text-white" href="about.html">About</a></li>
        <li class="nav-item"><a class="nav-link text-white" href="services.html">Services</a></li>
        <li class="nav-item"><a class="nav-link text-white" href="tailors.html">Tailors</a></li>
        <li class="nav-item"><a class="nav-link text-white" href="contact.html">Contact</a></li>
        <li class="nav-item"><a class="nav-link text-white" href="login.html">Login</a></li>
        <li class="nav-item"><a class="nav-link text-white" href="signup.html">Sign Up</a></li>
      </ul>
    </nav>
  </header>

  <h2>Manage Tailor Accounts</h2>

  <div class="container">
    <table class="table table-bordered">
      <thead class="table-light">
        <tr>
          <th>Name</th>
          <th>Email</th>
          <th>Specialty</th>
          <th>Status</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>Ravi Tailors</td>
          <td>ravi@threadup.com</td>
          <td>Men's Formal</td>
          <td>Pending</td>
          <td>
            <button class="btn btn-sm btn-approve">Approve</button>
            <button class="btn btn-sm btn-reject">Reject</button>
          </td>
        </tr>
        <tr>
          <td>Neha Stitching</td>
          <td>neha@threadup.com</td>
          <td>Bridal Wear</td>
          <td>Approved</td>
          <td>
            <button class="btn btn-sm btn-block">Block</button>
          </td>
        </tr>
        Add more tailor rows
      </tbody>
    </table>
  </div>
  <footer class="text-center p-4 mt-5" style="background: #3a1c71; color: white;">
    <p>&copy; 2025 ThreadUp. All rights reserved.</p>
  </footer>

</body>

</html> -->