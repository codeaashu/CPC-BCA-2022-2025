<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
  <title>Analytics | Admin Panel</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
  <style>
    body { background-color: #fef6f2; font-family: 'Segoe UI', sans-serif; }
    .container { margin-left: 220px; padding: 40px; }
    .chart-box { background-color: #fff3e6; border-radius: 10px; padding: 30px; }
  </style>
</head>
<body>
  <div class="container">
    <h2><i class="fas fa-chart-pie"></i> Analytics Overview</h2>
    <div class="chart-box">
      <p>More detailed analytics and charts coming soon!</p>
    </div>
  </div>
</body>
</html>
