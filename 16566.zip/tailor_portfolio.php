<?php include("header.php"); ?>

<div class="container mt-5" style="max-width: 600px;">
  <h2 class="text-primary text-center mb-4">Upload Portfolio Images</h2>
  <form method="post" enctype="multipart/form-data">
    <div class="mb-3">
      <label class="form-label">Upload your best works</label>
      <input class="form-control" type="file" name="portfolio_images[]" multiple required>
    </div>
    <div class="d-grid">
      <button class="btn btn-primary rounded-pill">Upload</button>
    </div>
  </form>
</div>

<?php include("footer.php"); ?>

<!-- <!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <title>Upload Portfolio - Tailor Panel</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background: #fff7f7;
      font-family: 'Segoe UI', sans-serif;
      padding: 2rem;
    }

    .container {
      max-width: 600px;
      margin: auto;
      background: white;
      padding: 2rem;
      border-radius: 12px;
      box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
    }

    h2 {
      text-align: center;
      color: #3a1c71;
      margin-bottom: 1.5rem;
    }

    .btn-upload {
      background-color: #3a1c71;
      color: white;
      border-radius: 30px;
    }

    .btn-upload:hover {
      background-color: #822e91;
    }
  </style>
</head>

<body>
  <header style="background: #3a1c71; padding: 1rem;">
    <nav class="container d-flex justify-content-between align-items-center text-white">
      <h3 class="m-0">ThreadUp</h3>
      <ul class="nav">
        <li class="nav-item"><a class="nav-link text-white" href="index.html">Home</a></li>
        <li class="nav-item"><a class="nav-link text-white" href="about.html">About</a></li>
        <li class="nav-item"><a class="nav-link text-white" href="services.html">Services</a></li>
        <li class="nav-item"><a class="nav-link text-white" href="tailors.html">Tailors</a></li>
        <li class="nav-item"><a class="nav-link text-white" href="contact.html">Contact</a></li>
        <li class="nav-item"><a class="nav-link text-white" href="login.html">Login</a></li>
        <li class="nav-item"><a class="nav-link text-white" href="signup.html">Sign Up</a></li>
      </ul>
    </nav>
  </header>

  <div class="container">
    <h2>Upload Portfolio Images</h2>
    <form>
      <div class="mb-3">
        <label class="form-label">Upload your best works</label>
        <input class="form-control" type="file" multiple>
      </div>
      <div class="d-grid">
        <button class="btn btn-upload">Upload</button>
      </div>
    </form>
  </div>
  <footer class="text-center p-4 mt-5" style="background: #3a1c71; color: white;">
    <p>&copy; 2025 ThreadUp. All rights reserved.</p>
  </footer>

</body>

</html> -->