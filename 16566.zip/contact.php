<?php include("header.php"); ?>
<div class="container py-5" style="min-height: 100vh;">
    <h1 class="text-center section-title">Contact Us</h1>
    <p class="text-center mb-5">We'd love to hear from you! Get in touch using the form below.</p>

    <div class="row align-items-center g-5">
        <!-- 📝 Contact Form -->
        <div class="col-lg-6">
            <div class="p-4 shadow rounded-4 bg-white">
                <?php
                if (isset($_GET['success']) && $_GET['success'] == '1') {
                    echo '<div class="alert alert-success text-center rounded-pill">Thank you! Your message has been sent.</div>';
                }
                ?>

                <form action="/ThreadUp/contact_process.php" method="POST">
                    <div class="mb-3">
                        <input type="text" class="form-control rounded-pill" name="name" placeholder="Full Name"
                            required>
                    </div>
                    <div class="mb-3">
                        <input type="email" class="form-control rounded-pill" name="email" placeholder="Email Address"
                            required>
                    </div>
                    <div class="mb-3">
                        <textarea class="form-control rounded" name="message" rows="5" placeholder="Your Message"
                            required></textarea>
                    </div>
                    <div class="d-grid">
                        <button type="submit" class="btn btn-primary rounded-pill">Send Message</button>
                    </div>
                </form>
                <div class="mt-4 text-center small text-muted">
                    Email: <a href="mailto:support@threadup.com">support@threadup.com</a> |
                    Phone: +91 123-456-7890
                </div>
            </div>
        </div>

        <!-- 🖼️ Image Grid -->
        <div class="col-lg-6">
            <div class="row g-3">
                <div class="col-6">
                    <img src="/ThreadUp/assets/1.jpg" alt="Sewing Machine" class="img-fluid rounded shadow-sm">
                </div>
                <div class="col-6">
                    <img src="/ThreadUp/assets/img3.jpg" alt="Tailor Cutting" class="img-fluid rounded shadow-sm">
                </div>
                <div class="col-6">
                    <img src="/ThreadUp/assets/img2.jpg" alt="Sketch Design" class="img-fluid rounded shadow-sm">
                </div>
                <div class="col-6">
                    <img src="/ThreadUp/assets/i.jpg" alt="Hand Stitching" class="img-fluid rounded shadow-sm">
                </div>
            </div>
        </div>
    </div>
    
</div>
<?php include("footer.php"); ?>