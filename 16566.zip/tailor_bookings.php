<?php
include("db_connection.php");
session_start();
$tailor_id = $_SESSION['tailor_id'] ?? null;

if (!$tailor_id) {
    header("Location: tailor_login.php");
    exit;
}

$result = mysqli_query($conn, "SELECT * FROM bookings WHERE tailor_id = $tailor_id");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>My Bookings</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .status-bar {
            display: flex;
            gap: 10px;
            margin-top: 10px;
        }
        .status-step {
            flex: 1;
            height: 10px;
            background: #e0e0e0;
            border-radius: 5px;
            position: relative;
        }
        .status-step.active {
            background: #28a745;
        }
        .status-step::after {
            content: '';
            position: absolute;
            top: -6px;
            left: 50%;
            transform: translateX(-50%);
            width: 16px;
            height: 16px;
            border-radius: 50%;
            background: #28a745;
        }
    </style>
</head>
<body class="bg-light">

<div class="container py-4">
    <h2 class="mb-4 text-center">Tailor Bookings</h2>

    <?php while($row = mysqli_fetch_assoc($result)) {
        $status = strtolower($row['status']);
        $status_steps = ['pending', 'accepted', 'in progress', 'completed'];
    ?>
        <div class="card mb-4 shadow-sm">
            <div class="card-body">
                <h5 class="card-title">Customer: <?= htmlspecialchars($row['customer_name']) ?></h5>
                <p><strong>Service:</strong> <?= htmlspecialchars($row['service']) ?></p>
                <p><strong>Date:</strong> <?= htmlspecialchars($row['booking_date']) ?></p>

                <!-- Status progress bar -->
                <div class="status-bar">
                    <?php foreach ($status_steps as $step) { ?>
                        <div class="status-step <?= $status == $step || array_search($status, $status_steps) > array_search($step, $status_steps) ? 'active' : '' ?>">
                        </div>
                    <?php } ?>
                </div>
                <div class="d-flex justify-content-between mt-2 small">
                    <?php foreach ($status_steps as $step) { ?>
                        <span><?= ucfirst($step) ?></span>
                    <?php } ?>
                </div>

                <!-- Upload completed work -->
                <?php if ($status == 'in progress' || $status == 'completed') { ?>
                <form action="upload_completed_work.php" method="POST" enctype="multipart/form-data" class="mt-3">
                    <input type="hidden" name="booking_id" value="<?= $row['id'] ?>">
                    <div class="mb-2">
                        <label for="work_file_<?= $row['id'] ?>" class="form-label">Upload Completed Work (Image):</label>
                        <input class="form-control" type="file" name="work_file" id="work_file_<?= $row['id'] ?>" required>
                    </div>
                    <button type="submit" class="btn btn-success btn-sm">Upload</button>
                </form>
                <?php } ?>

                <!-- Show uploaded work -->
                <?php if (!empty($row['completed_work_image'])) { ?>
                    <div class="mt-3">
                        <label class="form-label">Completed Work:</label><br>
                        <img src="uploads/<?= htmlspecialchars($row['completed_work_image']) ?>" alt="Completed Work" style="max-width: 100%; height: auto;" class="rounded border">
                    </div>
                <?php } ?>
            </div>
        </div>
    <?php } ?>
</div>

</body>
</html>
