<?php include("header.php"); ?>

<div class="container mt-5">
  <h2 class="text-primary text-center mb-4">Manage Order Status</h2>

  <table class="table table-bordered table-striped">
    <thead class="table-dark">
      <tr>
        <th>Customer</th>
        <th>Service</th>
        <th>Date</th>
        <th>Current Status</th>
        <th>Update</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>Priya Sharma</td>
        <td>Blouse Stitching</td>
        <td>2025-07-10</td>
        <td><span class="badge bg-warning">Pending</span></td>
        <td>
          <select class="form-select form-select-sm">
            <option>Pending</option>
            <option>Accepted</option>
            <option>In Progress</option>
            <option>Ready</option>
            <option>Delivered</option>
          </select>
        </td>
      </tr>
      <tr>
        <td>Rahul Verma</td>
        <td>Kurta Alteration</td>
        <td>2025-07-05</td>
        <td><span class="badge bg-success">Delivered</span></td>
        <td>
          <select class="form-select form-select-sm" disabled>
            <option selected>Delivered</option>
          </select>
        </td>
      </tr>
      <tr>
        <td>Anjali Singh</td>
        <td>Lehenga Fitting</td>
        <td>2025-07-12</td>
        <td><span class="badge bg-info">In Progress</span></td>
        <td>
          <select class="form-select form-select-sm">
            <option>In Progress</option>
            <option>Ready</option>
            <option>Delivered</option>
          </select>
        </td>
      </tr>
    </tbody>
  </table>
</div>

<?php include("footer.php"); ?>


<!-- <!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <title>Update Order Status - Tailor Panel</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background-color: #fff3f5;
      font-family: 'Segoe UI', sans-serif;
      padding: 2rem;
    }

    .container {
      max-width: 700px;
      margin: auto;
      background: white;
      border-radius: 12px;
      padding: 2rem;
      box-shadow: 0 5px 20px rgba(0, 0, 0, 0.1);
    }

    h2 {
      color: #3a1c71;
      margin-bottom: 2rem;
      text-align: center;
    }

    .btn-primary {
      background-color: #3a1c71;
      border: none;
      border-radius: 30px;
    }

    .btn-primary:hover {
      background-color: #822e91;
    }
  </style>
</head>

<body>
  <header style="background: #3a1c71; padding: 1rem;">
    <nav class="container d-flex justify-content-between align-items-center text-white">
      <h3 class="m-0">ThreadUp</h3>
      <ul class="nav">
        <li class="nav-item"><a class="nav-link text-white" href="index.html">Home</a></li>
        <li class="nav-item"><a class="nav-link text-white" href="about.html">About</a></li>
        <li class="nav-item"><a class="nav-link text-white" href="services.html">Services</a></li>
        <li class="nav-item"><a class="nav-link text-white" href="tailors.html">Tailors</a></li>
        <li class="nav-item"><a class="nav-link text-white" href="contact.html">Contact</a></li>
        <li class="nav-item"><a class="nav-link text-white" href="login.html">Login</a></li>
        <li class="nav-item"><a class="nav-link text-white" href="signup.html">Sign Up</a></li>
      </ul>
    </nav>
  </header>

  <div class="container">
    <h2>Update Order Status</h2>
    <form>
      <div class="mb-3">
        <label class="form-label">Select Order</label>
        <select class="form-select" required>
          <option selected disabled>Choose order...</option>
          <option value="1">Priya Sharma - Blouse stitching</option>
          <option value="2">Ravi Kumar - Pants Alteration</option>
        </select>
      </div>

      <div class="mb-3">
        <label class="form-label">Status</label>
        <select class="form-select" required>
          <option selected disabled>Select status...</option>
          <option value="in-progress">In Progress</option>
          <option value="ready">Ready for Pickup</option>
          <option value="delivered">Delivered</option>
        </select>
      </div>

      <div class="d-grid">
        <button type="submit" class="btn btn-primary">Update Status</button>
      </div>
    </form>
  </div>
  <footer class="text-center p-4 mt-5" style="background: #3a1c71; color: white;">
    <p>&copy; 2025 ThreadUp. All rights reserved.</p>
  </footer>

</body>

</html> -->