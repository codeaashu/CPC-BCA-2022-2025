<header style="background: #3a1c71; padding: 1rem;">
  <nav class="container d-flex justify-content-between align-items-center text-white">
    <h3 class="m-0">ThreadUp</h3>
    <ul class="nav">
      <li class="nav-item"><a class="nav-link text-white" href="admin_dashboard.php">Dashboard</a></li>
      <li class="nav-item"><a class="nav-link text-white" href="admin_bookings.php">Bookings</a></li> 
      <li class="nav-item"><a class="nav-link text-white" href="admin_customers.php">Customers</a></li>
      <li class="nav-item"><a class="nav-link text-white" href="admin_tailors.php">Tailors</a></li>
      <li class="nav-item"><a class="nav-link" href="reports.php">Reports</a></li>
      <li class="nav-item"><a class="nav-link text-white" href="logout.php">Logout</a></li>
    </ul>
  </nav>
</header>
