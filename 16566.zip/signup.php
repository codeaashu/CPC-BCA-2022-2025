<?php include("header.php"); ?>
<div class="container-fluid" style="min-height: 100vh; display: flex; justify-content: center; align-items: center;">
    <div class="card p-4 shadow" style="width: 100%; max-width: 500px; border-radius: 16px; background: rgba(255,255,255,0.95);">
        <h3 class="text-center text-primary fw-bold mb-3">Sign Up</h3>
        <p class="text-center text-muted mb-4">Join ThreadUp today</p>

        <form action="signup_submit.php" method="POST" enctype="multipart/form-data">
            <!-- Name -->
            <div class="mb-3">
                <input type="text" name="name" class="form-control rounded-pill text-center" placeholder="Full Name" required />
            </div>

            <!-- Email -->
            <div class="mb-3">
                <input type="email" name="email" class="form-control rounded-pill text-center" placeholder="Email" required />
            </div>

            <!-- Password -->
            <div class="mb-3">
                <input type="password" name="password" class="form-control rounded-pill text-center" placeholder="Password" required />
            </div>

            <!-- Role Selector -->
            <div class="mb-3">
                <select name="role" id="role" class="form-select rounded-pill text-center" required>
                    <option value="">-- Select Role --</option>
                    <option value="customer">Customer</option>
                    <option value="tailor">Tailor</option>
                    <option value="admin">Admin</option>
                </select>
            </div>

            <!-- Specialty Input (Visible only for Tailor) -->
            <div class="mb-3" id="specialty-box" style="display: none;">
                <input type="text" name="specialty" class="form-control rounded-pill text-center" placeholder="Specialty (e.g., Blouse, Sherwani)" />
            </div>

            <!-- Profile Image Upload -->
            <div class="mb-3">
                <label class="form-label fw-semibold">Upload Profile Image</label>
                <input type="file" name="profile" class="form-control rounded-pill text-center" accept="image/*" required>
            </div>

            <!-- Submit Button -->
            <div class="d-grid mb-2">
                <button type="submit" class="btn btn-primary rounded-pill">Sign Up</button>
            </div>

            <!-- Login Link -->
            <div class="text-center mt-3">
                Already have an account? <a href="login.php" class="text-decoration-none text-primary fw-semibold">Login</a>
            </div>
        </form>
    </div>
</div>

<script>
// Show specialty input only if role is tailor
document.getElementById('role').addEventListener('change', function () {
    const specialtyBox = document.getElementById('specialty-box');
    if (this.value === 'tailor') {
        specialtyBox.style.display = 'block';
    } else {
        specialtyBox.style.display = 'none';
    }
});
</script>

<?php include("footer.php"); ?>
