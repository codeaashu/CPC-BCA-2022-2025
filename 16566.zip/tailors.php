<?php include("header.php"); ?>
<div class="container py-5" style="min-height: 100vh;">
    <h1 class="text-center section-title">Meet Our Tailors</h1>
    <p class="text-center mb-4">Browse and select skilled tailors by category, location, and rating.</p>

    <!-- 🔍 Filter Section -->
    <form class="row g-3 mb-5">
        <div class="col-md-4">
            <select class="form-select" name="category">
                <option selected>All Categories</option>
                <option value="mens">Men</option>
                <option value="womens">Women</option>
                <option value="bridal">Bridal</option>
                <option value="kids">Kids</option>
            </select>
        </div>
        <div class="col-md-4">
            <select class="form-select" name="location">
                <option selected>All Locations</option>
                <option value="boring">Boring Road</option>
                <option value="kankarbagh">Kankarbagh</option>
                <option value="rajendra">Rajendra Nagar</option>
            </select>
        </div>
        <div class="col-md-4">
            <select class="form-select" name="rating">
                <option selected>Minimum Rating</option>
                <option value="3">3 ★ & above</option>
                <option value="4">4 ★ & above</option>
                <option value="5">5 ★</option>
            </select>
        </div>
    </form>

    <!-- 👔 Tailor Cards -->
    <div class="row g-4">
        <!-- Tailor 1 -->
        <div class="col-md-4">
            <div class="card h-100 shadow-sm">
                <img src="assets/tailor1.jpg" class="card-img-top" alt="Tailor Ravi">
                <div class="card-body">
                    <h5 class="card-title text-primary">Ravi Tailors</h5>
                    <p class="card-text">Men's Formal Specialist<br><strong>Location:</strong> Boring Road</p>
                    <p>⭐ 4.8 (120 reviews)</p>
                    <a href="/ThreadUp/tailor_profile.php?id=1" class="btn btn-primary w-100">View Profile</a>
                </div>
            </div>
        </div>
        <!-- Tailor 2 -->
        <div class="col-md-4">
            <div class="card h-100 shadow-sm">
                <img src="assets/tailor2.jpg" class="card-img-top" alt="Tailor Neha">
                <div class="card-body">
                    <h5 class="card-title text-primary">Neha Stitching</h5>
                    <p class="card-text">Bridal & Women's Wear<br><strong>Location:</strong> Kankarbagh</p>
                    <p>⭐ 4.7 (95 reviews)</p>
                    <a href="/ThreadUp/tailor_profile.php?id=2" class="btn btn-primary w-100">View Profile</a>
                </div>
            </div>
        </div>
        <!-- Tailor 3 -->
        <div class="col-md-4">
            <div class="card h-100 shadow-sm">
                <img src="assets/tailor3.jpg" class="card-img-top" alt="Tailor Modern">
                <div class="card-body">
                    <h5 class="card-title text-primary">Modern Tailors</h5>
                    <p class="card-text">Ethnic Wear Specialist<br><strong>Location:</strong> Rajendra Nagar</p>
                    <p>⭐ 4.6 (80 reviews)</p>
                    <a href="/ThreadUp/tailor_profile.php?id=3" class="btn btn-primary w-100">View Profile</a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php include("footer.php"); ?>
