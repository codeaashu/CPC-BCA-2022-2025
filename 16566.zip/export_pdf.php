<?php
require_once __DIR__ . '/vendor/autoload.php';
include 'db_connection.php';

$html = '<h2>Bookings Report</h2><table border="1" cellpadding="5" cellspacing="0"><tr><th>Customer</th><th>Service</th><th>Status</th><th>Contact</th></tr>';
$result = mysqli_query($conn, "SELECT * FROM bookings");
while ($row = mysqli_fetch_assoc($result)) {
    $html .= "<tr><td>{$row['customer_name']}</td><td>{$row['service']}</td><td>{$row['status']}</td><td>{$row['contact']}</td></tr>";
}
$html .= '</table>';

$mpdf = new \Mpdf\Mpdf();
$mpdf->WriteHTML($html);
$mpdf->Output('bookings_report.pdf', 'D');
