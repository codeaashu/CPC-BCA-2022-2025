<?php include("header.php"); ?>

<main>
  <!-- Hero Section -->
  <section
    style="background: linear-gradient(to right, #3a1c71, #d76d77, #ffaf7b); color: white; padding: 5rem 1rem; text-align: center;">
    <div class="container">
      <h1 style="font-size: 3rem; font-weight: bold;">Tailoring That Comes to You</h1>
      <p style="font-size: 1.25rem; margin-top: 1rem;">Custom Stitching | Doorstep Pickup | Trusted Tailors</p>
      <a href="signup.php"
        style="display: inline-block; margin: 1rem 0.5rem; border-radius: 30px; padding: 0.6rem 1.5rem; background: #fff; color: #000; text-decoration: none;">Get
        Started</a>
      <a href="tailors.php"
        style="display: inline-block; margin: 1rem 0.5rem; border-radius: 30px; padding: 0.6rem 1.5rem; border: 2px solid #fff; color: #fff; text-decoration: none;">Browse
        Tailors</a>
    </div>
  </section>

  <!-- Tailor Work Gallery -->
 <section class="tailors-gallery-section">
  <h2 class="section-title">Tailors at Work</h2>
  <p class="section-subtitle text-center mb-4">Discover the craftsmanship and creativity of our talented tailors</p>

   <div class="filter-buttons text-center mb-4">
    <button class="filter-btn active" onclick="filterImages('all')">All</button>
    <button class="filter-btn" onclick="filterImages('men')">Men</button>
    <button class="filter-btn" onclick="filterImages('women')">Women</button>
    <button class="filter-btn" onclick="filterImages('bridal')">Bridal</button>
  </div>

  <!-- Image Grid -->
  <div class="tailor-work-grid">
    <img src="assets/1.jpg" alt="Men kurta stitching" class="filter-item men">
    <img src="assets/2.jpg" alt="Designer blouse" class="filter-item women">
    <img src="assets/img3.jpg" alt="Bridal gown" class="filter-item bridal">
    <img src="assets/img2.jpg" alt="Men formal suit" class="filter-item men">
    <img src="assets/i.jpg" alt="Saree work" class="filter-item women">
    <img src="assets/img1.avif" alt="Bridal lehenga" class="filter-item bridal">
    <img src="assets/img2.jpg" alt="Casual shirt" class="filter-item men">
    <img src="assets/i.jpg" alt="Wedding dress" class="filter-item bridal">
    <img src="assets/1.jpg" alt="Women gown" class="filter-item women">
  </div>
</section>

  <!-- How It Works Flowchart -->
  <section style="padding: 3rem 1rem;">
    <h2 style="text-align: center; color: #3a1c71; font-weight: bold; margin-bottom: 2rem;">How It Works</h2>
    <div style="display: flex; justify-content: center; align-items: center; flex-wrap: wrap; gap: 20px;">
      <div
        style="flex: 1 1 250px; text-align: center; padding: 1.5rem; border-radius: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.1); background: #fff; animation: slideUp 0.6s ease;">
        <h3>📅 Book a Tailor</h3>
        <p>Choose your tailor and service.</p>
      </div>
      <span style="font-size: 2rem; color: #3a1c71;">➡️</span>
      <div
        style="flex: 1 1 250px; text-align: center; padding: 1.5rem; border-radius: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.1); background: #fff; animation: slideUp 0.8s ease;">
        <h3>🧵 Get Measured</h3>
        <p>Upload sizes or schedule a visit.</p>
      </div>
      <span style="font-size: 2rem; color: #3a1c71;">➡️</span>
      <div
        style="flex: 1 1 250px; text-align: center; padding: 1.5rem; border-radius: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.1); background: #fff; animation: slideUp 1s ease;">
        <h3>🚚 Get It Delivered</h3>
        <p>Receive stitched clothes at home.</p>
      </div>
    </div>
  </section>

  <!-- Why Choose Us -->
  <section style="padding: 3rem 1rem; background-color: #f8f9fa;">
    <h2 style="text-align: center; color: #3a1c71; font-weight: bold; margin-bottom: 2rem;">Why Choose Us?</h2>
    <div style="display: flex; flex-wrap: wrap; justify-content: space-around; gap: 20px;">
      <div
        style="flex: 1 1 250px; background: white; padding: 2rem; border-radius: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.1); text-align: center;">
        <h3 style="font-size: 2rem;">🎯</h3>
        <h5>Quality Assurance</h5>
        <p>Only verified and experienced tailors for your garments.</p>
      </div>
      <div
        style="flex: 1 1 250px; background: white; padding: 2rem; border-radius: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.1); text-align: center;">
        <h3 style="font-size: 2rem;">⏱️</h3>
        <h5>On-Time Delivery</h5>
        <p>Stitched, pressed & delivered at your doorstep on time.</p>
      </div>
      <div
        style="flex: 1 1 250px; background: white; padding: 2rem; border-radius: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.1); text-align: center;">
        <h3 style="font-size: 2rem;">💰</h3>
        <h5>Affordable Pricing</h5>
        <p>Transparent charges with no hidden fees or extra costs.</p>
      </div>
    </div>
  </section>

  <!-- Testimonials Carousel -->
  <section style="padding: 3rem 1rem;">
    <h2 style="text-align: center; color: #3a1c71; font-weight: bold; margin-bottom: 2rem;">What Our Customers Say</h2>
    <div id="testimonial-box"
      style="max-width: 600px; margin: auto; text-align: center; background: #fff; padding: 2rem; border-radius: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.1); transition: 0.5s;">
      <p id="testimonial-text" style="font-style: italic; color: #555;">"Great service! The tailor picked up and
        delivered exactly on time."</p>
      <h6 id="testimonial-name" style="margin-top: 1rem; font-weight: bold; color: #3a1c71;">– Priya Sharma</h6>
    </div>
  </section>

  <script>
    const testimonials = [
      { text: '"Great service! The tailor picked up and delivered exactly on time."', name: '– Priya Sharma' },
      { text: '"The stitching quality is amazing. Highly recommended!"', name: '– Rahul Verma' },
      { text: '"Booking was easy, and the clothes fit perfectly."', name: '– Aditi Singh' }
    ];

    let index = 0;
    setInterval(() => {
      index = (index + 1) % testimonials.length;
      document.getElementById("testimonial-text").textContent = testimonials[index].text;
      document.getElementById("testimonial-name").textContent = testimonials[index].name;
    }, 4000);
 

  function filterImages(category) {
    const images = document.querySelectorAll('.filter-item');
    const buttons = document.querySelectorAll('.filter-btn');

    buttons.forEach(btn => btn.classList.remove('active'));
    event.target.classList.add('active');

    images.forEach(img => {
      if (category === 'all') {
        img.classList.remove('hide');
      } else {
        img.classList.toggle('hide', !img.classList.contains(category));
      }
    });
  }
</script>

</main>

<!-- Inline Keyframe Animation -->
<style>
  @keyframes slideUp {
    from {
      opacity: 0;
      transform: translateY(40px);
    }

    to {
      opacity: 1;
      transform: translateY(0);
    }
  }
</style>

<?php include("footer.php"); ?>

<style>
  .background-images {
    position: absolute;
    top: 0;
    left: 0;
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    grid-auto-rows: 200px;
    width: 100%;
    height: 500px;
    /* Limit height */
    gap: 8px;
    opacity: 0.4;
    z-index: -1;
    padding: 20px;
  }

  .background-images img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    border-radius: 10px;
    animation: fadeInUp 1.5s ease-in-out;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.2);
    filter: grayscale(10%) brightness(0.8);
  }

  @keyframes fadeInUp {
    from {
      opacity: 0;
      transform: translateY(20px);
    }

    to {
      opacity: 1;
      transform: translateY(0);
    }
  }


  .background-images img:nth-child(odd) {
    animation-delay: 0.3s;
  }

  .background-images img:nth-child(even) {
    animation-delay: 0.6s;
  }

  @keyframes fadeInUp {
    to {
      opacity: 1;
      transform: translateY(0);
    }
  }

  @media (max-width: 768px) {
    .background-images {
      grid-template-columns: repeat(2, 1fr);
      grid-auto-rows: 150px;
    }
  }
/* Section Styling */
.tailors-gallery-section {
  padding: 3rem 1rem;
  background: #fff;
}

.section-title {
  text-align: center;
  color: #3a1c71;
  font-size: 2.5rem;
  font-weight: 700;
  margin-bottom: 0.3rem;
}

.section-subtitle {
  font-size: 1.1rem;
  color: #666;
  margin-bottom: 2rem;
}

/* Filter Buttons */
.filter-buttons {
  margin-bottom: 1.5rem;
}

.filter-btn {
  background: #3a1c71;
  color: #fff;
  border: none;
  padding: 0.5rem 1.2rem;
  margin: 0 5px;
  border-radius: 25px;
  font-weight: 500;
  cursor: pointer;
  transition: background 0.3s ease;
}

.filter-btn:hover,
.filter-btn.active {
  background: #d76d77;
}

/* Image Grid */
.tailor-work-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(220px, 1fr));
  gap: 16px;
}

.tailor-work-grid img {
  width: 100%;
  height: 200px;
  object-fit: cover;
  border-radius: 12px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
  transition: transform 0.4s ease, opacity 0.3s ease;
}

.tailor-work-grid img:hover {
  transform: scale(1.05);
}

/* Hide items */
.filter-item {
  display: block;
}

.filter-item.hide {
  display: none;
}

  .tailors-gallery-section {
  padding: 3rem 1rem;
  background: #fff;
}

.tailors-gallery-section .section-title {
  text-align: center;
  color: #3a1c71;
  font-size: 2.5rem;
  font-weight: 700;
  margin-bottom: 0.5rem;
}

.section-subtitle {
  font-size: 1.1rem;
  color: #666;
  text-align: center;
  margin-bottom: 2rem;
}

.tailor-work-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(220px, 1fr));
  gap: 16px;
}

.tailor-work-grid img {
  width: 100%;
  height: 200px;
  object-fit: cover;
  border-radius: 12px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
  transition: transform 0.4s ease, box-shadow 0.3s ease;
}

.tailor-work-grid img:hover {
  transform: scale(1.05);
  box-shadow: 0 6px 18px rgba(0, 0, 0, 0.15);
}

</style>