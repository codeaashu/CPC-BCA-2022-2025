<?php
session_start();

// If already logged in as tailor, redirect to dashboard directly
if (isset($_SESSION['user_id']) && $_SESSION['role'] === 'tailor') {
    header("Location: tailor_dashboard.php");
    exit;
}

include("header.php");
?>

<div class="container mt-5" style="max-width: 420px;">
  <h2 class="text-center text-primary mb-4 fw-bold">Tailor Login</h2>
  <form action="tailor_login_submit.php" method="POST">
    <div class="mb-3">
      <input type="email" name="email" class="form-control rounded-pill" placeholder="Email" required />
    </div>
    <div class="mb-3">
      <input type="password" name="password" class="form-control rounded-pill" placeholder="Password" required />
    </div>
    <div class="d-grid mb-3">
      <button type="submit" class="btn btn-primary rounded-pill">Login</button>
    </div>
    <div class="text-center">
      Not registered? <a href="tailor_signup.php" class="text-decoration-none fw-semibold text-primary">Sign Up</a>
    </div>
  </form>
</div>

<?php include("footer.php"); ?>
