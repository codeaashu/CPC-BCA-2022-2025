<?php
session_start();
include("db_connection.php");

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
  header("Location: login.html");
  exit;
}

// Filter logic
$status_filter = isset($_GET['status']) && $_GET['status'] != "" ? $_GET['status'] : "";

$query = "SELECT b.*, cu.name AS customer_name, tu.name AS tailor_name
          FROM bookings b
          JOIN users cu ON b.customer_id = cu.id
          JOIN users tu ON b.tailor_id = tu.id";

if ($status_filter != "") {
  $query .= " WHERE b.status = '$status_filter'";
}

$query .= " ORDER BY b.created_at DESC";
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html>
<head>
  <title>Admin Booking Report - ThreadUp</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    @media print {
      .no-print {
        display: none;
      }
    }
  </style>
</head>
<body class="p-4 bg-light">

  <div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="text-primary">Booking Report</h2>
    <button onclick="window.print()" class="btn btn-dark no-print">🖨️ Print Report</button>
  </div>

  <form method="GET" class="row g-3 align-items-center no-print mb-4">
    <div class="col-auto">
      <label for="status" class="form-label">Filter by Status:</label>
    </div>
    <div class="col-auto">
      <select name="status" id="status" class="form-select">
        <option value="">All</option>
        <option value="pending" <?= $status_filter == 'pending' ? 'selected' : '' ?>>Pending</option>
        <option value="accepted" <?= $status_filter == 'accepted' ? 'selected' : '' ?>>Accepted</option>
        <option value="in progress" <?= $status_filter == 'in progress' ? 'selected' : '' ?>>In Progress</option>
        <option value="ready" <?= $status_filter == 'ready' ? 'selected' : '' ?>>Ready</option>
        <option value="delivered" <?= $status_filter == 'delivered' ? 'selected' : '' ?>>Delivered</option>
        <option value="rejected" <?= $status_filter == 'rejected' ? 'selected' : '' ?>>Rejected</option>
      </select>
    </div>
    <div class="col-auto">
      <button type="submit" class="btn btn-primary">Apply Filter</button>
    </div>
  </form>

  <table class="table table-bordered table-striped">
    <thead class="table-dark text-center">
      <tr>
        <th>Customer</th>
        <th>Tailor</th>
        <th>Service</th>
        <th>Status</th>
        <th>Date</th>
        <th>Notes</th>
        <th>Placed On</th>
      </tr>
    </thead>
    <tbody>
      <?php while ($row = mysqli_fetch_assoc($result)) { ?>
        <tr>
          <td><?= htmlspecialchars($row['customer_name']) ?></td>
          <td><?= htmlspecialchars($row['tailor_name']) ?></td>
          <td><?= htmlspecialchars($row['service_type']) ?></td>
          <td><span class="badge bg-secondary"><?= ucfirst($row['status']) ?></span></td>
          <td><?= $row['booking_date'] ?></td>
          <td><?= nl2br(htmlspecialchars($row['notes'])) ?></td>
          <td><?= date("d M Y", strtotime($row['created_at'])) ?></td>
        </tr>
      <?php } ?>
    </tbody>
  </table>

</body>
</html>
