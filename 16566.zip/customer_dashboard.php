<?php
session_start();
include("db_connection.php");

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'customer') {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$query = mysqli_query($conn, "SELECT name, profile_image FROM customers WHERE id = '$user_id'");
$user = mysqli_fetch_assoc($query);

$name = $user['name'];
$imagePath = !empty($user['profile_image']) ? 'uploads/profile_images/' . $user['profile_image'] : 'assets/images/default_avatar.png';
?>

<?php include("header.php"); ?>

<div class="container mt-5">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h3 class="text-primary fw-bold">Welcome, <?php echo htmlspecialchars($name); ?> 👋</h3>
        <img src="<?php echo $imagePath; ?>" alt="Profile" class="img-thumbnail rounded-circle" style="width: 60px; height: 60px; object-fit: cover;">
    </div>

    <div class="card shadow-sm">
        <div class="card-body">
            <p>🎯 This is your customer dashboard. From here you can book tailoring services, view order status, and manage your profile.</p>
            <ul>
                <li><a href="book_service.php">📌 Book a New Service</a></li>
                <li><a href="my_orders.php">📦 Track My Orders</a></li>
                <li><a href="customer_profile.php">👤 Edit Profile</a></li>
            </ul>
        </div>
    </div>
</div>

<?php include("footer.php"); ?>
