<?php
session_start();
include("db_connect.php");
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_id = $_SESSION['user_id'] ?? 1; // Replace with actual user ID
    $rating = $conn->real_escape_string($_POST['rating']);
    $comment = $conn->real_escape_string($_POST['comment']);
    $sql = "INSERT INTO feedback (user_id, rating, comment) VALUES ($customer_id, $rating, '$comment')";
    $conn->query($sql);
    header("Location: /ThreadUp/home.php");
}
?>