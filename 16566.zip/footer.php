</main>

<footer class="main-footer">
  <div class="container">
    <div class="row g-4 text-white">
      <!-- Contact Us -->
      <div class="col-md-3">
        <h5 class="fw-bold mb-3">Contact Us</h5>
        <p><i class="bi bi-envelope-fill me-2"></i>Email: support@threadup.com</p>
        <p><i class="bi bi-telephone-fill me-2"></i>Phone: +91 123 456 7890</p>
        <p><i class="bi bi-geo-alt-fill me-2"></i>123 Tailor Street, Patna</p>
      </div>

      <!-- Quick Links -->
      <div class="col-md-3">
        <h5 class="fw-bold mb-3">Quick Links</h5>
        <ul class="list-unstyled">
          <li><a href="/ThreadUp/about.php" class="text-white text-decoration-none"><i class="bi bi-info-circle me-2"></i>About</a></li>
          <li><a href="/ThreadUp/services.php" class="text-white text-decoration-none"><i class="bi bi-scissors me-2"></i>Services</a></li>
          <li><a href="/ThreadUp/tailors.php" class="text-white text-decoration-none"><i class="bi bi-person-workspace me-2"></i>Tailors</a></li>
          <li><a href="/ThreadUp/privacy.php" class="text-white text-decoration-none"><i class="bi bi-person-workspace me-2"></i>Privacy Policy</a></li>
          <li><a href="/ThreadUp/terms.php"class="text-white text-decoration-none"><i class="bi bi-person-workspace me-2"></i>Terms of Service</a></li>
        </ul>
      </div>

      <!-- Follow Us + Play Store -->
      <div class="col-md-3">
  <h5 class="fw-bold mb-3">Follow Us</h5>
  <p class="mb-2">Stay connected:</p>
  <div class="social-icons mb-3">
    <a href="https://www.facebook.com" class="text-white me-3" target="_blank"><i class="fab fa-facebook-f"></i></a>
    <a href="https://www.instagram.com" class="text-white me-3" target="_blank"><i class="fab fa-instagram"></i></a>
    <a href="https://www.twitter.com" class="text-white me-3" target="_blank"><i class="fab fa-x-twitter"></i></a>
  </div>
  <a href="#" target="_blank">
    <img src="https://upload.wikimedia.org/wikipedia/commons/7/78/Google_Play_Store_badge_EN.svg"
         alt="Get it on Google Play"
         style="height: 40px; margin-top: 10px;">
  </a>
</div>


      <!-- Google Map -->
<div class="col-md-3 map-container">
  <h5 class="fw-bold mb-3 text-white">Visit Us</h5>
  <iframe
    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d229.45624296847143!2d85.1445072172935!3d25.61101249976752!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x39ed587b3a5c6b37%3A0x2f8e95fcd8827a4e!2sCIMAGE%20Professional%20College%2C%20Patna!5e0!3m2!1sen!2sin!4v1654114306623!5m2!1sen!2sin"
    width="100%"
    height="100"
    style="border:0;"
    allowfullscreen=""
    loading="lazy"
    referrerpolicy="no-referrer-when-downgrade">
  </iframe>
</div>

    </div>

    <!-- Copyright -->
    <p class="text-center mt-4 mb-0">© 2025 ThreadUp. All rights reserved.</p>
  </div>
</footer>
<style>
/* Footer */
.main-footer {
  background: #3a1c71 !important;
  color: #fff;
  padding: 1.5rem 0;
  text-align: center;
  position: relative;
  z-index: 10;
}
footer, .main-footer {
  z-index: 9999 !important;
  position: relative;
}

.main-footer::before {
  content: "";
  position: absolute;
  inset: 0;
  background: #3a1c71;
  z-index: -1;
  opacity: 1;
}
@media (max-width: 576px) {
  .footer-links {
    display: flex;
    flex-direction: column;
    gap: 8px;
  }
}

</style>