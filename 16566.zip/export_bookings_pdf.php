<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once __DIR__ . '/../vendor/autoload.php';
include('../db.php'); // ✅ Make sure this path is correct

$mpdf = new \Mpdf\Mpdf();
$html = '
<h2 style="color:#3a1c71; text-align:center;">ThreadUp - Booking Report</h2>
<table style="width:100%; border-collapse:collapse;" border="1" cellpadding="8">
<thead style="background-color:#f2f2f2;">
<tr>
  <th>#</th>
  <th>Customer</th>
  <th>Tailor</th>
  <th>Service</th>
  <th>Date</th>
  <th>Status</th>
</tr>
</thead>
<tbody>
';

$query = "SELECT b.*, 
  cust.name AS customer_name, 
  tailor.name AS tailor_name 
  FROM bookings b
  JOIN users cust ON b.customer_id = cust.id
  JOIN users tailor ON b.tailor_id = tailor.id
  ORDER BY b.booking_date DESC";

$result = mysqli_query($conn, $query);
$counter = 1;

while($row = mysqli_fetch_assoc($result)) {
  $html .= '<tr>
    <td>' . $counter++ . '</td>
    <td>' . $row['customer_name'] . '</td>
    <td>' . $row['tailor_name'] . '</td>
    <td>' . $row['service_type'] . '</td>
    <td>' . $row['booking_date'] . '</td>
    <td>' . ucfirst($row['status']) . '</td>
  </tr>';
}

$html .= '</tbody></table>';

$mpdf->WriteHTML($html);
$mpdf->Output('bookings_report.pdf', 'D');
?>
