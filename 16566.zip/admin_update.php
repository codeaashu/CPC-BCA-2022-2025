<?php
session_start();
include("db_connection.php");

if ($_SESSION['role'] !== 'admin') {
  header("Location: login.html");
  exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $id = $_POST['booking_id'];
  $status = $_POST['status'];

  $query = "UPDATE bookings SET status='$status' WHERE id='$id'";
  if (mysqli_query($conn, $query)) {
    echo "<script>alert('Status updated successfully'); window.location.href='admin_bookings.php';</script>";
  } else {
    echo "Error: " . mysqli_error($conn);
  }
}
?>
