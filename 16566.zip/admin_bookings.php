<?php include("header.php"); ?>

<div class="container mt-5">
  <h2 class="text-primary text-center mb-4">All Bookings</h2>

  <table class="table table-bordered table-striped">
    <thead class="table-dark">
      <tr>
        <th>Customer</th>
        <th>Tailor</th>
        <th>Service</th>
        <th>Date</th>
        <th>Status</th>
        <th>Notes</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>Priya</td>
        <td>Neha Tailors</td>
        <td>Blouse Stitching</td>
        <td>2025-07-10</td>
        <td><span class="badge bg-warning">Pending</span></td>
        <td>Golden lace on sleeves</td>
      </tr>
      <tr>
        <td>Amit</td>
        <td>Ravi Stitch</td>
        <td>Kurta Alteration</td>
        <td>2025-07-05</td>
        <td><span class="badge bg-success">Delivered</span></td>
        <td>Shorten sleeves</td>
      </tr>
      <tr>
        <td>Sonal</td>
        <td>Elegant Fashions</td>
        <td>Lehenga Fitting</td>
        <td>2025-07-12</td>
        <td><span class="badge bg-info">In Progress</span></td>
        <td>Add can-can layer</td>
      </tr>
    </tbody>
  </table>
</div>

<?php include("footer.php"); ?>


<!-- <!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <title>Admin - All Bookings</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      font-family: 'Segoe UI', sans-serif;
      background: #f8f9fa;
      padding: 2rem;
    }

    h2 {
      color: #3a1c71;
      text-align: center;
      margin-bottom: 2rem;
    }

    .table {
      background: #fff;
      border-radius: 12px;
      box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
    }

    .badge {
      border-radius: 8px;
      padding: 5px 10px;
    }

    .badge-inprogress {
      background: orange;
      color: white;
    }

    .badge-ready {
      background: green;
      color: white;
    }

    .badge-delivered {
      background: #17a2b8;
      color: white;
    }
  </style>
</head>

<body>
  <header style="background: #3a1c71; padding: 1rem;">
    <nav class="container d-flex justify-content-between align-items-center text-white">
      <h3 class="m-0">ThreadUp</h3>
      <ul class="nav">
        <li class="nav-item"><a class="nav-link text-white" href="index.html">Home</a></li>
        <li class="nav-item"><a class="nav-link text-white" href="about.html">About</a></li>
        <li class="nav-item"><a class="nav-link text-white" href="services.html">Services</a></li>
        <li class="nav-item"><a class="nav-link text-white" href="tailors.html">Tailors</a></li>
        <li class="nav-item"><a class="nav-link text-white" href="contact.html">Contact</a></li>
        <li class="nav-item"><a class="nav-link text-white" href="login.html">Login</a></li>
        <li class="nav-item"><a class="nav-link text-white" href="signup.html">Sign Up</a></li>
      </ul>
    </nav>
  </header>


  <h2>All Bookings</h2>

  <div class="container">
    <table class="table table-bordered">
      <thead class="table-light">
        <tr>
          <th>Customer</th>
          <th>Tailor</th>
          <th>Service</th>
          <th>Date</th>
          <th>Status</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>Priya Sharma</td>
          <td>Neha Stitching</td>
          <td>Lehenga Stitching</td>
          <td>02-Jul-2025</td>
          <td><span class="badge badge-inprogress">In Progress</span></td>
        </tr>
        <tr>
          <td>Amit Verma</td>
          <td>Ravi Tailors</td>
          <td>Blazer Alteration</td>
          <td>29-Jun-2025</td>
          <td><span class="badge badge-ready">Ready</span></td>
        </tr>
      </tbody>
    </table>
  </div>
  <footer class="text-center p-4 mt-5" style="background: #3a1c71; color: white;">
    <p>&copy; 2025 ThreadUp. All rights reserved.</p>
  </footer>

</body>

</html> -->