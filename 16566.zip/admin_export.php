<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
  <title>Export Reports | Admin Panel</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
  <style>
    body { background-color: #e7e8ef; font-family: 'Segoe UI', sans-serif; }
    .container { margin-left: 220px; padding: 40px; }
    h2 { margin-bottom: 20px; }
    .export-box { background: #cec4ef; padding: 30px; border-radius: 10px; }
  </style>
</head>
<body>
  <div class="container">
    <h2><i class="fas fa-file-export"></i> Export Bookings Data</h2>
    <div class="export-box">
      <p>You can export the booking report in different formats:</p>
      <a href="export_csv.php" class="btn btn-success me-3"><i class="fas fa-file-csv"></i> Export as CSV</a>
      <a href="export_pdf.php" class="btn btn-danger"><i class="fas fa-file-pdf"></i> Export as PDF</a>
    </div>
  </div>
</body>
</html>
