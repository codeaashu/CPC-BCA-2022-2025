<?php
session_start();
include("db_connection.php"); // Make sure this file is correct

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $email = mysqli_real_escape_string($conn, $_POST['email']);
  $password = $_POST['password'];

  // Use new tailors table
  $query = "SELECT * FROM tailors WHERE email = '$email'";
  $result = mysqli_query($conn, $query);

  if ($result && mysqli_num_rows($result) === 1) {
    $tailor = mysqli_fetch_assoc($result);

    if (password_verify($password, $tailor['password'])) {
    // Login success
    $_SESSION['user_id'] = $tailor['id'];
    $_SESSION['tailor_id'] = $tailor['id']; // ✅ Add this line
    $_SESSION['role'] = 'tailor';
    $_SESSION['name'] = $tailor['name'];

    header("Location: tailor_dashboard.php");
    exit;
}
    } else {
      echo "❌ Incorrect password. <a href='tailor_login.php'>Try again</a>";
    }
  } else {
    echo "❌ No tailor account found with this email. <a href='tailor_signup.php'>Sign up</a>";
  }
}
?>
