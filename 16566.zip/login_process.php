<?php
session_start();
include("db_connection.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email    = mysqli_real_escape_string($conn, $_POST['email']);
    $password = $_POST['password'];

    // 1. Try admin login
    $result = mysqli_query($conn, "SELECT * FROM admins WHERE email = '$email'");
    if ($result && mysqli_num_rows($result) === 1) {
        $admin = mysqli_fetch_assoc($result);
        if (password_verify($password, $admin['password'])) {
            $_SESSION['user_id'] = $admin['id'];
            $_SESSION['role'] = 'admin';
            $_SESSION['name'] = $admin['name'];
            header("Location: admin_dashboard.php");
            exit;
        }
    }

    // 2. Try tailor login
    $result = mysqli_query($conn, "SELECT * FROM tailors WHERE email = '$email'");
    if ($result && mysqli_num_rows($result) === 1) {
        $tailor = mysqli_fetch_assoc($result);
        if (password_verify($password, $tailor['password'])) {
            $_SESSION['user_id'] = $tailor['id'];
            $_SESSION['role'] = 'tailor';
            $_SESSION['name'] = $tailor['name'];
            header("Location: tailor_dashboard.php");
            exit;
        }
    }

    // 3. Try customer login
    $result = mysqli_query($conn, "SELECT * FROM customers WHERE email = '$email'");
    if ($result && mysqli_num_rows($result) === 1) {
        $customer = mysqli_fetch_assoc($result);
        if (password_verify($password, $customer['password'])) {
            $_SESSION['user_id'] = $customer['id'];
            $_SESSION['role'] = 'customer';
            $_SESSION['name'] = $customer['name'];
            header("Location: customer_dashboard.php");
            exit;
        }
    }

    // ❌ Login failed
    echo "<script>alert('❌ Invalid email or password'); window.location.href='login.php';</script>";
}
?>
