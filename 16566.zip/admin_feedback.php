<?php include("header.php"); ?>

<div class="container mt-5">
  <h2 class="text-primary text-center mb-4">User Feedback</h2>

  <table class="table table-bordered table-striped">
    <thead class="table-dark">
      <tr>
        <th>Customer</th>
        <th>Feedback</th>
        <th>Rating</th>
        <th>Date</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>Priya Sharma</td>
        <td>Excellent stitching, loved the fitting!</td>
        <td>⭐️⭐️⭐️⭐️⭐️</td>
        <td>2025-07-01</td>
      </tr>
      <tr>
        <td>Rahul Verma</td>
        <td>Good service but delivery was 1 day late.</td>
        <td>⭐️⭐️⭐️⭐️</td>
        <td>2025-06-28</td>
      </tr>
      <tr>
        <td>Anjali Singh</td>
        <td>Tailor didn’t follow lace instructions.</td>
        <td>⭐️⭐️</td>
        <td>2025-06-25</td>
      </tr>
    </tbody>
  </table>
</div>

<?php include("footer.php"); ?>


<!-- <!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <title>Admin - Feedback</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background: #fffdfc;
      font-family: 'Segoe UI', sans-serif;
      padding: 2rem;
    }

    .container {
      max-width: 800px;
      margin: auto;
    }

    h2 {
      color: #3a1c71;
      text-align: center;
      margin-bottom: 2rem;
    }

    .feedback-box {
      background: white;
      border-radius: 12px;
      padding: 1.5rem;
      margin-bottom: 1.5rem;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    }

    .feedback-box strong {
      color: #3a1c71;
    }
  </style>
</head>

<body>
  <header style="background: #3a1c71; padding: 1rem;">
    <nav class="container d-flex justify-content-between align-items-center text-white">
      <h3 class="m-0">ThreadUp</h3>
      <ul class="nav">
        <li class="nav-item"><a class="nav-link text-white" href="index.html">Home</a></li>
        <li class="nav-item"><a class="nav-link text-white" href="about.html">About</a></li>
        <li class="nav-item"><a class="nav-link text-white" href="services.html">Services</a></li>
        <li class="nav-item"><a class="nav-link text-white" href="tailors.html">Tailors</a></li>
        <li class="nav-item"><a class="nav-link text-white" href="contact.html">Contact</a></li>
        <li class="nav-item"><a class="nav-link text-white" href="login.html">Login</a></li>
        <li class="nav-item"><a class="nav-link text-white" href="signup.html">Sign Up</a></li>
      </ul>
    </nav>
  </header>


  <div class="container">
    <h2>User Feedback & Complaints</h2>

    <div class="feedback-box">
      <strong>Priya Sharma:</strong>
      <p>The delivery was delayed by 3 days. Please improve timings.</p>
    </div>

    <div class="feedback-box">
      <strong>Amit Verma:</strong>
      <p>Very satisfied with Ravi Tailors. Excellent fitting!</p>
    </div>

  </div>
  <footer class="text-center p-4 mt-5" style="background: #3a1c71; color: white;">
    <p>&copy; 2025 ThreadUp. All rights reserved.</p>
  </footer>

</body>

</html> -->