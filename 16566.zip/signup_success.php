<?php include("header.php"); ?>
<div class="container text-center my-5">
    <h2 class="text-success fw-bold">🎉 Registration Successful!</h2>
    <p class="lead">Welcome to ThreadUp. You will now be redirected to your dashboard.</p>
</div>
<script>
  setTimeout(() => {
    window.location.href = "<?php echo $_SESSION['role']; ?>/index.php";
  }, 3000);
</script>
<?php include("footer.php"); ?>
