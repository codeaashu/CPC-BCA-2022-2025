<?php include("header.php"); ?>

<div class="container mt-5" style="max-width: 500px;">
  <h2 class="text-center text-primary mb-4 fw-bold">Create Account</h2>

  <form action="signup_submit.php" method="POST">
    <div class="mb-3">
      <input type="text" name="name" class="form-control rounded-pill" placeholder="Full Name" required />
    </div>

    <div class="mb-3">
      <input type="email" name="email" class="form-control rounded-pill" placeholder="Email" required />
    </div>

    <div class="mb-3">
      <input type="password" name="password" class="form-control rounded-pill" placeholder="Password" required />
    </div>

    <div class="mb-3">
      <select name="role" class="form-select rounded-pill" required>
        <option value="">-- Select Role --</option>
        <option value="customer">Customer</option>
        <option value="tailor">Tailor</option>
      </select>
    </div>

    <!-- Only Tailors need Specialty -->
    <div class="mb-3" id="specialty-box" style="display: none;">
      <input type="text" name="specialty" class="form-control rounded-pill" placeholder="Specialty (for Tailor)" />
    </div>

    <div class="d-grid">
      <button type="submit" class="btn btn-primary rounded-pill">Sign Up</button>
    </div>

    <div class="text-center mt-3">
      Already have an account? <a href="login.php" class="text-decoration-none text-primary fw-semibold">Login</a>
    </div>
  </form>
</div>

<script>
  const roleSelect = document.querySelector('select[name="role"]');
  const specialtyBox = document.getElementById('specialty-box');

  roleSelect.addEventListener('change', function () {
    specialtyBox.style.display = this.value === 'tailor' ? 'block' : 'none';
  });
</script>

<?php include("footer.php"); ?>



<!-- <!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>ThreadUp - Sign Up</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" />
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', sans-serif;
            height: 100vh;
            overflow: hidden;
        }

        .container-fluid {
            height: 100vh;
            width: 100%;
            display: flex;
            justify-content: center;
            align-items: center;
            position: relative;
            background: linear-gradient(135deg, #3a1c71, #d76d77, #ffaf7b);
            overflow: hidden;
            padding: 1rem;
        }

        .background-images {
            position: absolute;
            top: 50%;
            left: 50%;
            width: 180vw;
            height: 180vh;
            transform: translate(-50%, -50%);
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            grid-template-rows: repeat(3, 1fr);
            gap: 1rem;
            z-index: 0;
            user-select: none;
            pointer-events: none;
            filter: brightness(0.25);
            animation: slowPulse 25s ease-in-out infinite;
        }

        .background-images img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            border-radius: 12px;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.15);
            mix-blend-mode: normal;
        }

        @keyframes slowPulse {

            0%,
            100% {
                filter: brightness(0.65);
            }

            50% {
                filter: brightness(0.4);
            }
        }

        .signup-card {
            position: relative;
            background: rgba(255, 255, 255, 0.95);
            padding: 2.5rem;
            border-radius: 16px;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.2);
            width: 100%;
            max-width: 420px;
            z-index: 1;
            backdrop-filter: saturate(180%) blur(10px);
        }

        .signup-card h2 {
            font-weight: 700;
            margin-bottom: 1.5rem;
            color: #3a1c71;
            text-align: center;
        }

        .form-control {
            border-radius: 30px;
            padding: 0.75rem 1rem;
        }

        .btn-primary {
            border-radius: 30px;
            padding: 0.6rem 1.5rem;
            background-color: #3a1c71;
            border: none;
            font-weight: 600;
        }

        .btn-primary:hover {
            background-color: #822e91;
        }

        .text-center a {
            text-decoration: none;
            color: #3a1c71;
            font-weight: 500;
        }

        .text-center a:hover {
            text-decoration: underline;
        }
    </style>
    <!-- <style>
        body {
            background: linear-gradient(135deg, #3a1c71, #d76d77, #ffaf7b);
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            font-family: 'Segoe UI', sans-serif;
        }

        .signup-card {
            background: #fff;
            padding: 2.5rem;
            border-radius: 12px;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.2);
            width: 100%;
            max-width: 480px;
        }

        .signup-card h2 {
            font-weight: 700;
            margin-bottom: 1.5rem;
            color: #3a1c71;
            text-align: center;
        }

        .form-control {
            border-radius: 30px;
            padding: 0.75rem 1rem;
        }

        .btn-primary {
            border-radius: 30px;
            padding: 0.6rem 1.5rem;
            background-color: #3a1c71;
            border: none;
            font-weight: 600;
        }

        .btn-primary:hover {
            background-color: #822e91;
        }

        .text-center a {
            text-decoration: none;
            color: #3a1c71;
            font-weight: 500;
        }

        .text-center a:hover {
            text-decoration: underline;
        }
    </style> 
</head>

<body>
    <header style="background: #3a1c71; padding: 1rem;">
        <nav class="container d-flex justify-content-between align-items-center text-white">
            <h3 class="m-0">ThreadUp</h3>
            <ul class="nav">
                <li class="nav-item"><a class="nav-link text-white" href="index.html">Home</a></li>
                <li class="nav-item"><a class="nav-link text-white" href="about.html">About</a></li>
                <li class="nav-item"><a class="nav-link text-white" href="services.html">Services</a></li>
                <li class="nav-item"><a class="nav-link text-white" href="tailors.html">Tailors</a></li>
                <li class="nav-item"><a class="nav-link text-white" href="contact.html">Contact</a></li>
                <li class="nav-item"><a class="nav-link text-white" href="login.html">Login</a></li>
                <li class="nav-item"><a class="nav-link text-white" href="signup.html">Sign Up</a></li>
            </ul>
        </nav>
    </header>

    <div class="container-fluid" role="main">
        <div class="background-images" aria-hidden="true" aria-label="Tailoring and sewing background images">
            <img src="assets/img1.avif" alt="Pattern drafting for tailor" />
            <img src="assets/img3.jpg" alt="Tailoring tools and equipment layout" />
            <img src="assets/img2.jpg" alt="Fashion sketch on paper" />
            <img src="assets/2.jpg" alt="Colorful folded fabrics on shelf" />
            <img src="assets/1.jpg" alt="Close-up sewing machine stitching" />
            <img src="assets/2.jpg" alt="Colorful folded fabrics on shelf" />
            <img src="assets/img1.avif" alt="Pattern drafting for tailor" />
            <img src="assets/img3.jpg" alt="Tailoring tools and equipment layout" />
            <img src="assets/img2.jpg" alt="Fashion sketch on paper" />
            <img src="assets/i.jpg" alt="Tailor sewing by hand with needle" />
        </div>
        <div class="signup-card">
            <h2>Create Your ThreadUp Account</h2>
            <form>
                <div class="mb-3">
                    <input type="text" class="form-control" placeholder="Full Name" required />
                </div>
                <div class="mb-3">
                    <input type="email" class="form-control" placeholder="Email" required />
                </div>
                <div class="mb-3">
                    <input type="password" class="form-control" placeholder="Password" required />
                </div>
                <div class="mb-3">
                    <input type="password" class="form-control" placeholder="Confirm Password" required />
                </div>
                <div class="d-grid mb-3">
                    <button type="submit" class="btn btn-primary">Sign Up</button>
                </div>
                <div class="text-center">
                    Already have an account? <a href="login.html">Login</a>
                </div>
            </form>
        </div>
    </div>
    <footer class="text-center p-4 mt-5" style="background: #3a1c71; color: white;">
        <p>&copy; 2025 ThreadUp. All rights reserved.</p>
    </footer>

</body>

</html> -->