<?php
include 'db_connection.php';
include 'admin_sidebar.php';

$search = $_GET['search'] ?? '';

$query = "SELECT * FROM customers WHERE 1";
if (!empty($search)) {
    $query .= " AND (name LIKE '%$search%' OR email LIKE '%$search%')";
}
$result = mysqli_query($conn, $query);
?>
<?php include("header.php"); ?>
<div class="main-content p-4" style="margin-left:250px;">
    <h2 class="mb-4">Manage Customers</h2>

    <!-- Search bar -->
    <form method="GET" class="row g-3 mb-4">
        <div class="col-md-4">
            <input type="text" name="search" class="form-control" placeholder="Search by name or email" value="<?= htmlspecialchars($search) ?>">
        </div>
        <div class="col-md-2">
            <button type="submit" class="btn btn-primary">Search</button>
        </div>
    </form>

    <!-- Customer table -->
    <div class="table-responsive bg-white p-3 rounded shadow-sm">
        <table class="table table-bordered align-middle table-hover">
            <thead class="table-dark text-center">
                <tr>
                    <th>#</th>
                    <th>Profile</th>
                    <th>Name & Email</th>
                    <th>Phone</th>
                    <th>Registered On</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (mysqli_num_rows($result) > 0): $i = 1; ?>
                    <?php while ($row = mysqli_fetch_assoc($result)): ?>
                        <tr>
                            <td><?= $i++ ?></td>
                            <td class="text-center">
                                <img src="uploads/<?= $row['profile_image'] ?? 'default.png' ?>" width="50" height="50" class="rounded-circle">
                            </td>
                            <td>
                                <strong><?= htmlspecialchars($row['name']) ?></strong><br>
                                <small><?= htmlspecialchars($row['email']) ?></small>
                            </td>
                            <td><?= htmlspecialchars($row['phone'] ?? '-') ?></td>
                            <td><?= date('d M Y', strtotime($row['created_at'])) ?></td>
                            <td class="text-center">
                                <a href="view_customer.php?id=<?= $row['id'] ?>" class="btn btn-info btn-sm">View</a>
                                <a href="edit_customer.php?id=<?= $row['id'] ?>" class="btn btn-warning btn-sm">Edit</a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr><td colspan="6" class="text-center">No customers found.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php include("footer.php"); ?>