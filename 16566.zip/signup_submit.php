<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
session_start();
include("db_connection.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name      = mysqli_real_escape_string($conn, $_POST['name']);
    $email     = mysqli_real_escape_string($conn, $_POST['email']);
    $password  = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $role      = $_POST['role'];
    $specialty = isset($_POST['specialty']) ? mysqli_real_escape_string($conn, $_POST['specialty']) : null;

    // ✅ Check if email exists in any role
    $tables = ['customers', 'tailors', 'admins'];
    foreach ($tables as $table) {
        $check = mysqli_query($conn, "SELECT * FROM $table WHERE email='$email'");
        if (mysqli_num_rows($check) > 0) {
            echo "<script>alert('❌ Email already registered as $table. Please login.'); window.location.href='login.php';</script>";
            exit;
        }
    }

    // ✅ Handle image upload
    $image_name = null;
    if (!empty($_FILES['profile']['name'])) {
        $upload_dir = "uploads/";
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir);
        }
        $image_name = uniqid() . "_" . basename($_FILES["profile"]["name"]);
        $target_path = $upload_dir . $image_name;

        if (!move_uploaded_file($_FILES["profile"]["tmp_name"], $target_path)) {
            echo "<script>alert('❌ Failed to upload image.'); window.location.href='signup.php';</script>";
            exit;
        }
    }

    // ✅ Insert into respective table
    switch ($role) {
        case 'customer':
            $stmt = $conn->prepare("INSERT INTO customers (name, email, password, profile_image) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("ssss", $name, $email, $password, $image_name);
            break;

        case 'tailor':
            $stmt = $conn->prepare("INSERT INTO tailors (name, email, password,specialization, profile_image) VALUES (?, ?, ?, ?, ?)");
            $stmt->bind_param("sssss", $name, $email, $password, $specialty, $image_name);
            break;

        case 'admin':
            $stmt = $conn->prepare("INSERT INTO admins (name, email, password, profile_image) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("ssss", $name, $email, $password, $image_name);
            break;

        default:
            echo "<script>alert('❌ Invalid role.'); window.location.href='signup.php';</script>";
            exit;
    }

    if ($stmt->execute()) {
        $_SESSION['user_id'] = $conn->insert_id;
        $_SESSION['name'] = $name;
        $_SESSION['role'] = $role;

        $redirect = ($role === 'customer') ? 'customer_dashboard.php' :
                    (($role === 'tailor') ? 'tailor_dashboard.php' : 'admin_dashboard.php');

        echo "<script>alert('✅ Registration successful! Welcome, $name.'); window.location.href='$redirect';</script>";
        exit;
    } else {
        echo "<script>alert('❌ Error: " . $stmt->error . "'); window.location.href='signup.php';</script>";
    }
    $stmt->close();
}
$conn->close();
?>
