<?php include("header.php"); ?>

<div class="container mt-5" style="max-width: 500px;">
  <div class="card shadow p-4 rounded-4">
    <h3 class="text-center text-primary fw-bold mb-4">Tailor Sign Up</h3>
    <form action="tailor_signup_submit.php" method="POST" enctype="multipart/form-data" novalidate>

      <div class="mb-3">
        <label class="form-label fw-semibold">Full Name</label>
        <input type="text" name="name" class="form-control rounded-pill text-center" placeholder="Enter your full name" required>
      </div>

      <div class="mb-3">
        <label class="form-label fw-semibold">Email</label>
        <input type="email" name="email" class="form-control rounded-pill text-center" placeholder="Enter your email" required>
      </div>

      <div class="mb-3">
        <label class="form-label fw-semibold">Phone</label>
        <input type="tel" name="phone" class="form-control rounded-pill text-center" placeholder="Enter your phone number" required pattern="[0-9]{10}">
      </div>

      <div class="mb-3">
        <label class="form-label fw-semibold">Specialty</label>
        <input type="text" name="specialty" class="form-control rounded-pill text-center" placeholder="e.g., Men's Wear, Bridal, Alterations" required>
      </div>

      <div class="mb-3">
        <label class="form-label fw-semibold">Location</label>
        <input type="text" name="location" class="form-control rounded-pill text-center" placeholder="City or area" required>
      </div>

      <div class="mb-3">
        <label class="form-label fw-semibold">Profile Photo</label>
        <input type="file" name="photo" class="form-control rounded-pill" accept="image/*" required>
      </div>

      <div class="mb-3">
        <label class="form-label fw-semibold">Password</label>
        <input type="password" name="password" class="form-control rounded-pill text-center" placeholder="Create a password" minlength="6" required>
      </div>

      <div class="d-grid mb-3">
        <button type="submit" class="btn btn-primary rounded-pill">Register</button>
      </div>

      <p class="text-center">Already have an account? <a href="tailor_login.php" class="text-primary fw-semibold">Login here</a></p>
    </form>
  </div>
</div>

<?php include("footer.php"); ?>
