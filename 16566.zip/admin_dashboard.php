<?php
session_start();
include("db_connection.php");
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

// Filters
$from_date = $_POST['from_date'] ?? '';
$to_date = $_POST['to_date'] ?? '';
$date_filter = '';
if (!empty($from_date) && !empty($to_date)) {
    $date_filter = "WHERE booking_date BETWEEN '$from_date' AND '$to_date'";
}

// Dashboard Counts
$totalCustomers = mysqli_num_rows(mysqli_query($conn, "SELECT id FROM customers"));
$totalTailors = mysqli_num_rows(mysqli_query($conn, "SELECT id FROM tailors"));
$totalBookings = mysqli_num_rows(mysqli_query($conn, "SELECT id FROM bookings $date_filter"));
$completedOrders = mysqli_num_rows(mysqli_query($conn, "SELECT id FROM bookings WHERE status='Completed' " . ($date_filter ? "AND booking_date BETWEEN '$from_date' AND '$to_date'" : "")));

$revenueResult = mysqli_query($conn, "SELECT SUM(price) AS total_revenue FROM bookings WHERE status='Completed' " . ($date_filter ? "AND booking_date BETWEEN '$from_date' AND '$to_date'" : ""));
$revenueRow = mysqli_fetch_assoc($revenueResult);
$totalRevenue = $revenueRow['total_revenue'] ?? 0;

// Booking Status Breakdown
$statusData = ['Pending' => 0, 'In Progress' => 0, 'Completed' => 0];
$statusQuery = mysqli_query($conn, "SELECT status, COUNT(*) AS count FROM bookings $date_filter GROUP BY status");
while ($row = mysqli_fetch_assoc($statusQuery)) {
    $statusData[$row['status']] = $row['count'];
}

// Monthly Bookings (last 6 months)
$monthlyLabels = [];
$monthlyCounts = [];
for ($i = 5; $i >= 0; $i--) {
    $month = date('Y-m', strtotime("-$i months"));
    $label = date('M', strtotime("-$i months"));
    $monthlyLabels[] = $label;
    $countResult = mysqli_query($conn, "SELECT COUNT(*) AS count FROM bookings WHERE DATE_FORMAT(booking_date, '%Y-%m') = '$month'");
    $countRow = mysqli_fetch_assoc($countResult);
    $monthlyCounts[] = $countRow['count'] ?? 0;
}
?>
<!DOCTYPE html>
<html>
<head>
<meta name="description" content="Custom tailoring platform.">
<meta name="keywords" content="tailoring, stitching, clothing, custom fashion">
  <title>Admin Dashboard | ThreadUp</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <style>
    body { background-color: #fef6f2; font-family: 'Segoe UI', sans-serif; }
    .sidebar {
      position: fixed; top: 0; left: 0;
      width: 220px; height: 100vh;
      background: linear-gradient(90deg, #3a1c71, #d76d77);
      padding-top: 20px;
    }
    .sidebar h2 { color: white; text-align: center; margin-bottom: 30px; }
    .sidebar a {
      display: block; color: white; padding: 12px 20px;
      text-decoration: none; font-size: 15px;
    }
    .sidebar a i { margin-right: 10px; }
    .sidebar a:hover, .sidebar .active {
      background-color: rgba(255,255,255,0.1); border-left: 5px solid white;
    }
    .main-content { margin-left: 220px; padding: 30px; }
    .summary-card {
      border-radius: 10px; padding: 20px; color: white;
      box-shadow: 0 4px 8px rgba(0,0,0,0.1);
      background: linear-gradient(90deg, #3a1c71, #d76d77);
    }
    .filter-section, .chart-section, .table-section, .extra-section {
      background-color: #fff3e6;
      border-radius: 10px;
      padding: 20px;
      margin-top: 25px;
    }
    .btn-primary {
      background: linear-gradient(90deg, #3a1c71, #d76d77);
      border: none;
    }
    .status {
      padding: 5px 10px;
      border-radius: 5px;
      color: white;
    }
    .Pending { background-color: #f0ad4e; }
    .InProgress { background-color: #d9534f; }
    .Completed { background-color: #5cb85c; }
    
    @media (max-width: 768px) {
  .sidebar {
    position: relative;
    width: 100%;
    height: auto;
  }
  .main-content {
    margin-left: 0;
    padding: 15px;
  }
}

  </style>
</head>
<body>

<div class="sidebar">
  <h2>ThreadUp</h2>
  <a href="admin_dashboard.php" class="active"><i class="fas fa-chart-line"></i> Dashboard</a>
  <a href="manage_customers.php"><i class="fas fa-users"></i> Manage Customers</a>
  <a href="manage_tailors.php"><i class="fas fa-scissors"></i> Manage Tailors</a>
  <a href="bookings_report.php"><i class="fas fa-file-alt"></i> Bookings Report</a>
  <a href="admin_export.php"><i class="fas fa-file-export"></i> Export</a>
  <a href="admin_analytics.php"><i class="fas fa-chart-pie"></i> Analytics</a>
  <a href="admin_settings.php"><i class="fas fa-cog"></i> Settings</a>
  <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
</div>

<div class="main-content">
  <h2>Welcome, <?= $_SESSION['name'] ?></h2>

  <!-- Summary Cards -->
  <div class="row text-center g-3">
    <div class="col-md-2"><div class="summary-card"><h6>Customers</h6><h4><?= $totalCustomers ?></h4></div></div>
    <div class="col-md-2"><div class="summary-card"><h6>Tailors</h6><h4><?= $totalTailors ?></h4></div></div>
    <div class="col-md-2"><div class="summary-card"><h6>Bookings</h6><h4><?= $totalBookings ?></h4></div></div>
    <div class="col-md-3"><div class="summary-card"><h6>Completed Orders</h6><h4><?= $completedOrders ?></h4></div></div>
    <div class="col-md-3"><div class="summary-card"><h6>Total Revenue</h6><h4>₹<?= number_format($totalRevenue, 2) ?></h4></div></div>
  </div>

  <!-- Date Filter -->
  <form method="POST" class="filter-section mt-4">
    <div class="row">
      <div class="col-md-3"><label>From Date</label><input type="date" name="from_date" class="form-control" value="<?= $from_date ?>"></div>
      <div class="col-md-3"><label>To Date</label><input type="date" name="to_date" class="form-control" value="<?= $to_date ?>"></div>
      <div class="col-md-3 d-flex align-items-end"><button type="submit" class="btn btn-primary w-100">Apply Filter</button></div>
    </div>
  </form>

  <!-- Charts -->
  <div class="row chart-section mt-4">
    <div class="col-md-6"><canvas id="barChart" height="200"></canvas></div>
    <div class="col-md-6"><canvas id="pieChart" height="200"></canvas></div>
  </div>

  <!-- Notifications + Stats + Profile -->
 <!-- Notifications (Dynamic) -->
<div class="col-md-4">
  <h5><i class="fas fa-bell"></i> Notifications</h5>
  <ul class="list-unstyled">
    <?php
    $notifQuery = mysqli_query($conn, "SELECT customer_name, service, status, booking_date FROM bookings ORDER BY booking_date DESC LIMIT 5");
    while ($n = mysqli_fetch_assoc($notifQuery)) {
        echo "<li>📌 <strong>{$n['customer_name']}</strong> booked <em>{$n['service']}</em> — <span class='badge bg-secondary'>{$n['status']}</span></li>";
    }
    ?>
  </ul>
</div>


  <!-- Top Tailors -->
  <div class="table-section">
    <h5><i class="fas fa-trophy text-warning"></i> Top Performing Tailors</h5>
    <table class="table mt-3">
      <thead><tr><th>Name</th><th>Orders</th><th>Rating</th></tr></thead>
      <tbody>
    //   $result = mysqli_query($conn, "SELECT name, orders_completed, rating FROM tailors ORDER BY orders_completed DESC LIMIT 3"); (if db is there)
        <tr><td>Ravi Tailors</td><td>48</td><td>⭐ 4.9</td></tr>
        <tr><td>FashionHub</td><td>39</td><td>⭐ 4.7</td></tr>
        <tr><td>Stitch&Style</td><td>32</td><td>⭐ 4.8</td></tr>
      </tbody>
    </table>
  </div>
</div>

<script>
const barCtx = document.getElementById('barChart').getContext('2d');
new Chart(barCtx, {
  type: 'bar',
  data: {
    labels: <?= json_encode($monthlyLabels) ?>,
    datasets: [{
      label: 'Bookings/Month',
      data: <?= json_encode($monthlyCounts) ?>,
      backgroundColor: 'rgba(58,28,113,0.8)'
    }]
  }
});
const pieCtx = document.getElementById('pieChart').getContext('2d');
new Chart(pieCtx, {
  type: 'pie',
  data: {
    labels: ['Pending', 'In Progress', 'Completed'],
    datasets: [{
      data: [<?= $statusData['Pending'] ?>, <?= $statusData['In Progress'] ?>, <?= $statusData['Completed'] ?>],
      backgroundColor: ['#f0ad4e', '#d9534f', '#5cb85c']
    }]
  }
});
</script>
</body>
</html>
