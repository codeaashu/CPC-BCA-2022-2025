<?php include("header.php"); ?>
<div class="container-fluid" style="min-height: 100vh; display: flex; justify-content: center; align-items: center; background: linear-gradient(135deg, #f5f7fa, #e0e7ff);">
  <div class="card shadow p-4" style="max-width: 400px; width: 100%; border-radius: 16px;">
    <h3 class="text-center text-primary fw-bold mb-4">Login to ThreadUp</h3>
    <form action="login_process.php" method="POST">
      <div class="mb-3 text-start">
        <label for="email" class="form-label fw-semibold"><i class="bi bi-envelope me-2"></i>Email</label>
        <input type="email" name="email" class="form-control rounded-pill text-center" id="email" placeholder="Enter your email" required>
      </div>

      <div class="mb-3 text-start">
        <label for="password" class="form-label fw-semibold"><i class="bi bi-lock-fill me-2"></i>Password</label>
        <input type="password" name="password" class="form-control rounded-pill text-center" id="password" placeholder="Enter your password" required>
        <div class="form-check mt-2">
          <input class="form-check-input" type="checkbox" id="showPassword" onclick="togglePassword()">
          <label class="form-check-label" for="showPassword">
            Show Password
          </label>
        </div>
      </div>

      <div class="d-grid mb-3">
        <button type="submit" class="btn btn-primary rounded-pill">Login</button>
      </div>

      <p class="text-center">Don't have an account? <a href="signup.php" class="text-primary fw-semibold">Sign Up</a></p>
    </form>
  </div>
</div>

<script>
function togglePassword() {
  const passwordInput = document.getElementById("password");
  passwordInput.type = passwordInput.type === "password" ? "text" : "password";
}
</script>

<?php include("footer.php"); ?>
