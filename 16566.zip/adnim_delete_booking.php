<?php
session_start();
include("db_connection.php");

if ($_SESSION['role'] !== 'admin') {
  header("Location: login.html");
  exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $id = $_POST['booking_id'];

  $query = "DELETE FROM bookings WHERE id='$id'";
  if (mysqli_query($conn, $query)) {
    echo "<script>alert('Booking deleted'); window.location.href='admin_bookings.php';</script>";
  } else {
    echo "Error deleting: " . mysqli_error($conn);
  }
}
?>
