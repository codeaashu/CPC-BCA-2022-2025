<?php
session_start();
include("db_connection.php");

// Validate POST method
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Fetch & sanitize input
    $name      = trim($_POST['name']);
    $email     = trim($_POST['email']);
    $phone     = trim($_POST['phone']);
    $password  = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $specialty = trim($_POST['specialty']);
    $location  = trim($_POST['location']);

    // Validate image upload
    $uploadDir = "uploads/tailors/";
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0755, true);
    }

    $photoName = basename($_FILES["photo"]["name"]);
    $photoPath = $uploadDir . time() . "_" . $photoName;
    $photoType = strtolower(pathinfo($photoPath, PATHINFO_EXTENSION));

    $allowedTypes = ['jpg', 'jpeg', 'png', 'gif'];
    if (!in_array($photoType, $allowedTypes)) {
        die("❌ Only JPG, PNG, JPEG, GIF files are allowed.");
    }

    if (!move_uploaded_file($_FILES["photo"]["tmp_name"], $photoPath)) {
        die("❌ Failed to upload image.");
    }

    // Check for existing email
    $check = $conn->prepare("SELECT * FROM tailors WHERE email = ?");
    $check->bind_param("s", $email);
    $check->execute();
    $check->store_result();

    if ($check->num_rows > 0) {
        echo "❌ Email already exists. <a href='tailor_login.php'>Login here</a>";
        exit;
    }

    // Insert into tailors table
    $stmt = $conn->prepare("INSERT INTO tailors (name, email, password, phone, specialty, location, photo) 
                            VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssssss", $name, $email, $password, $phone, $specialty, $location, $photoPath);

    if ($stmt->execute()) {
        $_SESSION['user_id'] = $conn->insert_id;
        $_SESSION['role'] = 'tailor';
        $_SESSION['name'] = $name;
        header("Location: tailor_dashboard.php");
        exit;
    } else {
        echo "❌ Error: " . $stmt->error;
    }
}
?>
