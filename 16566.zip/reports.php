<?php
session_start();
if ($_SESSION['role'] !== 'admin') {
    header("Location: /ThreadUp/login.php");
    exit;
}

include("header.php");
include("db_connection.php");
require_once __DIR__ . '/vendor/autoload.php';

use Mpdf\Mpdf;

if (isset($_GET['generate'])) {
    $type = $_GET['generate'];
    $mpdf = new Mpdf();

    if ($type === 'bookings') {
        $html = "<h2 style='text-align:center;'>ThreadUp Booking Report</h2><hr><table border='1' cellpadding='10' cellspacing='0' width='100%'><tr><th>ID</th><th>Service</th><th>Status</th></tr>";
        $result = $conn->query("SELECT id, service, status FROM bookings");

        while ($row = $result->fetch_assoc()) {
            $html .= "<tr><td>{$row['id']}</td><td>{$row['service']}</td><td>{$row['status']}</td></tr>";
        }
        $html .= "</table>";
        $mpdf->WriteHTML($html);
        $mpdf->Output('booking_report.pdf', 'D');
        exit;
    } elseif ($type === 'users') {
        $html = "<h2 style='text-align:center;'>ThreadUp User Report</h2><hr><table border='1' cellpadding='10' cellspacing='0' width='100%'><tr><th>ID</th><th>Name</th><th>Email</th><th>Role</th></tr>";

        $users = [];
        $queries = [
            "SELECT id, name, email, 'customer' AS role FROM customers",
            "SELECT id, name, email, 'tailor' AS role FROM tailors",
            "SELECT id, name, email, 'admin' AS role FROM admins"
        ];

        foreach ($queries as $sql) {
            $res = $conn->query($sql);
            while ($row = $res->fetch_assoc()) {
                $users[] = $row;
            }
        }

        foreach ($users as $user) {
            $html .= "<tr><td>{$user['id']}</td><td>{$user['name']}</td><td>{$user['email']}</td><td>{$user['role']}</td></tr>";
        }

        $html .= "</table>";
        $mpdf->WriteHTML($html);
        $mpdf->Output('user_report.pdf', 'D');
        exit;
    }
}
?>

<!-- UI SECTION -->
<div class="container py-5">
    <div class="text-center mb-5">
        <h1 class="fw-bold text-primary">Admin Reports Panel</h1>
        <p class="text-muted">Generate and download important reports as PDF</p>
    </div>

    <div class="row justify-content-center g-4">
        <div class="col-md-5">
            <div class="card shadow-sm h-100 border-0">
                <div class="card-body text-center">
                    <h4 class="fw-bold">📋 Booking Report</h4>
                    <p class="text-muted">Generate a full report of all service bookings.</p>
                    <a href="reports.php?generate=bookings" class="btn btn-primary rounded-pill px-4">Download PDF</a>
                </div>
            </div>
        </div>

        <div class="col-md-5">
            <div class="card shadow-sm h-100 border-0">
                <div class="card-body text-center">
                    <h4 class="fw-bold">👥 User Report</h4>
                    <p class="text-muted">Get a list of all customers, tailors, and admins.</p>
                    <a href="reports.php?generate=users" class="btn btn-secondary rounded-pill px-4">Download PDF</a>
                </div>
            </div>
        </div>
    </div>

    <!-- FILTER + PRINT SECTION -->
    <div class="container mt-5">
        <div class="row mb-3 align-items-center no-print">
            <div class="col-md-6">
                <form method="GET" class="d-flex gap-2">
                    <select name="status" class="form-select" style="max-width: 200px;">
                        <option value="">All Statuses</option>
                        <option value="pending" <?= $status_filter == 'pending' ? 'selected' : '' ?>>Pending</option>
                        <option value="accepted" <?= $status_filter == 'accepted' ? 'selected' : '' ?>>Accepted</option>
                        <option value="in progress" <?= $status_filter == 'in progress' ? 'selected' : '' ?>>In Progress</option>
                        <option value="ready" <?= $status_filter == 'ready' ? 'selected' : '' ?>>Ready</option>
                        <option value="delivered" <?= $status_filter == 'delivered' ? 'selected' : '' ?>>Delivered</option>
                        <option value="rejected" <?= $status_filter == 'rejected' ? 'selected' : '' ?>>Rejected</option>
                    </select>
                    <button type="submit" class="btn btn-outline-primary">Apply Filter</button>
                </form>
            </div>
            <div class="col-md-6 text-end">
                <button onclick="window.print()" class="btn btn-dark">🖨️ Print Table</button>
            </div>
        </div>

        <div class="table-responsive">
            <table class="table table-bordered table-hover align-middle">
                <thead class="table-dark text-center">
                    <tr>
                        <th>Customer</th>
                        <th>Tailor</th>
                        <th>Service</th>
                        <th>Status</th>
                        <th>Date</th>
                        <th>Notes</th>
                        <th>Placed On</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $query = "SELECT b.*, c.name AS customer_name, t.name AS tailor_name
                  FROM bookings b
                  JOIN customers c ON b.customer_id = c.id
                  JOIN tailors t ON b.tailor_id = t.id";
                    if ($status_filter != "") {
                        $query .= " WHERE b.status = '$status_filter'";
                    }
                    $query .= " ORDER BY b.created_at DESC LIMIT 10";

                    $result = mysqli_query($conn, $query);
                    while ($row = mysqli_fetch_assoc($result)) {
                    ?>
                        <tr>
                            <td><?= htmlspecialchars($row['customer_name']) ?></td>
                            <td><?= htmlspecialchars($row['tailor_name']) ?></td>
                            <td><?= htmlspecialchars($row['service']) ?></td>
                            <td><span class="badge bg-info"><?= ucfirst($row['status']) ?></span></td>
                            <td><?= $row['booking_date'] ?></td>
                            <td><?= nl2br(htmlspecialchars($row['notes'])) ?></td>
                            <td><?= date("d M Y", strtotime($row['created_at'])) ?></td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>

</div>

<?php include("footer.php"); ?>