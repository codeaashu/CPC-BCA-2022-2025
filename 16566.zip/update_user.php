<?php
session_start();
if ($_SESSION['role'] !== 'admin') {
    header("Location: /ThreadUp/login.php");
    exit;
}
include("db_connect.php");
$user_id = $_GET['id'] ?? 0;
$user = $conn->query("SELECT * FROM users WHERE id = $user_id")->fetch_assoc();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $conn->real_escape_string($_POST['name']);
    $email = $conn->real_escape_string($_POST['email']);
    $role = $conn->real_escape_string($_POST['role']);
    $specialty = $conn->real_escape_string($_POST['specialty'] ?? '');
    $sql = "UPDATE users SET name='$name', email='$email', role='$role', specialty='$specialty' WHERE id=$user_id";
    $conn->query($sql);
    header("Location: /ThreadUp/admin_dashboard.php");
}
?>
<div class="container-fluid" role="main" aria-label="ThreadUp Update User">
    <div class="background-images" aria-hidden="true" aria-label="Tailors working in background">
        <img src="/ThreadUp/assets/1.jpg" alt="Close-up sewing machine stitching" />
        <img src="/ThreadUp/assets/2.jpg" alt="Colorful folded fabrics on shelf" />
        <img src="/ThreadUp/assets/img3.jpg" alt="Tailor cutting fabric with scissors" />
        <img src="/ThreadUp/assets/img2.jpg" alt="Fashion sketch on paper" />
        <img src="/ThreadUp/assets/i.jpg" alt="Tailor sewing by hand with needle" />
        <img src="/ThreadUp/assets/img1.avif" alt="Pattern drafting for tailor" />
        <img src="/ThreadUp/assets/img3.jpg" alt="Tailoring tools and equipment layout" />
        <img src="/ThreadUp/assets/img2.jpg" alt="Fashion sketch on paper" />
        <img src="/ThreadUp/assets/2.jpg" alt="Colorful folded fabrics on shelf" />
        <img src="/ThreadUp/assets/1.jpg" alt="Close-up sewing machine stitching" />
        <img src="/ThreadUp/assets/2.jpg" alt="Colorful folded fabrics on shelf" />
        <img src="/ThreadUp/assets/i.jpg" alt="Tailor measuring cloth on table" />
    </div>
    <section class="welcome-card" tabindex="0">
        <h1 class="section-title text-primary fw-bold">Update User</h1>
        <p class="lead text-center">Edit user details.</p>
        <form action="" method="POST">
            <div class="mb-3">
                <input type="text" name="name" class="form-control rounded-pill" value="<?php echo $user['name']; ?>" required />
            </div>
            <div class="mb-3">
                <input type="email" name="email" class="form-control rounded-pill" value="<?php echo $user['email']; ?>" required />
            </div>
            <div class="mb-3">
                <select name="role" class="form-select rounded-pill" required>
                    <option value="customer" <?php if ($user['role'] == 'customer') echo 'selected'; ?>>Customer</option>
                    <option value="tailor" <?php if ($user['role'] == 'tailor') echo 'selected'; ?>>Tailor</option>
                    <option value="admin" <?php if ($user['role'] == 'admin') echo 'selected'; ?>>Admin</option>
                </select>
            </div>
            <div class="mb-3">
                <input type="text" name="specialty" class="form-control rounded-pill" value="<?php echo $user['specialty']; ?>" placeholder="Specialty (for Tailor)" />
            </div>
            <div class="d-grid">
                <button type="submit" class="btn btn-primary rounded-pill">Update</button>
            </div>
        </form>
    </section>
</div>
<?php include("footer.php"); ?>